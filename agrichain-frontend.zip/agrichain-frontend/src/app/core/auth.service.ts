import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { LoginRequest, UserRequest, UserResponse, DecodedToken } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY = 'agrichain_token';
  private readonly USER_KEY  = 'agrichain_user';

  private _isLoggedIn = signal(false);
  private _currentUser = signal<DecodedToken | null>(null);

  readonly isLoggedIn = this._isLoggedIn.asReadonly();
  readonly currentUser = this._currentUser.asReadonly();

  constructor(private http: HttpClient, private router: Router) {
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    const token = localStorage.getItem(this.TOKEN_KEY);
    if (token && !this.isTokenExpired(token)) {
      this._isLoggedIn.set(true);
      this._currentUser.set(this.decodeToken(token));
    } else {
      this.clearStorage();
    }
  }

  register(dto: UserRequest): Observable<string> {
    return this.http.post(`${environment.apiGatewayUrl}/users/register`, dto, { responseType: 'text' });
  }

  login(dto: LoginRequest): Observable<string> {
    return this.http.post(`${environment.apiGatewayUrl}/users/login`, dto, { responseType: 'text' })
      .pipe(tap(token => {
        localStorage.setItem(this.TOKEN_KEY, token);
        const decoded = this.decodeToken(token);
        this._currentUser.set(decoded);
        this._isLoggedIn.set(true);
      }));
  }

  logout(): void {
    this.clearStorage();
    this._isLoggedIn.set(false);
    this._currentUser.set(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  getRole(): string {
    const user = this._currentUser();
    if (!user) return '';
    return user.role?.replace('ROLE_', '') || '';
  }

  getEmail(): string {
    return this._currentUser()?.sub || '';
  }

  hasRole(...roles: string[]): boolean {
    const role = this.getRole();
    return roles.includes(role);
  }

  private decodeToken(token: string): DecodedToken | null {
    try {
      const payload = token.split('.')[1];
      return JSON.parse(atob(payload));
    } catch { return null; }
  }

  private isTokenExpired(token: string): boolean {
    try {
      const decoded = this.decodeToken(token);
      if (!decoded) return true;
      return decoded.exp * 1000 < Date.now();
    } catch { return true; }
  }

  private clearStorage(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }
}
