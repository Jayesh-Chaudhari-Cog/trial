import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="topbar">
      <div class="topbar-left">
        <h2 class="page-title-bar">{{ title }}</h2>
        @if (subtitle) {
          <span class="topbar-subtitle">{{ subtitle }}</span>
        }
      </div>
      <div class="topbar-right">
        <span class="today-date">{{ today }}</span>
      </div>
    </header>
  `,
  styles: [`
    .topbar {
      height: var(--topbar-height);
      background: var(--color-surface);
      border-bottom: 1px solid var(--color-border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      position: fixed;
      top: 0;
      left: var(--sidebar-width);
      right: 0;
      z-index: 50;
      box-shadow: var(--shadow-sm);
    }

    .topbar-left { display: flex; align-items: baseline; gap: 0.75rem; }

    .page-title-bar {
      font-size: 1.125rem;
      font-weight: 600;
      color: var(--color-text-primary);
    }

    .topbar-subtitle {
      font-size: 0.875rem;
      color: var(--color-text-secondary);
    }

    .topbar-right { display: flex; align-items: center; gap: 1rem; }

    .today-date {
      font-size: 0.875rem;
      color: var(--color-text-secondary);
      font-weight: 500;
    }
  `]
})
export class TopbarComponent {
  @Input() title = 'AgriChain';
  @Input() subtitle = '';

  get today(): string {
    return new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  }
}
