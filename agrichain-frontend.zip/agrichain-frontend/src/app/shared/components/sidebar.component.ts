import { Component, computed, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/auth.service';

interface NavItem {
  label: string;
  icon: string;
  route: string;
  roles?: string[];
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, CommonModule],
  template: `
    <aside class="sidebar">
      <div class="sidebar-brand">
        <div class="brand-icon">🌾</div>
        <div class="brand-text">
          <span class="brand-name">AgriChain</span>
          <span class="brand-tagline">Supply Platform</span>
        </div>
      </div>

      <nav class="sidebar-nav">
        <span class="nav-section-label">Navigation</span>
        @for (item of visibleNav(); track item.route) {
          <a class="nav-item" [routerLink]="item.route" routerLinkActive="active">
            <span class="nav-icon">{{ item.icon }}</span>
            <span class="nav-label">{{ item.label }}</span>
          </a>
        }
      </nav>

      <div class="sidebar-footer">
        <div class="user-chip">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-info">
            <span class="user-email">{{ email() }}</span>
            <span class="user-role-badge">{{ role() }}</span>
          </div>
        </div>
        <button class="logout-btn" (click)="logout()">
          <span>⎋</span> Logout
        </button>
      </div>
    </aside>
  `,
  styles: [`
    .sidebar {
      width: var(--sidebar-width);
      height: 100vh;
      background: var(--color-primary-dark);
      display: flex;
      flex-direction: column;
      position: fixed;
      left: 0; top: 0;
      z-index: 100;
      overflow: hidden;
    }

    .sidebar-brand {
      display: flex;
      align-items: center;
      gap: 0.875rem;
      padding: 1.5rem 1.25rem;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }

    .brand-icon {
      width: 40px; height: 40px;
      background: var(--color-accent);
      border-radius: var(--radius-md);
      display: flex; align-items: center; justify-content: center;
      font-size: 1.25rem;
      flex-shrink: 0;
    }

    .brand-text { display: flex; flex-direction: column; }
    .brand-name { font-size: 1rem; font-weight: 700; color: white; letter-spacing: 0.01em; }
    .brand-tagline { font-size: 0.7rem; color: rgba(255,255,255,0.4); text-transform: uppercase; letter-spacing: 0.08em; }

    .sidebar-nav {
      flex: 1;
      padding: 1.25rem 0.75rem;
      display: flex;
      flex-direction: column;
      gap: 0.125rem;
      overflow-y: auto;
    }

    .nav-section-label {
      font-size: 0.6875rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: rgba(255,255,255,0.3);
      padding: 0 0.625rem;
      margin-bottom: 0.5rem;
    }

    .nav-item {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.625rem 0.875rem;
      border-radius: var(--radius-md);
      color: rgba(255,255,255,0.65);
      text-decoration: none;
      font-size: 0.9375rem;
      font-weight: 500;
      transition: all 0.15s ease;

      &:hover { background: rgba(255,255,255,0.07); color: rgba(255,255,255,0.9); }

      &.active {
        background: var(--color-accent);
        color: white;
        .nav-icon { opacity: 1; }
      }
    }

    .nav-icon { font-size: 1.125rem; opacity: 0.75; line-height: 1; }
    .nav-label { line-height: 1; }

    .sidebar-footer {
      padding: 1rem 0.75rem;
      border-top: 1px solid rgba(255,255,255,0.08);
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .user-chip {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.625rem 0.75rem;
      background: rgba(255,255,255,0.05);
      border-radius: var(--radius-md);
    }

    .user-avatar {
      width: 34px; height: 34px;
      background: var(--color-primary);
      border: 2px solid var(--color-accent);
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 0.75rem;
      font-weight: 700;
      color: white;
      flex-shrink: 0;
    }

    .user-info { display: flex; flex-direction: column; min-width: 0; }
    .user-email { font-size: 0.75rem; color: rgba(255,255,255,0.7); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .user-role-badge {
      font-size: 0.6875rem;
      font-weight: 600;
      color: var(--color-accent);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .logout-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      width: 100%;
      padding: 0.5rem 0.75rem;
      background: transparent;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: var(--radius-md);
      color: rgba(255,255,255,0.5);
      font-family: var(--font-sans);
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.15s ease;

      &:hover { border-color: rgba(220,38,38,0.5); color: #f87171; background: rgba(220,38,38,0.08); }
    }
  `]
})
export class SidebarComponent {
  private readonly navItems: NavItem[] = [
    { label: 'Dashboard',    icon: '⊞', route: '/dashboard' },
    { label: 'Users',        icon: '👤', route: '/users',     roles: ['ADMIN', 'MANAGER', 'OFFICER', 'AUDITOR'] },
    { label: 'Farmers',      icon: '🧑‍🌾', route: '/farmers' },
    { label: 'Market',       icon: '🌽', route: '/market' },
    { label: 'Subsidy',      icon: '💰', route: '/subsidy',   roles: ['ADMIN', 'MANAGER', 'OFFICER', 'FARMER'] },
    { label: 'Audit',        icon: '📋', route: '/audit',     roles: ['ADMIN', 'MANAGER', 'AUDITOR', 'COMPLIANCE', 'OFFICER'] },
    { label: 'Reports',      icon: '📊', route: '/reports',   roles: ['ADMIN', 'MANAGER', 'AUDITOR', 'OFFICER'] },
    { label: 'Audit Logs',   icon: '🗒️', route: '/audit-logs', roles: ['ADMIN', 'MANAGER', 'AUDITOR'] },
  ];

  visibleNav = computed(() => {
    const role = this.auth.getRole();
    return this.navItems.filter(i => !i.roles || i.roles.includes(role));
  });

  email = computed(() => this.auth.getEmail());
  role  = computed(() => this.auth.getRole());
  initials = computed(() => {
    const e = this.auth.getEmail();
    return e ? e.substring(0, 2).toUpperCase() : 'AC';
  });

  constructor(private auth: AuthService) {}
  logout() { this.auth.logout(); }
}
