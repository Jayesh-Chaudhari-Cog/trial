import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  UserRequest, UserResponse,
  Farmer, FarmerResponse, FarmerDocument,
  CropListing, Order,
  SubsidyProgram, Disbursement, DisbursementDTO,
  Audit, Compliance, AuditLog,
  Report, ReportDTO
} from '../models/models';

const BASE = environment.apiGatewayUrl;

// ─── User Service ─────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class UserService {
  private url = `${BASE}/users`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<UserResponse[]> { return this.http.get<UserResponse[]>(this.url); }
  getById(id: number): Observable<UserResponse> { return this.http.get<UserResponse>(`${this.url}/${id}`); }
  update(id: number, dto: UserRequest): Observable<UserResponse> { return this.http.put<UserResponse>(`${this.url}/${id}`, dto); }
  deactivate(id: number): Observable<string> { return this.http.delete(`${this.url}/${id}`, { responseType: 'text' }); }
}

// ─── Farmer Service ───────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class FarmerService {
  private url = `${BASE}/farmers`;
  private docUrl = `${BASE}/documents`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<Farmer[]> { return this.http.get<Farmer[]>(this.url); }
  getById(id: number): Observable<FarmerResponse> { return this.http.get<FarmerResponse>(`${this.url}/${id}`); }
  create(farmer: Farmer): Observable<FarmerResponse> { return this.http.post<FarmerResponse>(this.url, farmer); }
  update(id: number, farmer: Farmer): Observable<Farmer> { return this.http.put<Farmer>(`${this.url}/${id}`, farmer); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }

  // Documents
  getDocuments(farmerId: number): Observable<FarmerDocument[]> { return this.http.get<FarmerDocument[]>(`${this.docUrl}/farmer/${farmerId}`); }
  uploadDocument(doc: FarmerDocument): Observable<FarmerDocument> { return this.http.post<FarmerDocument>(this.docUrl, doc); }
  verifyDocument(docId: number, status: string): Observable<FarmerDocument> {
    return this.http.put<FarmerDocument>(`${this.docUrl}/${docId}/verify`, { status });
  }
}

// ─── Market Service ───────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class MarketService {
  private url = `${BASE}/market`;
  constructor(private http: HttpClient) {}

  // Listings
  getAllListings(): Observable<CropListing[]> { return this.http.get<CropListing[]>(`${this.url}/listings`); }
  getListingsByStatus(status: string): Observable<CropListing[]> { return this.http.get<CropListing[]>(`${this.url}/listings/status/${status}`); }
  createListing(dto: CropListing): Observable<CropListing> { return this.http.post<CropListing>(`${this.url}/createlisting`, dto); }
  validateListing(id: number): Observable<CropListing> { return this.http.put<CropListing>(`${this.url}/listings/validate/${id}`, {}); }
  reduceQuantity(listingId: number, quantity: number): Observable<void> {
    return this.http.put<void>(`${this.url}/listings/${listingId}/reduce-quantity`, null, {
      params: new HttpParams().set('quantity', quantity)
    });
  }

  // Orders
  getAllOrders(): Observable<Order[]> { return this.http.get<Order[]>(`${this.url}/orders`); }
  getOrderById(id: number): Observable<Order> { return this.http.get<Order>(`${this.url}/orders/${id}`); }
  getOrdersByTrader(traderId: number): Observable<Order[]> { return this.http.get<Order[]>(`${this.url}/orders/trader/${traderId}`); }
  placeOrder(dto: Order): Observable<Order> { return this.http.post<Order>(`${this.url}/placeorder`, dto); }
  updateOrderStatus(id: number, status: string): Observable<Order> {
    return this.http.put<Order>(`${this.url}/orders/${id}/status`, null, {
      params: new HttpParams().set('status', status)
    });
  }
}

// ─── Subsidy Service ──────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class SubsidyService {
  private programUrl = `${BASE}/subsidy-programs`;
  private disburseUrl = `${BASE}/disbursements`;
  constructor(private http: HttpClient) {}

  // Programs
  getAllPrograms(): Observable<SubsidyProgram[]> { return this.http.get<SubsidyProgram[]>(this.programUrl); }
  getProgramById(id: number): Observable<SubsidyProgram> { return this.http.get<SubsidyProgram>(`${this.programUrl}/${id}`); }
  createProgram(p: SubsidyProgram): Observable<SubsidyProgram> { return this.http.post<SubsidyProgram>(this.programUrl, p); }
  updateProgram(id: number, p: SubsidyProgram): Observable<SubsidyProgram> { return this.http.put<SubsidyProgram>(`${this.programUrl}/${id}`, p); }
  deleteProgram(id: number): Observable<string> { return this.http.delete(`${this.programUrl}/${id}`, { responseType: 'text' }); }

  // Disbursements
  getAllDisbursements(): Observable<Disbursement[]> { return this.http.get<Disbursement[]>(this.disburseUrl); }
  getDisbursementById(id: number): Observable<Disbursement> { return this.http.get<Disbursement>(`${this.disburseUrl}/${id}`); }
  getDisbursementsByFarmer(farmerId: number): Observable<Disbursement[]> { return this.http.get<Disbursement[]>(`${this.disburseUrl}/farmer/${farmerId}`); }
  getDisbursementsByProgram(programId: number): Observable<Disbursement[]> { return this.http.get<Disbursement[]>(`${this.disburseUrl}/program/${programId}`); }
  applyForSubsidy(dto: DisbursementDTO): Observable<Disbursement> { return this.http.post<Disbursement>(this.disburseUrl, dto); }
  reviewDisbursement(id: number, status: string): Observable<Disbursement> {
    return this.http.patch<Disbursement>(`${this.disburseUrl}/${id}/review`, null, {
      params: new HttpParams().set('status', status)
    });
  }
}

// ─── Audit Service ────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class AuditService {
  private auditUrl      = `${BASE}/api/audits`;
  private complianceUrl = `${BASE}/api/compliances`;
  private logUrl        = `${BASE}/api/auditlogs`;
  constructor(private http: HttpClient) {}

  // Audits
  getAllAudits(): Observable<Audit[]> { return this.http.get<Audit[]>(`${this.auditUrl}/all`); }
  getAuditById(id: number): Observable<Audit> { return this.http.get<Audit>(`${this.auditUrl}/${id}`); }
  createAudit(dto: Audit): Observable<Audit> { return this.http.post<Audit>(`${this.auditUrl}/create`, dto); }
  updateAudit(id: number, dto: Audit): Observable<Audit> { return this.http.put<Audit>(`${this.auditUrl}/${id}`, dto); }
  deleteAudit(id: number): Observable<void> { return this.http.delete<void>(`${this.auditUrl}/${id}`); }
  getByScope(scope: string): Observable<Audit[]> { return this.http.get<Audit[]>(`${this.auditUrl}/scope/${scope}`); }
  getByStatus(status: string): Observable<Audit[]> { return this.http.get<Audit[]>(`${this.auditUrl}/status/${status}`); }
  getByOfficer(officerId: number): Observable<Audit[]> { return this.http.get<Audit[]>(`${this.auditUrl}/officer/${officerId}`); }

  // Compliances
  getAllCompliances(): Observable<Compliance[]> { return this.http.get<Compliance[]>(`${this.complianceUrl}/all`); }
  getComplianceById(id: number): Observable<Compliance> { return this.http.get<Compliance>(`${this.complianceUrl}/${id}`); }
  createCompliance(auditId: number, dto: Compliance): Observable<Compliance> { return this.http.post<Compliance>(`${this.complianceUrl}/create/${auditId}`, dto); }
  updateCompliance(id: number, dto: Compliance): Observable<Compliance> { return this.http.put<Compliance>(`${this.complianceUrl}/update/${id}`, dto); }
  deleteCompliance(id: number): Observable<void> { return this.http.delete<void>(`${this.complianceUrl}/delete/${id}`); }
  getCompliancesByAudit(auditId: number): Observable<Compliance[]> { return this.http.get<Compliance[]>(`${this.complianceUrl}/audit/${auditId}`); }

  // Audit Logs
  getAllLogs(): Observable<AuditLog[]> { return this.http.get<AuditLog[]>(`${this.logUrl}/all`); }
  getLogById(id: number): Observable<AuditLog> { return this.http.get<AuditLog>(`${this.logUrl}/${id}`); }
}

// ─── Report Service ───────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ReportService {
  private url = `${BASE}/api/report`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<Report[]> { return this.http.get<Report[]>(`${this.url}/all`); }
  getById(id: number): Observable<Report> { return this.http.get<Report>(`${this.url}/${id}`); }
  generate(dto: ReportDTO): Observable<Report> { return this.http.post<Report>(`${this.url}/generate`, dto); }
  update(id: number, dto: ReportDTO): Observable<Report> { return this.http.put<Report>(`${this.url}/update/${id}`, dto); }
  delete(id: number): Observable<string> { return this.http.delete(`${this.url}/delete/${id}`, { responseType: 'text' }); }
  getByScope(scope: string): Observable<Report[]> { return this.http.get<Report[]>(`${this.url}/scope/${scope}`); }
  getByDateRange(start: string, end: string): Observable<Report[]> {
    return this.http.get<Report[]>(`${this.url}/range`, {
      params: new HttpParams().set('start', start).set('end', end)
    });
  }
  generateTransactionReport(status: string): Observable<Report> {
    return this.http.get<Report>(`${this.url}/transactionsreport/${status}`);
  }
}
