import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { SubsidyService } from '../../services/api.services';
import { SubsidyProgram, Disbursement } from '../../models/models';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-subsidy',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Subsidy Management" subtitle="Programs and disbursements" />

    <div class="page-content">
      <div class="tab-bar">
        <button class="tab-btn" [class.active]="tab() === 'programs'" (click)="switchTab('programs')">💰 Programs</button>
        <button class="tab-btn" [class.active]="tab() === 'disbursements'" (click)="switchTab('disbursements')">📤 Disbursements</button>
      </div>

      <!-- Programs Tab -->
      @if (tab() === 'programs') {
        <div class="page-header">
          <div>
            <h2 class="page-title">Subsidy Programs</h2>
            <p class="page-subtitle">{{ programs().length }} programs available</p>
          </div>
          @if (canManage()) {
            <button class="btn btn-primary" (click)="openCreateProgram()">＋ New Program</button>
          }
        </div>

        @if (loadingPrograms()) {
          <div class="loading-container"><span class="spinner"></span> Loading…</div>
        } @else if (programs().length === 0) {
          <div class="empty-state"><div class="empty-icon">💰</div><h3>No programs yet</h3></div>
        } @else {
          <div class="programs-grid">
            @for (p of programs(); track p.programId) {
              <div class="program-card">
                <div class="pc-header">
                  <h3 class="pc-title">{{ p.title }}</h3>
                  <div class="flex gap-2">
                    @if (canManage()) {
                      <button class="btn btn-ghost btn-sm btn-icon" (click)="openEditProgram(p)">✏️</button>
                      <button class="btn btn-ghost btn-sm btn-icon" (click)="deleteProgram(p.programId!)">🗑️</button>
                    }
                  </div>
                </div>
                <p class="pc-desc">{{ p.description || 'No description provided.' }}</p>
                <div class="pc-budget">
                  <div class="budget-row">
                    <span>Allotted Budget</span>
                    <strong>₹{{ p.allottedBudget | number }}</strong>
                  </div>
                  @if (p.disbursedAmount) {
                    <div class="budget-row">
                      <span>Disbursed</span>
                      <strong>₹{{ p.disbursedAmount | number }}</strong>
                    </div>
                  }
                </div>
                @if (p.startDate || p.endDate) {
                  <div class="pc-dates">
                    📅 {{ p.startDate || '?' }} → {{ p.endDate || 'ongoing' }}
                  </div>
                }
                <button class="btn btn-outline btn-sm w-full mt-3" (click)="applyForSubsidy(p)">Apply for Disbursement</button>
              </div>
            }
          </div>
        }
      }

      <!-- Disbursements Tab -->
      @if (tab() === 'disbursements') {
        <div class="page-header">
          <div>
            <h2 class="page-title">Disbursements</h2>
            <p class="page-subtitle">{{ disbursements().length }} applications</p>
          </div>
        </div>

        @if (loadingDisbursements()) {
          <div class="loading-container"><span class="spinner"></span> Loading…</div>
        } @else if (disbursements().length === 0) {
          <div class="empty-state"><div class="empty-icon">📤</div><h3>No disbursements yet</h3></div>
        } @else {
          <div class="card">
            <div class="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>ID</th><th>Farmer ID</th><th>Program ID</th>
                    <th>Requested</th><th>Approved</th><th>Status</th><th>Remarks</th>
                    @if (canManage()) { <th>Actions</th> }
                  </tr>
                </thead>
                <tbody>
                  @for (d of disbursements(); track d.disbursementId) {
                    <tr>
                      <td class="text-muted">{{ d.disbursementId }}</td>
                      <td>{{ d.farmerId }}</td>
                      <td>{{ d.programId }}</td>
                      <td>₹{{ d.requestedAmount | number }}</td>
                      <td>{{ d.approvedAmount ? '₹' + (d.approvedAmount | number) : '—' }}</td>
                      <td><span class="badge" [class]="disburseStatusBadge(d.status)">{{ d.status }}</span></td>
                      <td>{{ d.remarks || '—' }}</td>
                      @if (canManage()) {
                        <td>
                          @if (d.status === 'PENDING') {
                            <div class="flex gap-2">
                              <button class="btn btn-sm btn-outline" style="color:var(--color-success);border-color:var(--color-success)" (click)="review(d.disbursementId!, 'APPROVED')">✅ Approve</button>
                              <button class="btn btn-sm btn-outline" style="color:var(--color-danger);border-color:var(--color-danger)" (click)="review(d.disbursementId!, 'REJECTED')">❌ Reject</button>
                            </div>
                          } @else { <span class="text-muted text-sm">—</span> }
                        </td>
                      }
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }
      }
    </div>

    <!-- Program Modal -->
    @if (showProgramModal()) {
      <div class="modal-overlay" (click)="showProgramModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>{{ editingProgram ? 'Edit' : 'New' }} Subsidy Program</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showProgramModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (pErr()) { <div class="alert alert-danger mb-4">{{ pErr() }}</div> }
            <div class="form-group">
              <label class="form-label">Title *</label>
              <input class="form-control" [(ngModel)]="pDto.title" placeholder="e.g. PM-KISAN" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Description</label>
              <input class="form-control" [(ngModel)]="pDto.description" />
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Allotted Budget (₹) *</label>
                <input class="form-control" type="number" [(ngModel)]="pDto.allottedBudget" />
              </div>
              <div class="form-group">
                <label class="form-label">Eligibility Criteria</label>
                <input class="form-control" [(ngModel)]="pDto.eligibilityCriteria" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Start Date</label>
                <input class="form-control" type="date" [(ngModel)]="pDto.startDate" />
              </div>
              <div class="form-group">
                <label class="form-label">End Date</label>
                <input class="form-control" type="date" [(ngModel)]="pDto.endDate" />
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showProgramModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveProgram()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Save
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Apply Disbursement Modal -->
    @if (showApplyModal()) {
      <div class="modal-overlay" (click)="showApplyModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>Apply for Subsidy</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showApplyModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (aErr()) { <div class="alert alert-danger mb-4">{{ aErr() }}</div> }
            <div class="alert alert-warning mb-4">
              🎯 Applying for: <strong>{{ selectedProgram()?.title }}</strong>
            </div>
            <div class="form-group">
              <label class="form-label">Farmer ID *</label>
              <input class="form-control" type="number" [(ngModel)]="applyDto.farmerId" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Requested Amount (₹) *</label>
              <input class="form-control" type="number" [(ngModel)]="applyDto.requestedAmount" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Remarks</label>
              <input class="form-control" [(ngModel)]="applyDto.remarks" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showApplyModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitApplication()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Submit Application
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .tab-bar { display: flex; gap: 0.25rem; margin-bottom: 1.5rem; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: 0.375rem; width: fit-content; }
    .tab-btn { padding: 0.5rem 1.25rem; border-radius: var(--radius-md); border: none; background: transparent; font-family: var(--font-sans); font-size: 0.9375rem; font-weight: 500; color: var(--color-text-secondary); cursor: pointer; transition: all 0.15s ease; &.active { background: var(--color-primary); color: white; } &:not(.active):hover { background: var(--color-surface-2); } }

    .programs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.25rem; }
    .program-card { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: 1.25rem; box-shadow: var(--shadow-sm); transition: box-shadow 0.2s ease; &:hover { box-shadow: var(--shadow-md); } }
    .pc-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 0.5rem; }
    .pc-title { font-size: 1rem; font-weight: 700; color: var(--color-text-primary); }
    .pc-desc { font-size: 0.875rem; color: var(--color-text-secondary); margin-bottom: 1rem; line-height: 1.5; }
    .pc-budget { background: var(--color-surface-2); border-radius: var(--radius-md); padding: 0.75rem; margin-bottom: 0.75rem; }
    .budget-row { display: flex; justify-content: space-between; font-size: 0.875rem; color: var(--color-text-secondary); & strong { color: var(--color-text-primary); } &:not(:last-child) { margin-bottom: 0.375rem; } }
    .pc-dates { font-size: 0.8125rem; color: var(--color-text-muted); }
  `]
})
export class SubsidyComponent implements OnInit {
  tab = signal<'programs'|'disbursements'>('programs');
  programs = signal<SubsidyProgram[]>([]);
  disbursements = signal<Disbursement[]>([]);
  loadingPrograms = signal(true);
  loadingDisbursements = signal(true);
  saving = signal(false);
  showProgramModal = signal(false);
  showApplyModal = signal(false);
  editingProgram: SubsidyProgram | null = null;
  selectedProgram = signal<SubsidyProgram | null>(null);
  pErr = signal('');
  aErr = signal('');
  pDto: Partial<SubsidyProgram> = {};
  applyDto: { farmerId?: number; requestedAmount?: number; remarks?: string } = {};

  constructor(private svc: SubsidyService, private auth: AuthService) {}

  ngOnInit(): void {
    this.loadPrograms();
    this.loadDisbursements();
  }

  switchTab(t: 'programs' | 'disbursements'): void {
    this.tab.set(t);
    if (t === 'disbursements') this.loadDisbursements();
  }

  loadPrograms(): void {
    this.svc.getAllPrograms().subscribe({
      next: d => { this.programs.set(d); this.loadingPrograms.set(false); },
      error: () => this.loadingPrograms.set(false)
    });
  }

  loadDisbursements(): void {
    this.svc.getAllDisbursements().subscribe({
      next: d => { this.disbursements.set(d); this.loadingDisbursements.set(false); },
      error: () => this.loadingDisbursements.set(false)
    });
  }

  canManage(): boolean { return this.auth.hasRole('ADMIN','MANAGER','OFFICER'); }

  openCreateProgram(): void { this.pDto = {}; this.editingProgram = null; this.pErr.set(''); this.showProgramModal.set(true); }
  openEditProgram(p: SubsidyProgram): void { this.pDto = { ...p }; this.editingProgram = p; this.pErr.set(''); this.showProgramModal.set(true); }

  saveProgram(): void {
    if (!this.pDto.title || !this.pDto.allottedBudget) { this.pErr.set('Title and budget are required.'); return; }
    this.saving.set(true);
    const obs = this.editingProgram
      ? this.svc.updateProgram(this.editingProgram.programId!, this.pDto as SubsidyProgram)
      : this.svc.createProgram(this.pDto as SubsidyProgram);
    obs.subscribe({
      next: () => { this.saving.set(false); this.showProgramModal.set(false); this.loadPrograms(); },
      error: () => { this.pErr.set('Failed to save.'); this.saving.set(false); }
    });
  }

  deleteProgram(id: number): void {
    if (!confirm('Delete this subsidy program?')) return;
    this.svc.deleteProgram(id).subscribe({ next: () => this.loadPrograms() });
  }

  applyForSubsidy(p: SubsidyProgram): void {
    this.selectedProgram.set(p);
    this.applyDto = { farmerId: undefined, requestedAmount: undefined };
    this.aErr.set('');
    this.showApplyModal.set(true);
  }

  submitApplication(): void {
    if (!this.applyDto.farmerId || !this.applyDto.requestedAmount) { this.aErr.set('Fill all required fields.'); return; }
    this.saving.set(true);
    this.svc.applyForSubsidy({
      farmerId: this.applyDto.farmerId,
      programId: this.selectedProgram()!.programId!,
      requestedAmount: this.applyDto.requestedAmount,
      remarks: this.applyDto.remarks
    }).subscribe({
      next: () => { this.saving.set(false); this.showApplyModal.set(false); this.loadDisbursements(); },
      error: () => { this.aErr.set('Application failed.'); this.saving.set(false); }
    });
  }

  review(id: number, status: string): void {
    this.svc.reviewDisbursement(id, status).subscribe({ next: () => this.loadDisbursements() });
  }

  disburseStatusBadge(s?: string): string {
    return s === 'APPROVED' || s === 'DISBURSED' ? 'badge badge-success' : s === 'REJECTED' ? 'badge badge-danger' : 'badge badge-warning';
  }
}
