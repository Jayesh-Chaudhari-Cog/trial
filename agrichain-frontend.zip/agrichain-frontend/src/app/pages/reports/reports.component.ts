import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { ReportService } from '../../services/api.services';
import { Report, ReportDTO } from '../../models/models';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Reports" subtitle="Generate and manage analytical reports" />

    <div class="page-content">
      <div class="page-header">
        <div>
          <h2 class="page-title">Reports</h2>
          <p class="page-subtitle">{{ reports().length }} reports generated</p>
        </div>
        <div class="flex gap-2">
          <button class="btn btn-outline" (click)="openTxnReport()">📊 Transaction Report</button>
          <button class="btn btn-primary" (click)="openGenerate()">＋ Generate Report</button>
        </div>
      </div>

      <!-- Date range filter -->
      <div class="card mb-4">
        <div class="card-body">
          <div class="flex gap-3 items-center flex-wrap">
            <span class="font-medium text-sm">Filter by date range:</span>
            <div class="form-group" style="flex-direction:row;align-items:center;gap:0.5rem;margin:0">
              <label class="form-label" style="white-space:nowrap;margin:0">From</label>
              <input class="form-control" type="date" [(ngModel)]="startDate" style="width:160px" />
            </div>
            <div class="form-group" style="flex-direction:row;align-items:center;gap:0.5rem;margin:0">
              <label class="form-label" style="white-space:nowrap;margin:0">To</label>
              <input class="form-control" type="date" [(ngModel)]="endDate" style="width:160px" />
            </div>
            <button class="btn btn-outline btn-sm" (click)="filterByDate()">Apply Filter</button>
            <button class="btn btn-ghost btn-sm" (click)="clearFilter()">Clear</button>
          </div>
        </div>
      </div>

      @if (loading()) {
        <div class="loading-container"><span class="spinner"></span> Loading reports…</div>
      } @else if (reports().length === 0) {
        <div class="empty-state">
          <div class="empty-icon">📊</div>
          <h3>No reports yet</h3>
          <p>Generate your first report using the button above.</p>
        </div>
      } @else {
        <div class="report-grid">
          @for (r of reports(); track r.reportId) {
            <div class="report-card">
              <div class="rc-top">
                <div class="rc-id">Report #{{ r.reportId }}</div>
                <div class="flex gap-2">
                  <button class="btn btn-ghost btn-sm btn-icon" (click)="openEdit(r)">✏️</button>
                  <button class="btn btn-ghost btn-sm btn-icon" (click)="deleteReport(r.reportId!)">🗑️</button>
                </div>
              </div>
              <div class="rc-scope">
                <span class="badge badge-primary">{{ r.scope }}</span>
              </div>
              <div class="rc-metrics">
                <span class="rc-label">Metrics</span>
                <p class="rc-value">{{ r.metrics }}</p>
              </div>
              <div class="rc-date">
                📅 Generated: {{ r.generatedDate || 'Today' }}
              </div>
            </div>
          }
        </div>
      }
    </div>

    <!-- Generate/Edit Modal -->
    @if (showModal()) {
      <div class="modal-overlay" (click)="showModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>{{ editingReport ? 'Edit Report' : 'Generate Report' }}</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (errMsg()) { <div class="alert alert-danger mb-4">{{ errMsg() }}</div> }
            <div class="form-group">
              <label class="form-label">Scope *</label>
              <input class="form-control" [(ngModel)]="dto.scope" placeholder="e.g. QUARTERLY, ANNUAL, REGIONAL" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Metrics *</label>
              <input class="form-control" [(ngModel)]="dto.metrics" placeholder="e.g. Total Sales, Subsidy Utilization, Farmer Count" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveReport()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> }
              {{ editingReport ? 'Save Changes' : 'Generate' }}
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Transaction Report Modal -->
    @if (showTxnModal()) {
      <div class="modal-overlay" (click)="showTxnModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>Generate Transaction Report</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showTxnModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Transaction Status *</label>
              <select class="form-control" [(ngModel)]="txnStatus">
                <option value="">Select…</option>
                <option value="SUCCESS">SUCCESS</option>
                <option value="PENDING">PENDING</option>
                <option value="FAILED">FAILED</option>
              </select>
            </div>
            @if (txnReport()) {
              <div class="alert alert-success mt-3">
                ✅ Report #{{ txnReport()!.reportId }} generated! Scope: {{ txnReport()!.scope }}
              </div>
            }
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showTxnModal.set(false)">Close</button>
            <button class="btn btn-primary" (click)="generateTxnReport()" [disabled]="saving() || !txnStatus">
              @if (saving()) { <span class="spinner"></span> } Generate
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .report-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.25rem; }

    .report-card {
      background: var(--color-surface);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-lg);
      padding: 1.25rem;
      box-shadow: var(--shadow-sm);
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      transition: box-shadow 0.2s ease;
      &:hover { box-shadow: var(--shadow-md); }
    }

    .rc-top { display: flex; justify-content: space-between; align-items: center; }
    .rc-id { font-weight: 700; font-size: 0.9375rem; color: var(--color-text-secondary); }
    .rc-scope { }
    .rc-metrics { }
    .rc-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.06em; font-weight: 600; color: var(--color-text-muted); }
    .rc-value { font-size: 0.9375rem; margin-top: 0.25rem; color: var(--color-text-primary); }
    .rc-date { font-size: 0.8125rem; color: var(--color-text-muted); }
  `]
})
export class ReportsComponent implements OnInit {
  reports = signal<Report[]>([]);
  loading = signal(true);
  saving = signal(false);
  showModal = signal(false);
  showTxnModal = signal(false);
  editingReport: Report | null = null;
  errMsg = signal('');
  txnStatus = '';
  txnReport = signal<Report | null>(null);
  startDate = '';
  endDate = '';
  dto: Partial<ReportDTO> = {};

  constructor(private svc: ReportService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.svc.getAll().subscribe({
      next: d => { this.reports.set(d); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  openGenerate(): void { this.dto = {}; this.editingReport = null; this.errMsg.set(''); this.showModal.set(true); }
  openEdit(r: Report): void { this.dto = { scope: r.scope, metrics: r.metrics }; this.editingReport = r; this.errMsg.set(''); this.showModal.set(true); }

  saveReport(): void {
    if (!this.dto.scope || !this.dto.metrics) { this.errMsg.set('Scope and metrics are required.'); return; }
    this.saving.set(true);
    const obs = this.editingReport
      ? this.svc.update(this.editingReport.reportId!, this.dto as ReportDTO)
      : this.svc.generate(this.dto as ReportDTO);
    obs.subscribe({
      next: () => { this.saving.set(false); this.showModal.set(false); this.load(); },
      error: () => { this.errMsg.set('Operation failed.'); this.saving.set(false); }
    });
  }

  deleteReport(id: number): void {
    if (!confirm('Delete this report?')) return;
    this.svc.delete(id).subscribe({ next: () => this.load() });
  }

  filterByDate(): void {
    if (!this.startDate || !this.endDate) return;
    const fmt = (d: string) => d.split('-').reverse().join('-');
    this.svc.getByDateRange(fmt(this.startDate), fmt(this.endDate)).subscribe({
      next: d => this.reports.set(d)
    });
  }

  clearFilter(): void { this.startDate = ''; this.endDate = ''; this.load(); }

  openTxnReport(): void { this.txnStatus = ''; this.txnReport.set(null); this.showTxnModal.set(true); }

  generateTxnReport(): void {
    this.saving.set(true);
    this.svc.generateTransactionReport(this.txnStatus).subscribe({
      next: r => { this.txnReport.set(r); this.saving.set(false); this.load(); },
      error: () => this.saving.set(false)
    });
  }
}
