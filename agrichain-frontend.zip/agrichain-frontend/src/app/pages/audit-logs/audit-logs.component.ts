import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { AuditService } from '../../services/api.services';
import { AuditLog } from '../../models/models';

@Component({
  selector: 'app-audit-logs',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Audit Logs" subtitle="System-wide activity and action logs" />

    <div class="page-content">
      <div class="page-header">
        <div>
          <h2 class="page-title">System Audit Logs</h2>
          <p class="page-subtitle">{{ filtered().length }} of {{ logs().length }} entries</p>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="search-bar">
            <span class="search-icon">🔍</span>
            <input type="text" placeholder="Search by action, user or role…"
                   [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()" />
          </div>
          <select class="form-control" style="width:160px" [(ngModel)]="roleFilter" (ngModelChange)="applyFilter()">
            <option value="">All Roles</option>
            <option value="ADMIN">ADMIN</option>
            <option value="MANAGER">MANAGER</option>
            <option value="FARMER">FARMER</option>
            <option value="TRADER">TRADER</option>
            <option value="OFFICER">OFFICER</option>
            <option value="AUDITOR">AUDITOR</option>
            <option value="COMPLIANCE">COMPLIANCE</option>
            <option value="USER">USER</option>
            <option value="SYSTEM">SYSTEM</option>
          </select>
        </div>

        @if (loading()) {
          <div class="loading-container"><span class="spinner"></span> Loading audit logs…</div>
        } @else if (filtered().length === 0) {
          <div class="empty-state">
            <div class="empty-icon">🗒️</div>
            <h3>No logs found</h3>
            <p>Logs are automatically created as users interact with the system.</p>
          </div>
        } @else {
          <div class="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Log ID</th>
                  <th>Performed By</th>
                  <th>Action</th>
                  <th>Role</th>
                  <th>Details</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                @for (log of filtered(); track log.logId) {
                  <tr>
                    <td class="text-muted">{{ log.logId }}</td>
                    <td class="font-semibold">{{ log.performedBy }}</td>
                    <td>
                      <span class="action-chip" [class]="actionChip(log.action)">{{ log.action }}</span>
                    </td>
                    <td><span class="badge badge-primary">{{ log.role }}</span></td>
                    <td style="max-width:280px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                      {{ log.details || '—' }}
                    </td>
                    <td class="text-muted text-sm">{{ formatTime(log.timestamp) }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .action-chip {
      display: inline-flex;
      padding: 0.2rem 0.625rem;
      border-radius: 4px;
      font-size: 0.75rem;
      font-weight: 700;
      font-family: 'Courier New', monospace;
      letter-spacing: 0.02em;
      text-transform: uppercase;
    }
    .action-create { background: rgba(22,163,74,0.12); color: var(--color-success); }
    .action-update { background: rgba(37,99,235,0.12); color: var(--color-info); }
    .action-delete { background: rgba(220,38,38,0.12); color: var(--color-danger); }
    .action-login  { background: rgba(245,158,11,0.12); color: var(--color-warning); }
    .action-default { background: var(--color-surface-2); color: var(--color-text-secondary); }
  `]
})
export class AuditLogsComponent implements OnInit {
  logs     = signal<AuditLog[]>([]);
  filtered = signal<AuditLog[]>([]);
  loading  = signal(true);
  searchTerm = '';
  roleFilter = '';

  constructor(private svc: AuditService) {}

  ngOnInit(): void {
    this.svc.getAllLogs().subscribe({
      next: d => { this.logs.set(d); this.filtered.set(d); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  applyFilter(): void {
    let r = this.logs();
    if (this.searchTerm) {
      const q = this.searchTerm.toLowerCase();
      r = r.filter(l =>
        l.action?.toLowerCase().includes(q) ||
        l.performedBy?.toLowerCase().includes(q) ||
        l.role?.toLowerCase().includes(q) ||
        l.details?.toLowerCase().includes(q)
      );
    }
    if (this.roleFilter) r = r.filter(l => l.role === this.roleFilter);
    this.filtered.set(r);
  }

  actionChip(action?: string): string {
    if (!action) return 'action-chip action-default';
    const a = action.toUpperCase();
    if (a.includes('CREATE') || a.includes('REGISTER') || a.includes('ADD')) return 'action-chip action-create';
    if (a.includes('UPDATE') || a.includes('EDIT') || a.includes('MODIFY')) return 'action-chip action-update';
    if (a.includes('DELETE') || a.includes('REMOVE') || a.includes('DEACTIVATE')) return 'action-chip action-delete';
    if (a.includes('LOGIN') || a.includes('LOGOUT') || a.includes('AUTH')) return 'action-chip action-login';
    return 'action-chip action-default';
  }

  formatTime(ts?: string): string {
    if (!ts) return '—';
    try { return new Date(ts).toLocaleString('en-IN', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }); }
    catch { return ts; }
  }
}
