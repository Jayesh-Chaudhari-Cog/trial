import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { UserService } from '../../services/api.services';
import { UserResponse, UserRequest, UserRole } from '../../models/models';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="User Management" subtitle="Manage platform users and roles" />

    <div class="page-content">
      <div class="page-header">
        <div>
          <h1 class="page-title">Users</h1>
          <p class="page-subtitle">{{ filtered().length }} of {{ users().length }} users</p>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="search-bar">
            <span class="search-icon">🔍</span>
            <input type="text" placeholder="Search by name or email…" [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()" />
          </div>
          <div class="flex gap-2">
            <select class="form-control" style="width:150px" [(ngModel)]="filterRole" (ngModelChange)="applyFilter()">
              <option value="">All Roles</option>
              <option *ngFor="let r of roles" [value]="r">{{ r }}</option>
            </select>
          </div>
        </div>

        @if (loading()) {
          <div class="loading-container"><span class="spinner"></span> Loading users…</div>
        } @else if (filtered().length === 0) {
          <div class="empty-state">
            <div class="empty-icon">👤</div>
            <h3>No users found</h3>
            <p>Try adjusting your search or filters.</p>
          </div>
        } @else {
          <div class="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @for (u of filtered(); track u.userId) {
                  <tr>
                    <td class="text-muted">{{ u.userId }}</td>
                    <td class="font-semibold">{{ u.name }}</td>
                    <td>{{ u.email }}</td>
                    <td>{{ u.phone }}</td>
                    <td><span class="badge badge-primary">{{ u.role }}</span></td>
                    <td>
                      <span class="badge" [class]="statusBadge(u.status)">{{ u.status }}</span>
                    </td>
                    <td>
                      <div class="flex gap-2">
                        <button class="btn btn-ghost btn-sm btn-icon" title="Edit" (click)="openEdit(u)">✏️</button>
                        <button class="btn btn-ghost btn-sm btn-icon" title="Deactivate" (click)="deactivate(u.userId)">🚫</button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>

    <!-- Edit Modal -->
    @if (editUser()) {
      <div class="modal-overlay" (click)="closeEdit()">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>Edit User #{{ editUser()!.userId }}</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="closeEdit()">✕</button>
          </div>
          <div class="modal-body">
            @if (saveMsg()) { <div class="alert alert-success mb-4">{{ saveMsg() }}</div> }
            @if (saveErr()) { <div class="alert alert-danger mb-4">{{ saveErr() }}</div> }
            <div class="form-group">
              <label class="form-label">Name</label>
              <input class="form-control" [(ngModel)]="editDto.name" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Email</label>
              <input class="form-control" type="email" [(ngModel)]="editDto.email" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Phone</label>
              <input class="form-control" [(ngModel)]="editDto.phone" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Role</label>
              <select class="form-control" [(ngModel)]="editDto.role">
                <option *ngFor="let r of roles" [value]="r">{{ r }}</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="closeEdit()">Cancel</button>
            <button class="btn btn-primary" (click)="saveEdit()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Save Changes
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class UsersComponent implements OnInit {
  users    = signal<UserResponse[]>([]);
  filtered = signal<UserResponse[]>([]);
  loading  = signal(true);
  editUser = signal<UserResponse | null>(null);
  saving   = signal(false);
  saveMsg  = signal('');
  saveErr  = signal('');
  searchTerm = '';
  filterRole = '';
  editDto: Partial<UserRequest> = {};
  roles: UserRole[] = ['FARMER','TRADER','OFFICER','MANAGER','ADMIN','COMPLIANCE','AUDITOR'];

  constructor(private svc: UserService) {}

  ngOnInit(): void {
    this.svc.getAll().subscribe({
      next: data => { this.users.set(data); this.filtered.set(data); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  applyFilter(): void {
    let res = this.users();
    if (this.searchTerm) {
      const q = this.searchTerm.toLowerCase();
      res = res.filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
    }
    if (this.filterRole) res = res.filter(u => u.role === this.filterRole);
    this.filtered.set(res);
  }

  openEdit(u: UserResponse): void {
    this.editUser.set(u);
    this.editDto = { name: u.name, email: u.email, phone: u.phone, role: u.role };
    this.saveMsg.set(''); this.saveErr.set('');
  }

  closeEdit(): void { this.editUser.set(null); }

  saveEdit(): void {
    const u = this.editUser();
    if (!u) return;
    this.saving.set(true); this.saveErr.set('');
    this.svc.update(u.userId, this.editDto as UserRequest).subscribe({
      next: updated => {
        const list = this.users().map(x => x.userId === updated.userId ? updated : x);
        this.users.set(list); this.applyFilter();
        this.saveMsg.set('Saved!');
        this.saving.set(false);
        setTimeout(() => this.closeEdit(), 1000);
      },
      error: () => { this.saveErr.set('Save failed.'); this.saving.set(false); }
    });
  }

  deactivate(id: number): void {
    if (!confirm('Deactivate this user?')) return;
    this.svc.deactivate(id).subscribe({
      next: () => {
        this.users.set(this.users().filter(u => u.userId !== id));
        this.applyFilter();
      }
    });
  }

  statusBadge(s: string): string {
    return s === 'ACTIVE' ? 'badge badge-success' : s === 'INACTIVE' ? 'badge badge-neutral' : 'badge badge-danger';
  }
}
