import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { AuthService } from '../../core/auth.service';
import { UserService } from '../../services/api.services';
import { FarmerService } from '../../services/api.services';
import { MarketService } from '../../services/api.services';
import { SubsidyService } from '../../services/api.services';
import { AuditService } from '../../services/api.services';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent],
  template: `
    <app-topbar title="Dashboard" [subtitle]="greeting()" />

    <div class="page-content">
      <!-- Stats Grid -->
      <div class="grid-4 mb-4">
        @for (stat of stats(); track stat.label) {
          <div class="stat-card">
            <div class="stat-icon" [style.background]="stat.bg">{{ stat.icon }}</div>
            <div class="stat-value">{{ stat.value ?? '—' }}</div>
            <div class="stat-label">{{ stat.label }}</div>
          </div>
        }
      </div>

      <!-- Quick Access -->
      <div class="grid-2">
        <div class="card">
          <div class="card-header">
            <h3>Quick Actions</h3>
          </div>
          <div class="card-body">
            <div class="quick-actions">
              @for (qa of quickActions(); track qa.label) {
                <a class="quick-action-item" [routerLink]="qa.route">
                  <span class="qa-icon">{{ qa.icon }}</span>
                  <div>
                    <div class="qa-label">{{ qa.label }}</div>
                    <div class="qa-desc">{{ qa.desc }}</div>
                  </div>
                </a>
              }
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <h3>System Overview</h3>
          </div>
          <div class="card-body">
            <div class="system-rows">
              <div class="sys-row">
                <span class="sys-label">🔒 Logged in as</span>
                <span class="sys-val">{{ email() }}</span>
              </div>
              <div class="sys-row">
                <span class="sys-label">🎭 Role</span>
                <span class="badge badge-primary">{{ role() }}</span>
              </div>
              <div class="sys-row">
                <span class="sys-label">🌐 API Gateway</span>
                <span class="badge badge-success">localhost:8090</span>
              </div>
              <div class="sys-row">
                <span class="sys-label">📅 Today</span>
                <span class="sys-val">{{ today }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .quick-actions { display: flex; flex-direction: column; gap: 0.5rem; }
    .quick-action-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 0.875rem;
      border-radius: var(--radius-md);
      border: 1px solid var(--color-border);
      text-decoration: none;
      color: var(--color-text-primary);
      transition: all 0.15s ease;
      &:hover { border-color: var(--color-primary); background: rgba(26,77,46,0.04); }
    }
    .qa-icon { font-size: 1.5rem; line-height: 1; }
    .qa-label { font-size: 0.9375rem; font-weight: 600; }
    .qa-desc  { font-size: 0.8125rem; color: var(--color-text-secondary); }

    .system-rows { display: flex; flex-direction: column; gap: 0.875rem; }
    .sys-row { display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; }
    .sys-label { font-size: 0.9375rem; color: var(--color-text-secondary); }
    .sys-val { font-size: 0.9375rem; font-weight: 500; text-align: right; }
  `]
})
export class DashboardComponent implements OnInit {
  role  = computed(() => this.auth.getRole());
  email = computed(() => this.auth.getEmail());
  greeting = computed(() => {
    const h = new Date().getHours();
    const prefix = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
    return `${prefix}, ${this.email().split('@')[0]}`;
  });

  today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  stats = signal([
    { label: 'Total Users',    value: null as number | null, icon: '👥', bg: 'rgba(37,99,235,0.12)' },
    { label: 'Farmers',        value: null as number | null, icon: '🧑‍🌾', bg: 'rgba(26,77,46,0.12)' },
    { label: 'Crop Listings',  value: null as number | null, icon: '🌽', bg: 'rgba(245,158,11,0.12)' },
    { label: 'Subsidy Programs', value: null as number | null, icon: '💰', bg: 'rgba(22,163,74,0.12)' },
  ]);

  quickActions = computed(() => {
    const role = this.auth.getRole();
    const all = [
      { icon: '🌽', label: 'Crop Market',       desc: 'View listings & place orders',   route: '/market',  roles: [] as string[] },
      { icon: '🧑‍🌾', label: 'Manage Farmers',   desc: 'Register and verify farmers',    route: '/farmers', roles: [] as string[] },
      { icon: '💰', label: 'Subsidy Programs',  desc: 'Apply or manage disbursements',  route: '/subsidy', roles: [] as string[] },
      { icon: '📋', label: 'Audit & Compliance', desc: 'Schedules and compliance checks', route: '/audit', roles: ['ADMIN','MANAGER','AUDITOR','COMPLIANCE','OFFICER'] },
      { icon: '📊', label: 'Reports',           desc: 'Generate analytical reports',    route: '/reports', roles: ['ADMIN','MANAGER','AUDITOR','OFFICER'] },
    ];
    return all.filter(a => a.roles.length === 0 || a.roles.includes(role));
  });

  constructor(
    private auth: AuthService,
    private userService: UserService,
    private farmerService: FarmerService,
    private marketService: MarketService,
    private subsidyService: SubsidyService
  ) {}

  ngOnInit(): void {
    const role = this.auth.getRole();
    const update = (idx: number, v: number) => {
      const s = [...this.stats()];
      s[idx] = { ...s[idx], value: v };
      this.stats.set(s);
    };

    if (['ADMIN','MANAGER','OFFICER','AUDITOR'].includes(role)) {
      this.userService.getAll().subscribe({ next: r => update(0, r.length), error: () => {} });
    }
    this.farmerService.getAll().subscribe({ next: r => update(1, r.length), error: () => {} });
    this.marketService.getAllListings().subscribe({ next: r => update(2, r.length), error: () => {} });
    this.subsidyService.getAllPrograms().subscribe({ next: r => update(3, r.length), error: () => {} });
  }
}
