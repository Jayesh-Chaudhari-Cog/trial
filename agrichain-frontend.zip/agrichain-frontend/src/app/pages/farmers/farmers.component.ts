import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { FarmerService } from '../../services/api.services';
import { Farmer } from '../../models/models';

@Component({
  selector: 'app-farmers',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Farmers" subtitle="Register and manage farmer profiles" />

    <div class="page-content">
      <div class="page-header">
        <div>
          <h1 class="page-title">Farmers</h1>
          <p class="page-subtitle">{{ filtered().length }} records</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">＋ Register Farmer</button>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="search-bar">
            <span class="search-icon">🔍</span>
            <input type="text" placeholder="Search farmers…" [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()" />
          </div>
          <select class="form-control" style="width:160px" [(ngModel)]="filterStatus" (ngModelChange)="applyFilter()">
            <option value="">All Status</option>
            <option value="PENDING">PENDING</option>
            <option value="APPROVED">APPROVED</option>
            <option value="REJECTED">REJECTED</option>
          </select>
        </div>

        @if (loading()) {
          <div class="loading-container"><span class="spinner"></span> Loading…</div>
        } @else if (filtered().length === 0) {
          <div class="empty-state">
            <div class="empty-icon">🧑‍🌾</div>
            <h3>No farmers found</h3>
            <p>Register the first farmer using the button above.</p>
          </div>
        } @else {
          <div class="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Name</th><th>Email</th><th>Phone</th>
                  <th>State</th><th>Land (Acres)</th><th>Status</th><th>Verified</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @for (f of filtered(); track f.farmerId) {
                  <tr>
                    <td class="text-muted">{{ f.farmerId }}</td>
                    <td class="font-semibold">{{ f.fullName }}</td>
                    <td>{{ f.email }}</td>
                    <td>{{ f.phone }}</td>
                    <td>{{ f.state || '—' }}</td>
                    <td>{{ f.landHoldingAcres ?? '—' }}</td>
                    <td><span class="badge" [class]="statusBadge(f.status)">{{ f.status }}</span></td>
                    <td><span class="badge" [class]="verifyBadge(f.verificationStatus)">{{ f.verificationStatus }}</span></td>
                    <td>
                      <div class="flex gap-2">
                        <button class="btn btn-ghost btn-sm btn-icon" (click)="openEdit(f)">✏️</button>
                        <button class="btn btn-ghost btn-sm btn-icon" (click)="deleteFarmer(f.farmerId!)">🗑️</button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>

    <!-- Create/Edit Modal -->
    @if (showModal()) {
      <div class="modal-overlay" (click)="closeModal()">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>{{ isEditing() ? 'Edit Farmer' : 'Register New Farmer' }}</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="closeModal()">✕</button>
          </div>
          <div class="modal-body">
            @if (errMsg()) { <div class="alert alert-danger mb-4">{{ errMsg() }}</div> }
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input class="form-control" [(ngModel)]="dto.fullName" />
              </div>
              <div class="form-group">
                <label class="form-label">Gender</label>
                <select class="form-control" [(ngModel)]="dto.gender">
                  <option value="">Select…</option>
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Email *</label>
                <input class="form-control" type="email" [(ngModel)]="dto.email" />
              </div>
              <div class="form-group">
                <label class="form-label">Phone *</label>
                <input class="form-control" [(ngModel)]="dto.phone" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">State</label>
                <input class="form-control" [(ngModel)]="dto.state" placeholder="Tamil Nadu" />
              </div>
              <div class="form-group">
                <label class="form-label">Pin Code</label>
                <input class="form-control" [(ngModel)]="dto.pinCode" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Land Holding (Acres)</label>
                <input class="form-control" type="number" [(ngModel)]="dto.landHoldingAcres" min="0" />
              </div>
              <div class="form-group">
                <label class="form-label">Date of Birth</label>
                <input class="form-control" type="date" [(ngModel)]="dto.dateOfBirth" />
              </div>
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Address</label>
              <input class="form-control" [(ngModel)]="dto.address" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="closeModal()">Cancel</button>
            <button class="btn btn-primary" (click)="saveModal()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> }
              {{ isEditing() ? 'Save Changes' : 'Register' }}
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class FarmersComponent implements OnInit {
  farmers  = signal<Farmer[]>([]);
  filtered = signal<Farmer[]>([]);
  loading  = signal(true);
  showModal = signal(false);
  isEditing = signal(false);
  saving   = signal(false);
  errMsg   = signal('');
  searchTerm = '';
  filterStatus = '';
  dto: Partial<Farmer> = {};
  editId: number | null = null;

  constructor(private svc: FarmerService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.svc.getAll().subscribe({
      next: d => { this.farmers.set(d); this.applyFilter(); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  applyFilter(): void {
    let r = this.farmers();
    if (this.searchTerm) {
      const q = this.searchTerm.toLowerCase();
      r = r.filter(f => f.fullName?.toLowerCase().includes(q) || f.email?.toLowerCase().includes(q));
    }
    if (this.filterStatus) r = r.filter(f => f.status === this.filterStatus);
    this.filtered.set(r);
  }

  openCreate(): void { this.dto = {}; this.isEditing.set(false); this.errMsg.set(''); this.showModal.set(true); }
  openEdit(f: Farmer): void {
    this.dto = { ...f }; this.editId = f.farmerId ?? null;
    this.isEditing.set(true); this.errMsg.set(''); this.showModal.set(true);
  }
  closeModal(): void { this.showModal.set(false); }

  saveModal(): void {
    if (!this.dto.fullName || !this.dto.email || !this.dto.phone) {
      this.errMsg.set('Name, Email and Phone are required.'); return;
    }
    this.saving.set(true); this.errMsg.set('');
    const obs = this.isEditing()
      ? this.svc.update(this.editId!, this.dto as Farmer)
      : this.svc.create(this.dto as Farmer);
    obs.subscribe({
      next: () => { this.saving.set(false); this.closeModal(); this.load(); },
      error: () => { this.errMsg.set('Operation failed. Please try again.'); this.saving.set(false); }
    });
  }

  deleteFarmer(id: number): void {
    if (!confirm('Delete this farmer?')) return;
    this.svc.delete(id).subscribe({ next: () => this.load() });
  }

  statusBadge(s?: string): string {
    return s === 'APPROVED' ? 'badge badge-success' : s === 'REJECTED' ? 'badge badge-danger' : 'badge badge-warning';
  }
  verifyBadge(v?: string): string {
    return v === 'VERIFIED' ? 'badge badge-success' : v === 'REJECTED' ? 'badge badge-danger' : 'badge badge-neutral';
  }
}
