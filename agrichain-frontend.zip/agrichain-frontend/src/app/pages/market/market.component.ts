import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { MarketService } from '../../services/api.services';
import { CropListing, Order, CropListingStatus, OrderStatus } from '../../models/models';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-market',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Crop Market" subtitle="Listings, orders and trade management" />

    <div class="page-content">
      <!-- Tab Bar -->
      <div class="tab-bar">
        <button class="tab-btn" [class.active]="tab() === 'listings'" (click)="tab.set('listings')">
          🌽 Crop Listings
        </button>
        <button class="tab-btn" [class.active]="tab() === 'orders'" (click)="tab.set('orders')">
          📦 Orders
        </button>
      </div>

      <!-- ─── LISTINGS TAB ─── -->
      @if (tab() === 'listings') {
        <div class="page-header">
          <div>
            <h2 class="page-title">Crop Listings</h2>
            <p class="page-subtitle">{{ listings().length }} total listings</p>
          </div>
          <button class="btn btn-primary" (click)="openCreateListing()">＋ New Listing</button>
        </div>

        <div class="card">
          <div class="card-header">
            <div class="search-bar">
              <span class="search-icon">🔍</span>
              <input type="text" placeholder="Search crop…" [(ngModel)]="listingSearch" (ngModelChange)="filterListings()" />
            </div>
            <select class="form-control" style="width:160px" [(ngModel)]="listingStatusFilter" (ngModelChange)="filterListings()">
              <option value="">All Status</option>
              <option value="PENDING">PENDING</option>
              <option value="APPROVED">APPROVED</option>
              <option value="REJECTED">REJECTED</option>
              <option value="SOLD">SOLD</option>
            </select>
          </div>

          @if (loadingListings()) {
            <div class="loading-container"><span class="spinner"></span> Loading listings…</div>
          } @else if (filteredListings().length === 0) {
            <div class="empty-state"><div class="empty-icon">🌽</div><h3>No listings found</h3></div>
          } @else {
            <div class="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>ID</th><th>Farmer ID</th><th>Crop</th><th>Variety</th>
                    <th>Qty (kg)</th><th>Price/kg</th><th>Location</th><th>Status</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @for (l of filteredListings(); track l.listingId) {
                    <tr>
                      <td class="text-muted">{{ l.listingId }}</td>
                      <td>{{ l.farmerId }}</td>
                      <td class="font-semibold">{{ l.cropName }}</td>
                      <td>{{ l.variety || '—' }}</td>
                      <td>{{ l.quantityKg }}</td>
                      <td>₹{{ l.pricePerKg }}</td>
                      <td>{{ l.location || '—' }}</td>
                      <td><span class="badge" [class]="listingBadge(l.status)">{{ l.status }}</span></td>
                      <td>
                        <div class="flex gap-2">
                          @if (l.status === 'PENDING' && canValidate()) {
                            <button class="btn btn-sm btn-outline" (click)="validate(l.listingId!)">✅ Validate</button>
                          }
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="openOrderFromListing(l)">📦</button>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }

      <!-- ─── ORDERS TAB ─── -->
      @if (tab() === 'orders') {
        <div class="page-header">
          <div>
            <h2 class="page-title">Orders</h2>
            <p class="page-subtitle">{{ orders().length }} total orders</p>
          </div>
          <button class="btn btn-primary" (click)="openCreateOrder()">＋ Place Order</button>
        </div>

        <div class="card">
          @if (loadingOrders()) {
            <div class="loading-container"><span class="spinner"></span> Loading orders…</div>
          } @else if (orders().length === 0) {
            <div class="empty-state"><div class="empty-icon">📦</div><h3>No orders yet</h3></div>
          } @else {
            <div class="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Order ID</th><th>Listing ID</th><th>Trader ID</th>
                    <th>Qty (kg)</th><th>Total Price</th><th>Status</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @for (o of orders(); track o.orderId) {
                    <tr>
                      <td class="text-muted">{{ o.orderId }}</td>
                      <td>{{ o.listingId }}</td>
                      <td>{{ o.traderId }}</td>
                      <td>{{ o.quantityOrdered }}</td>
                      <td>{{ o.totalPrice ? '₹' + o.totalPrice : '—' }}</td>
                      <td><span class="badge" [class]="orderBadge(o.status)">{{ o.status }}</span></td>
                      <td>
                        <select class="form-control" style="width:130px;font-size:0.8125rem"
                                [ngModel]="o.status" (ngModelChange)="updateStatus(o.orderId!, $event)">
                          <option value="PLACED">PLACED</option>
                          <option value="CONFIRMED">CONFIRMED</option>
                          <option value="SHIPPED">SHIPPED</option>
                          <option value="DELIVERED">DELIVERED</option>
                          <option value="CANCELLED">CANCELLED</option>
                        </select>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }
    </div>

    <!-- Create Listing Modal -->
    @if (showListingModal()) {
      <div class="modal-overlay" (click)="showListingModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>New Crop Listing</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showListingModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (listingErr()) { <div class="alert alert-danger mb-4">{{ listingErr() }}</div> }
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Farmer ID *</label>
                <input class="form-control" type="number" [(ngModel)]="listingDto.farmerId" />
              </div>
              <div class="form-group">
                <label class="form-label">Crop Name *</label>
                <input class="form-control" [(ngModel)]="listingDto.cropName" placeholder="Rice, Wheat…" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Variety</label>
                <input class="form-control" [(ngModel)]="listingDto.variety" />
              </div>
              <div class="form-group">
                <label class="form-label">Quantity (kg) *</label>
                <input class="form-control" type="number" [(ngModel)]="listingDto.quantityKg" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Price per kg (₹) *</label>
                <input class="form-control" type="number" [(ngModel)]="listingDto.pricePerKg" />
              </div>
              <div class="form-group">
                <label class="form-label">Location</label>
                <input class="form-control" [(ngModel)]="listingDto.location" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Harvest Date</label>
                <input class="form-control" type="date" [(ngModel)]="listingDto.harvestDate" />
              </div>
              <div class="form-group">
                <label class="form-label">Available From</label>
                <input class="form-control" type="date" [(ngModel)]="listingDto.availableFrom" />
              </div>
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Description</label>
              <input class="form-control" [(ngModel)]="listingDto.description" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showListingModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitListing()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Create Listing
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Create Order Modal -->
    @if (showOrderModal()) {
      <div class="modal-overlay" (click)="showOrderModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>Place Order</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showOrderModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (orderErr()) { <div class="alert alert-danger mb-4">{{ orderErr() }}</div> }
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Listing ID *</label>
                <input class="form-control" type="number" [(ngModel)]="orderDto.listingId" />
              </div>
              <div class="form-group">
                <label class="form-label">Trader ID *</label>
                <input class="form-control" type="number" [(ngModel)]="orderDto.traderId" />
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Quantity (kg) *</label>
                <input class="form-control" type="number" [(ngModel)]="orderDto.quantityOrdered" />
              </div>
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Delivery Address</label>
              <input class="form-control" [(ngModel)]="orderDto.deliveryAddress" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showOrderModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitOrder()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Place Order
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .tab-bar {
      display: flex;
      gap: 0.25rem;
      margin-bottom: 1.5rem;
      background: var(--color-surface);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-lg);
      padding: 0.375rem;
      width: fit-content;
    }
    .tab-btn {
      padding: 0.5rem 1.25rem;
      border-radius: var(--radius-md);
      border: none;
      background: transparent;
      font-family: var(--font-sans);
      font-size: 0.9375rem;
      font-weight: 500;
      color: var(--color-text-secondary);
      cursor: pointer;
      transition: all 0.15s ease;
      &.active { background: var(--color-primary); color: white; }
      &:not(.active):hover { background: var(--color-surface-2); }
    }
  `]
})
export class MarketComponent implements OnInit {
  tab = signal<'listings'|'orders'>('listings');
  listings = signal<CropListing[]>([]);
  filteredListings = signal<CropListing[]>([]);
  orders = signal<Order[]>([]);
  loadingListings = signal(true);
  loadingOrders = signal(true);
  saving = signal(false);
  showListingModal = signal(false);
  showOrderModal = signal(false);
  listingErr = signal('');
  orderErr = signal('');
  listingSearch = '';
  listingStatusFilter = '';
  listingDto: Partial<CropListing> = {};
  orderDto: Partial<Order> = {};

  constructor(private svc: MarketService, private auth: AuthService) {}

  ngOnInit(): void {
    this.loadListings();
    this.loadOrders();
  }

  loadListings(): void {
    this.svc.getAllListings().subscribe({
      next: d => { this.listings.set(d); this.filteredListings.set(d); this.loadingListings.set(false); },
      error: () => this.loadingListings.set(false)
    });
  }

  loadOrders(): void {
    this.svc.getAllOrders().subscribe({
      next: d => { this.orders.set(d); this.loadingOrders.set(false); },
      error: () => this.loadingOrders.set(false)
    });
  }

  filterListings(): void {
    let r = this.listings();
    if (this.listingSearch) {
      const q = this.listingSearch.toLowerCase();
      r = r.filter(l => l.cropName?.toLowerCase().includes(q) || l.location?.toLowerCase().includes(q));
    }
    if (this.listingStatusFilter) r = r.filter(l => l.status === this.listingStatusFilter);
    this.filteredListings.set(r);
  }

  canValidate(): boolean { return this.auth.hasRole('ADMIN','MANAGER','OFFICER'); }

  validate(id: number): void {
    this.svc.validateListing(id).subscribe({ next: () => this.loadListings() });
  }

  openCreateListing(): void { this.listingDto = {}; this.listingErr.set(''); this.showListingModal.set(true); }

  submitListing(): void {
    if (!this.listingDto.farmerId || !this.listingDto.cropName || !this.listingDto.quantityKg || !this.listingDto.pricePerKg) {
      this.listingErr.set('Please fill all required fields.'); return;
    }
    this.saving.set(true);
    this.svc.createListing(this.listingDto as CropListing).subscribe({
      next: () => { this.saving.set(false); this.showListingModal.set(false); this.loadListings(); },
      error: () => { this.listingErr.set('Failed to create listing.'); this.saving.set(false); }
    });
  }

  openCreateOrder(): void { this.orderDto = {}; this.orderErr.set(''); this.showOrderModal.set(true); }
  openOrderFromListing(l: CropListing): void {
    this.orderDto = { listingId: l.listingId }; this.orderErr.set(''); this.showOrderModal.set(true);
  }

  submitOrder(): void {
    if (!this.orderDto.listingId || !this.orderDto.traderId || !this.orderDto.quantityOrdered) {
      this.orderErr.set('Fill all required fields.'); return;
    }
    this.saving.set(true);
    this.svc.placeOrder(this.orderDto as Order).subscribe({
      next: () => { this.saving.set(false); this.showOrderModal.set(false); this.loadOrders(); tab: this.tab.set('orders'); },
      error: () => { this.orderErr.set('Failed to place order.'); this.saving.set(false); }
    });
  }

  updateStatus(id: number, status: string): void {
    this.svc.updateOrderStatus(id, status).subscribe({ next: () => this.loadOrders() });
  }

  listingBadge(s?: string): string {
    return s === 'APPROVED' ? 'badge badge-success' : s === 'REJECTED' ? 'badge badge-danger' : s === 'SOLD' ? 'badge badge-info' : 'badge badge-warning';
  }
  orderBadge(s?: string): string {
    return s === 'DELIVERED' ? 'badge badge-success' : s === 'CANCELLED' ? 'badge badge-danger' : s === 'PLACED' ? 'badge badge-warning' : 'badge badge-info';
  }
}
