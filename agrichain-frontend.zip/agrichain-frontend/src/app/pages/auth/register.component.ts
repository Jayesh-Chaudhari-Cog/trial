import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { UserRole } from '../../models/models';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-shell">
      <div class="auth-left">
        <div class="auth-brand">
          <div class="hero-icon">🌾</div>
          <h1 class="hero-heading display-heading">Join AgriChain</h1>
          <p class="hero-sub">Create your account to access the agricultural supply chain platform.</p>
        </div>
      </div>

      <div class="auth-right">
        <div class="auth-card">
          <div class="auth-card-header">
            <h2>Create Account</h2>
            <p>Fill in your details to get started</p>
          </div>

          @if (successMsg()) {
            <div class="alert alert-success" style="margin-bottom:1rem">✅ {{ successMsg() }}</div>
          }
          @if (errorMsg()) {
            <div class="alert alert-danger" style="margin-bottom:1rem">⚠️ {{ errorMsg() }}</div>
          }

          <form (ngSubmit)="onRegister()" #form="ngForm">
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Full Name</label>
                <input class="form-control" type="text" [(ngModel)]="dto.name" name="name" placeholder="John Doe" required />
              </div>
              <div class="form-group">
                <label class="form-label">Role</label>
                <select class="form-control" [(ngModel)]="dto.role" name="role" required>
                  <option value="">Select role…</option>
                  <option *ngFor="let r of roles" [value]="r">{{ r }}</option>
                </select>
              </div>
            </div>

            <div class="form-group mt-3">
              <label class="form-label">Email Address</label>
              <input class="form-control" type="email" [(ngModel)]="dto.email" name="email" placeholder="you@example.com" required />
            </div>

            <div class="form-group mt-3">
              <label class="form-label">Phone Number</label>
              <input class="form-control" type="tel" [(ngModel)]="dto.phone" name="phone" placeholder="9876543210" required />
            </div>

            <div class="form-group mt-3">
              <label class="form-label">Password</label>
              <input class="form-control" type="password" [(ngModel)]="dto.password" name="password" placeholder="Min. 8 characters" required />
            </div>

            <button class="btn btn-primary btn-lg w-full mt-4" type="submit" [disabled]="loading()">
              @if (loading()) { <span class="spinner"></span> }
              {{ loading() ? 'Creating account…' : 'Create Account' }}
            </button>
          </form>

          <p class="auth-switch">
            Already have an account? <a routerLink="/login">Sign in →</a>
          </p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-shell { display: flex; min-height: 100vh; }
    .auth-left {
      flex: 1;
      background: var(--color-primary-dark);
      padding: 3rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .auth-brand {
      .hero-icon { font-size: 3rem; margin-bottom: 1rem; }
      .hero-heading { font-size: 3rem; color: white; line-height: 1.1; margin-bottom: 0.75rem; }
      .hero-sub { font-size: 1.0625rem; color: rgba(255,255,255,0.55); max-width: 320px; line-height: 1.6; }
    }
    .auth-right { width: 520px; display: flex; align-items: center; justify-content: center; padding: 2rem; background: var(--color-bg); }
    .auth-card { width: 100%; max-width: 420px; }
    .auth-card-header { margin-bottom: 2rem;
      h2 { font-size: 1.625rem; font-weight: 700; }
      p  { font-size: 0.9375rem; color: var(--color-text-secondary); margin-top: 0.25rem; }
    }
    .auth-switch { margin-top: 1.5rem; text-align: center; font-size: 0.9375rem; color: var(--color-text-secondary); a { color: var(--color-primary); font-weight: 600; } }
    @media (max-width: 768px) { .auth-shell { flex-direction: column; } .auth-left { padding: 2rem; } .auth-right { width: 100%; } }
  `]
})
export class RegisterComponent {
  dto: any = { name: '', email: '', phone: '', password: '', role: '' };
  loading = signal(false);
  errorMsg = signal('');
  successMsg = signal('');
  roles: UserRole[] = ['FARMER', 'TRADER', 'OFFICER', 'MANAGER', 'ADMIN', 'COMPLIANCE', 'AUDITOR'];

  constructor(private auth: AuthService, private router: Router) {}

  onRegister(): void {
    this.errorMsg.set('');
    this.loading.set(true);
    this.auth.register({ ...this.dto, status: 'ACTIVE' })
      .subscribe({
        next: () => {
          this.successMsg.set('Account created! Redirecting to login…');
          setTimeout(() => this.router.navigate(['/login']), 1500);
        },
        error: (err) => {
          this.errorMsg.set(err?.error || 'Registration failed. Please try again.');
          this.loading.set(false);
        }
      });
  }
}
