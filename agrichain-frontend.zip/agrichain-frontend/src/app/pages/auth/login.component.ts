import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-shell">
      <div class="auth-left">
        <div class="auth-brand">
          <div class="hero-icon">🌾</div>
          <h1 class="hero-heading display-heading">AgriChain</h1>
          <p class="hero-sub">Agricultural Supply Chain Management Platform</p>
        </div>
        <div class="feature-list">
          <div class="feature" *ngFor="let f of features">
            <span class="feat-icon">{{ f.icon }}</span>
            <span>{{ f.text }}</span>
          </div>
        </div>
      </div>

      <div class="auth-right">
        <div class="auth-card">
          <div class="auth-card-header">
            <h2>Welcome back</h2>
            <p>Sign in to your account</p>
          </div>

          @if (errorMsg()) {
            <div class="alert alert-danger" style="margin-bottom:1rem">
              ⚠️ {{ errorMsg() }}
            </div>
          }

          <form (ngSubmit)="onLogin()" #form="ngForm">
            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input
                class="form-control"
                type="email"
                [(ngModel)]="email"
                name="email"
                placeholder="you@example.com"
                required
              />
            </div>

            <div class="form-group mt-3">
              <label class="form-label">Password</label>
              <div class="input-with-icon">
                <input
                  class="form-control"
                  [type]="showPw() ? 'text' : 'password'"
                  [(ngModel)]="password"
                  name="password"
                  placeholder="••••••••"
                  required
                />
                <button type="button" class="pw-toggle" (click)="showPw.set(!showPw())">
                  {{ showPw() ? '🙈' : '👁️' }}
                </button>
              </div>
            </div>

            <button class="btn btn-primary btn-lg w-full mt-4" type="submit" [disabled]="loading()">
              @if (loading()) { <span class="spinner"></span> }
              {{ loading() ? 'Signing in…' : 'Sign In' }}
            </button>
          </form>

          <p class="auth-switch">
            Don't have an account?
            <a routerLink="/register">Create one →</a>
          </p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-shell {
      display: flex;
      min-height: 100vh;
    }

    .auth-left {
      flex: 1;
      background: var(--color-primary-dark);
      padding: 3rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: relative;
      overflow: hidden;

      &::before {
        content: '';
        position: absolute;
        width: 400px; height: 400px;
        background: radial-gradient(circle, rgba(245,158,11,0.15) 0%, transparent 70%);
        top: -100px; right: -100px;
        border-radius: 50%;
      }
    }

    .auth-brand {
      margin-bottom: 2.5rem;

      .hero-icon { font-size: 3rem; margin-bottom: 1rem; }

      .hero-heading {
        font-size: 3rem;
        color: white;
        line-height: 1.1;
        margin-bottom: 0.75rem;
      }

      .hero-sub {
        font-size: 1.0625rem;
        color: rgba(255,255,255,0.55);
        max-width: 320px;
        line-height: 1.6;
      }
    }

    .feature-list {
      display: flex;
      flex-direction: column;
      gap: 0.875rem;
    }

    .feature {
      display: flex;
      align-items: center;
      gap: 0.875rem;
      color: rgba(255,255,255,0.7);
      font-size: 0.9375rem;

      .feat-icon {
        width: 36px; height: 36px;
        background: rgba(255,255,255,0.08);
        border-radius: var(--radius-md);
        display: flex; align-items: center; justify-content: center;
        font-size: 1rem;
        flex-shrink: 0;
      }
    }

    .auth-right {
      width: 480px;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      background: var(--color-bg);
    }

    .auth-card {
      width: 100%;
      max-width: 400px;
    }

    .auth-card-header {
      margin-bottom: 2rem;
      h2 { font-size: 1.625rem; font-weight: 700; color: var(--color-text-primary); }
      p  { font-size: 0.9375rem; color: var(--color-text-secondary); margin-top: 0.25rem; }
    }

    .input-with-icon { position: relative; }
    .pw-toggle {
      position: absolute;
      right: 0.75rem; top: 50%;
      transform: translateY(-50%);
      background: none; border: none;
      cursor: pointer; font-size: 1rem;
      line-height: 1;
    }

    .auth-switch {
      margin-top: 1.5rem;
      text-align: center;
      font-size: 0.9375rem;
      color: var(--color-text-secondary);

      a { color: var(--color-primary); font-weight: 600; }
    }

    @media (max-width: 768px) {
      .auth-shell { flex-direction: column; }
      .auth-left { padding: 2rem; }
      .auth-right { width: 100%; }
    }
  `]
})
export class LoginComponent {
  email = '';
  password = '';
  loading = signal(false);
  errorMsg = signal('');
  showPw = signal(false);

  features = [
    { icon: '🌽', text: 'Crop listing and order management' },
    { icon: '💰', text: 'Government subsidy tracking' },
    { icon: '📋', text: 'Compliance and audit workflows' },
    { icon: '📊', text: 'Real-time analytics reports' },
  ];

  constructor(private auth: AuthService, private router: Router) {}

  onLogin(): void {
    this.errorMsg.set('');
    if (!this.email || !this.password) { this.errorMsg.set('Please enter email and password.'); return; }
    this.loading.set(true);
    this.auth.login({ email: this.email, password: this.password })
      .subscribe({
        next: () => this.router.navigate(['/dashboard']),
        error: (err) => {
          this.errorMsg.set(err?.error || 'Invalid credentials. Please try again.');
          this.loading.set(false);
        }
      });
  }
}
