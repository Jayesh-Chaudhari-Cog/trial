import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/topbar.component';
import { AuditService } from '../../services/api.services';
import { Audit, Compliance } from '../../models/models';

@Component({
  selector: 'app-audit',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Audit & Compliance" subtitle="Track audits and compliance checks" />

    <div class="page-content">
      <div class="tab-bar">
        <button class="tab-btn" [class.active]="tab() === 'audits'" (click)="tab.set('audits')">📋 Audits</button>
        <button class="tab-btn" [class.active]="tab() === 'compliance'" (click)="tab.set('compliance')">✅ Compliance</button>
      </div>

      <!-- AUDITS -->
      @if (tab() === 'audits') {
        <div class="page-header">
          <div>
            <h2 class="page-title">Audits</h2>
            <p class="page-subtitle">{{ audits().length }} audits total</p>
          </div>
          <button class="btn btn-primary" (click)="openCreateAudit()">＋ Create Audit</button>
        </div>

        <!-- Filters -->
        <div class="flex gap-2 mb-4" style="flex-wrap:wrap">
          <select class="form-control" style="width:150px" [(ngModel)]="auditScopeFilter" (ngModelChange)="filterAudits()">
            <option value="">All Scopes</option>
            <option value="FINANCIAL">FINANCIAL</option>
            <option value="OPERATIONAL">OPERATIONAL</option>
            <option value="COMPLIANCE">COMPLIANCE</option>
            <option value="ENVIRONMENTAL">ENVIRONMENTAL</option>
          </select>
          <select class="form-control" style="width:160px" [(ngModel)]="auditStatusFilter" (ngModelChange)="filterAudits()">
            <option value="">All Status</option>
            <option value="SCHEDULED">SCHEDULED</option>
            <option value="IN_PROGRESS">IN PROGRESS</option>
            <option value="COMPLETED">COMPLETED</option>
            <option value="CANCELLED">CANCELLED</option>
          </select>
        </div>

        @if (loadingAudits()) {
          <div class="loading-container"><span class="spinner"></span> Loading audits…</div>
        } @else if (filteredAudits().length === 0) {
          <div class="empty-state"><div class="empty-icon">📋</div><h3>No audits found</h3></div>
        } @else {
          <div class="card">
            <div class="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>ID</th><th>Title</th><th>Scope</th><th>Status</th>
                    <th>Officer ID</th><th>Scheduled</th><th>Findings</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @for (a of filteredAudits(); track a.auditId) {
                    <tr>
                      <td class="text-muted">{{ a.auditId }}</td>
                      <td class="font-semibold">{{ a.title }}</td>
                      <td><span class="badge badge-info">{{ a.scope }}</span></td>
                      <td><span class="badge" [class]="auditStatusBadge(a.status)">{{ a.status }}</span></td>
                      <td>{{ a.officerId || '—' }}</td>
                      <td>{{ a.scheduledDate || '—' }}</td>
                      <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{ a.findings || '—' }}</td>
                      <td>
                        <div class="flex gap-2">
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="openEditAudit(a)">✏️</button>
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="viewCompliances(a)">📋</button>
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="deleteAudit(a.auditId!)">🗑️</button>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }
      }

      <!-- COMPLIANCE -->
      @if (tab() === 'compliance') {
        <div class="page-header">
          <div>
            <h2 class="page-title">Compliance Records</h2>
            <p class="page-subtitle">{{ compliances().length }} records</p>
          </div>
          <button class="btn btn-primary" (click)="openCreateCompliance()">＋ Add Compliance</button>
        </div>

        @if (loadingCompliances()) {
          <div class="loading-container"><span class="spinner"></span> Loading…</div>
        } @else if (compliances().length === 0) {
          <div class="empty-state"><div class="empty-icon">✅</div><h3>No compliance records</h3></div>
        } @else {
          <div class="card">
            <div class="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>ID</th><th>Audit ID</th><th>Type</th><th>Result</th>
                    <th>Description</th><th>Due Date</th><th>Remarks</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @for (c of compliances(); track c.complianceId) {
                    <tr>
                      <td class="text-muted">{{ c.complianceId }}</td>
                      <td>{{ c.auditId }}</td>
                      <td><span class="badge badge-primary">{{ c.complianceType }}</span></td>
                      <td><span class="badge" [class]="resultBadge(c.result)">{{ c.result }}</span></td>
                      <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{ c.description || '—' }}</td>
                      <td>{{ c.dueDate || '—' }}</td>
                      <td>{{ c.remarks || '—' }}</td>
                      <td>
                        <div class="flex gap-2">
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="openEditCompliance(c)">✏️</button>
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="deleteCompliance(c.complianceId!)">🗑️</button>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }
      }
    </div>

    <!-- Audit Modal -->
    @if (showAuditModal()) {
      <div class="modal-overlay" (click)="showAuditModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>{{ editingAudit ? 'Edit Audit' : 'Create Audit' }}</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showAuditModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (aErr()) { <div class="alert alert-danger mb-4">{{ aErr() }}</div> }
            <div class="form-group">
              <label class="form-label">Title *</label>
              <input class="form-control" [(ngModel)]="aDto.title" />
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Scope *</label>
                <select class="form-control" [(ngModel)]="aDto.scope">
                  <option value="">Select…</option>
                  <option value="FINANCIAL">FINANCIAL</option>
                  <option value="OPERATIONAL">OPERATIONAL</option>
                  <option value="COMPLIANCE">COMPLIANCE</option>
                  <option value="ENVIRONMENTAL">ENVIRONMENTAL</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Status *</label>
                <select class="form-control" [(ngModel)]="aDto.status">
                  <option value="">Select…</option>
                  <option value="SCHEDULED">SCHEDULED</option>
                  <option value="IN_PROGRESS">IN_PROGRESS</option>
                  <option value="COMPLETED">COMPLETED</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Officer ID</label>
                <input class="form-control" type="number" [(ngModel)]="aDto.officerId" />
              </div>
              <div class="form-group">
                <label class="form-label">Scheduled Date</label>
                <input class="form-control" type="date" [(ngModel)]="aDto.scheduledDate" />
              </div>
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Findings</label>
              <input class="form-control" [(ngModel)]="aDto.findings" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showAuditModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveAudit()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Save
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Compliance Modal -->
    @if (showComplianceModal()) {
      <div class="modal-overlay" (click)="showComplianceModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h3>{{ editingCompliance ? 'Edit Compliance' : 'Add Compliance' }}</h3>
            <button class="btn btn-ghost btn-sm btn-icon" (click)="showComplianceModal.set(false)">✕</button>
          </div>
          <div class="modal-body">
            @if (cErr()) { <div class="alert alert-danger mb-4">{{ cErr() }}</div> }
            <div class="form-group">
              <label class="form-label">Audit ID *</label>
              <input class="form-control" type="number" [(ngModel)]="cDto.auditId" />
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Type *</label>
                <select class="form-control" [(ngModel)]="cDto.complianceType">
                  <option value="">Select…</option>
                  <option value="REGULATORY">REGULATORY</option>
                  <option value="INTERNAL">INTERNAL</option>
                  <option value="EXTERNAL">EXTERNAL</option>
                  <option value="STATUTORY">STATUTORY</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Result *</label>
                <select class="form-control" [(ngModel)]="cDto.result">
                  <option value="">Select…</option>
                  <option value="COMPLIANT">COMPLIANT</option>
                  <option value="NON_COMPLIANT">NON_COMPLIANT</option>
                  <option value="PARTIAL">PARTIAL</option>
                  <option value="PENDING">PENDING</option>
                </select>
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group">
                <label class="form-label">Due Date</label>
                <input class="form-control" type="date" [(ngModel)]="cDto.dueDate" />
              </div>
              <div class="form-group">
                <label class="form-label">Closed Date</label>
                <input class="form-control" type="date" [(ngModel)]="cDto.closedDate" />
              </div>
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Description</label>
              <input class="form-control" [(ngModel)]="cDto.description" />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Remarks</label>
              <input class="form-control" [(ngModel)]="cDto.remarks" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showComplianceModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveCompliance()" [disabled]="saving()">
              @if (saving()) { <span class="spinner"></span> } Save
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .tab-bar { display: flex; gap: 0.25rem; margin-bottom: 1.5rem; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); padding: 0.375rem; width: fit-content; }
    .tab-btn { padding: 0.5rem 1.25rem; border-radius: var(--radius-md); border: none; background: transparent; font-family: var(--font-sans); font-size: 0.9375rem; font-weight: 500; color: var(--color-text-secondary); cursor: pointer; transition: all 0.15s ease; &.active { background: var(--color-primary); color: white; } &:not(.active):hover { background: var(--color-surface-2); } }
  `]
})
export class AuditComponent implements OnInit {
  tab = signal<'audits'|'compliance'>('audits');
  audits = signal<Audit[]>([]);
  filteredAudits = signal<Audit[]>([]);
  compliances = signal<Compliance[]>([]);
  loadingAudits = signal(true);
  loadingCompliances = signal(true);
  saving = signal(false);
  showAuditModal = signal(false);
  showComplianceModal = signal(false);
  editingAudit: Audit | null = null;
  editingCompliance: Compliance | null = null;
  aErr = signal('');
  cErr = signal('');
  auditScopeFilter = '';
  auditStatusFilter = '';
  aDto: Partial<Audit> = {};
  cDto: Partial<Compliance> = {};

  constructor(private svc: AuditService) {}

  ngOnInit(): void {
    this.loadAudits();
    this.loadCompliances();
  }

  loadAudits(): void {
    this.svc.getAllAudits().subscribe({
      next: d => { this.audits.set(d); this.filteredAudits.set(d); this.loadingAudits.set(false); },
      error: () => this.loadingAudits.set(false)
    });
  }

  loadCompliances(): void {
    this.svc.getAllCompliances().subscribe({
      next: d => { this.compliances.set(d); this.loadingCompliances.set(false); },
      error: () => this.loadingCompliances.set(false)
    });
  }

  filterAudits(): void {
    let r = this.audits();
    if (this.auditScopeFilter) r = r.filter(a => a.scope === this.auditScopeFilter);
    if (this.auditStatusFilter) r = r.filter(a => a.status === this.auditStatusFilter);
    this.filteredAudits.set(r);
  }

  openCreateAudit(): void { this.aDto = {}; this.editingAudit = null; this.aErr.set(''); this.showAuditModal.set(true); }
  openEditAudit(a: Audit): void { this.aDto = { ...a }; this.editingAudit = a; this.aErr.set(''); this.showAuditModal.set(true); }

  saveAudit(): void {
    if (!this.aDto.title || !this.aDto.scope || !this.aDto.status) { this.aErr.set('Fill required fields.'); return; }
    this.saving.set(true);
    const obs = this.editingAudit
      ? this.svc.updateAudit(this.editingAudit.auditId!, this.aDto as Audit)
      : this.svc.createAudit(this.aDto as Audit);
    obs.subscribe({
      next: () => { this.saving.set(false); this.showAuditModal.set(false); this.loadAudits(); },
      error: () => { this.aErr.set('Save failed.'); this.saving.set(false); }
    });
  }

  deleteAudit(id: number): void {
    if (!confirm('Delete this audit?')) return;
    this.svc.deleteAudit(id).subscribe({ next: () => this.loadAudits() });
  }

  viewCompliances(a: Audit): void {
    this.tab.set('compliance');
    this.svc.getCompliancesByAudit(a.auditId!).subscribe({ next: d => this.compliances.set(d) });
  }

  openCreateCompliance(): void { this.cDto = {}; this.editingCompliance = null; this.cErr.set(''); this.showComplianceModal.set(true); }
  openEditCompliance(c: Compliance): void { this.cDto = { ...c }; this.editingCompliance = c; this.cErr.set(''); this.showComplianceModal.set(true); }

  saveCompliance(): void {
    if (!this.cDto.auditId || !this.cDto.complianceType || !this.cDto.result) { this.cErr.set('Fill required fields.'); return; }
    this.saving.set(true);
    const obs = this.editingCompliance
      ? this.svc.updateCompliance(this.editingCompliance.complianceId!, this.cDto as Compliance)
      : this.svc.createCompliance(this.cDto.auditId!, this.cDto as Compliance);
    obs.subscribe({
      next: () => { this.saving.set(false); this.showComplianceModal.set(false); this.loadCompliances(); },
      error: () => { this.cErr.set('Save failed.'); this.saving.set(false); }
    });
  }

  deleteCompliance(id: number): void {
    if (!confirm('Delete this compliance record?')) return;
    this.svc.deleteCompliance(id).subscribe({ next: () => this.loadCompliances() });
  }

  auditStatusBadge(s?: string): string {
    return s === 'COMPLETED' ? 'badge badge-success' : s === 'CANCELLED' ? 'badge badge-danger' : s === 'IN_PROGRESS' ? 'badge badge-warning' : 'badge badge-info';
  }
  resultBadge(r?: string): string {
    return r === 'COMPLIANT' ? 'badge badge-success' : r === 'NON_COMPLIANT' ? 'badge badge-danger' : r === 'PARTIAL' ? 'badge badge-warning' : 'badge badge-neutral';
  }
}
