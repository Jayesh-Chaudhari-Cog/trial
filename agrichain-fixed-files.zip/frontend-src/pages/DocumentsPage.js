import React, { useState } from 'react';
import Layout from '../components/Layout';
import { documentsAPI } from '../services/api';

export default function DocumentsPage() {
  const [farmerId, setFarmerId] = useState('');
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modal, setModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  // Form uses actual file upload (multipart)
  const [form, setForm] = useState({ farmerId: '', docType: 'AADHAR', file: null });
  const [submitting, setSubmitting] = useState(false);

  const loadDocs = async () => {
    if (!farmerId) return;
    setLoading(true);
    setError('');
    try {
      const res = await documentsAPI.getByFarmer(farmerId);
      setDocuments(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load documents for this farmer');
      setDocuments([]);
    }
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.file) {
      setError('Please select a file to upload');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await documentsAPI.uploadDocument(form.farmerId, form.file, form.docType);
      setSuccess('Document uploaded successfully!');
      setModal(false);
      setForm({ farmerId: '', docType: 'AADHAR', file: null });
      if (farmerId === form.farmerId) loadDocs();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to upload document');
    }
    setSubmitting(false);
  };

  const docTypeIcon = (type) => {
    const map = { AADHAR: '🪪', PAN: '💳', LAND_DEED: '📜', BANK_PASSBOOK: '🏦', DRIVING_LICENSE: '🚗', LAND_RECORD: '🗺' };
    return map[type] || '📄';
  };

  const statusColor = (s) => {
    const map = { VERIFIED: 'badge-green', PENDING: 'badge-yellow', REJECTED: 'badge-red' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Documents" subtitle="Farmer document verification">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Document Management</div>
            <div className="page-subtitle">KYC & verification documents</div>
          </div>
          <button className="btn btn-primary" onClick={() => { setModal(true); setError(''); }}>+ Upload Document</button>
        </div>

        {/* Farmer lookup */}
        <div className="card mb-6">
          <div className="section-title">🔍 Search Documents by Farmer</div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', marginTop: 12 }}>
            <div className="form-group" style={{ flex: 1, maxWidth: 300 }}>
              <label className="form-label">Farmer ID</label>
              <input className="form-input" type="number" placeholder="Enter farmer ID..." value={farmerId}
                onChange={e => setFarmerId(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && loadDocs()} />
            </div>
            <button className="btn btn-outline" onClick={loadDocs} disabled={loading || !farmerId}>
              {loading ? 'Loading...' : 'Search'}
            </button>
          </div>
        </div>

        {documents.length > 0 && (
          <div className="grid-3">
            {documents.map(d => (
              <div key={d.documentId || d.id} className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <span style={{ fontSize: 32 }}>{docTypeIcon(d.docType)}</span>
                  <span className={`badge ${statusColor(d.verificationStatus || d.status)}`}>
                    {d.verificationStatus || d.status || 'PENDING'}
                  </span>
                </div>
                <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 4 }}>{d.docType}</div>
                <div style={{ fontSize: 12, color: 'var(--text3)', fontFamily: 'var(--mono)' }}>
                  {d.fileName || d.documentNumber || '—'}
                </div>
                {d.filePath && (
                  <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 8, wordBreak: 'break-all' }}>
                    📁 {d.filePath}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {documents.length === 0 && farmerId && !loading && !error && (
          <div className="empty-state">
            <div className="icon">📄</div>
            <h3>No documents found</h3>
            <p>Farmer #{farmerId} has no documents on record</p>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Upload Document</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Farmer ID</label>
                <input className="form-input" type="number" placeholder="Farmer ID" value={form.farmerId}
                  onChange={e => setForm(f => ({ ...f, farmerId: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Document Type</label>
                <select className="form-select" value={form.docType}
                  onChange={e => setForm(f => ({ ...f, docType: e.target.value }))}>
                  {['AADHAR', 'PAN', 'LAND_DEED', 'LAND_RECORD', 'BANK_PASSBOOK', 'DRIVING_LICENSE'].map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Select File</label>
                <input
                  className="form-input"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={e => setForm(f => ({ ...f, file: e.target.files[0] }))}
                  required
                />
                <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>
                  Accepted formats: PDF, JPG, PNG
                </div>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Uploading...' : 'Upload Document'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
