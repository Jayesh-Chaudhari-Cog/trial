import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { auditAPI } from '../services/api';

export default function AuditLogsPage() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [source, setSource] = useState('AUDIT');

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      let data = [];
      if (source === 'AUDIT') {
        // Audit-Compliance service: GET /api/auditlogs/all
        const res = await auditAPI.getAuditLogs();
        data = Array.isArray(res.data) ? res.data : [];
      } else {
        // Registration service: GET /api/logs/GetAllLogs (paginated)
        const res = await auditAPI.getRegistrationLogs(0, 100);
        // Paginated response has .content array
        data = Array.isArray(res.data?.content)
          ? res.data.content
          : Array.isArray(res.data)
          ? res.data
          : [];
      }
      setLogs(data);
    } catch (err) {
      setError('Failed to load audit logs');
      setLogs([]);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, [source]);

  const actionColor = (action) => {
    if (!action) return 'badge-gray';
    if (action.includes('DELETE') || action.includes('REMOVE')) return 'badge-red';
    if (action.includes('CREATE') || action.includes('REGISTER')) return 'badge-green';
    if (action.includes('UPDATE') || action.includes('EDIT')) return 'badge-yellow';
    if (action.includes('LOGIN') || action.includes('LOGOUT')) return 'badge-blue';
    return 'badge-gray';
  };

  const filtered = logs.filter(l =>
    !search ||
    (l.performedBy || '').toLowerCase().includes(search.toLowerCase()) ||
    (l.action || '').toLowerCase().includes(search.toLowerCase()) ||
    (l.details || l.resource || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout title="Audit Logs" subtitle="System activity & security log trail">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Audit Log Trail</div>
            <div className="page-subtitle">{filtered.length} of {logs.length} entries</div>
          </div>
          <button className="btn btn-outline" onClick={load}>↻ Refresh</button>
        </div>

        {/* Source & Search */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className={`btn btn-sm ${source === 'AUDIT' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setSource('AUDIT')}>Audit-Compliance Logs</button>
            <button className={`btn btn-sm ${source === 'REGISTRATION' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setSource('REGISTRATION')}>Registration Logs</button>
          </div>
          <input className="form-input" placeholder="🔍 Search by user, action, or details..." value={search}
            onChange={e => setSearch(e.target.value)} style={{ maxWidth: 350 }} />
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="icon">📋</div>
            <h3>No audit logs found</h3>
            <p>Activity logs will appear as users interact with the platform</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Performed By</th><th>Action</th><th>Role / Resource</th><th>Details</th><th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((log, idx) => (
                  <tr key={log.logId || log.id || idx}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{log.logId || log.id || idx + 1}</td>
                    <td style={{ fontWeight: 600, color: 'var(--text)' }}>{log.performedBy || '—'}</td>
                    <td><span className={`badge ${actionColor(log.action)}`}>{log.action || '—'}</span></td>
                    <td>
                      <span style={{ fontSize: 12, color: 'var(--text3)', fontFamily: 'var(--mono)' }}>
                        {log.role || log.resource || '—'}
                      </span>
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text3)', maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {log.details || '—'}
                    </td>
                    <td style={{ fontSize: 11, color: 'var(--text3)', fontFamily: 'var(--mono)', whiteSpace: 'nowrap' }}>
                      {log.timestamp ? new Date(log.timestamp).toLocaleString() : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Layout>
  );
}
