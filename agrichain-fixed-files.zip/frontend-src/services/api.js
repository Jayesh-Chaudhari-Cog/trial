import axios from 'axios';

// All requests go through API Gateway at port 8090
const API_BASE = 'http://localhost:8090';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ─── AUTH / USERS ───────────────────────────────────────────
export const authAPI = {
  register: (data) => api.post('/users/register', data),
  login: (data) => api.post('/users/login', data),
  getUser: (id) => api.get(`/users/${id}`),
  getAllUsers: () => api.get('/users'),
  updateUser: (id, data) => api.put(`/users/${id}`, data),
  deleteUser: (id) => api.delete(`/users/${id}`),
};

// ─── FARMERS ────────────────────────────────────────────────
export const farmersAPI = {
  register: (data) => api.post('/farmers', data),
  getAll: () => api.get('/farmers'),
  getById: (id) => api.get(`/farmers/${id}`),
  update: (id, data) => api.put(`/farmers/${id}`, data),
  delete: (id) => api.delete(`/farmers/${id}`),
};

// ─── DOCUMENTS ──────────────────────────────────────────────
// Backend: GET  /documents/farmer/{farmerId}
// Backend: GET  /documents/all
// Backend: POST /documents/farmer/{farmerId}/upload  (multipart/form-data)
// Backend: PATCH /documents/{documentId}/verify?status=...
export const documentsAPI = {
  getByFarmer: (farmerId) => api.get(`/documents/farmer/${farmerId}`),
  getAll: () => api.get('/documents/all'),
  uploadDocument: (farmerId, file, docType) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('docType', docType);
    return api.post(`/documents/farmer/${farmerId}/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  verifyDocument: (documentId, status) =>
    api.patch(`/documents/${documentId}/verify?status=${status}`),
};

// ─── CROP MARKET ────────────────────────────────────────────
export const marketAPI = {
  createListing: (data) => api.post('/market/createlisting', data),
  getAllListings: () => api.get('/market/listings'),
  getListingsByStatus: (status) => api.get(`/market/listings/status/${status}`),
  validateListing: (id) => api.put(`/market/listings/validate/${id}`),
  placeOrder: (data) => api.post('/market/placeorder', data),
  getAllOrders: () => api.get('/market/orders'),
  getOrdersByTrader: (traderId) => api.get(`/market/orders/trader/${traderId}`),
  getOrderById: (id) => api.get(`/market/orders/${id}`),
  updateOrderStatus: (id, status) => api.put(`/market/orders/${id}/status?status=${status}`),
};

// ─── TRANSACTIONS & PAYMENTS ────────────────────────────────
export const transactionAPI = {
  // POST /transactions/initiate  body: { orderId, amount }
  initiateTransaction: (data) => api.post('/transactions/initiate', data),
  // GET /transactions/status/{status}
  getByStatus: (status) => api.get(`/transactions/status/${status}`),
  // PUT /transactions/{id}/status?status=...
  updateStatus: (id, status) => api.put(`/transactions/${id}/status?status=${status}`),
  // PUT /transactions/{id}/finalize
  finalizeTransaction: (id) => api.put(`/transactions/${id}/finalize`),
  // POST /transactions/payment/record  body: { transactionId, method }
  recordPayment: (data) => api.post('/transactions/payment/record', data),
  // PUT /transactions/payment/callback/{paymentId}?status=...
  paymentCallback: (paymentId, status) =>
    api.put(`/transactions/payment/callback/${paymentId}?status=${status}`),
};

// ─── SUBSIDY ────────────────────────────────────────────────
export const subsidyAPI = {
  createProgram: (data) => api.post('/subsidy-programs', data),
  getAllPrograms: () => api.get('/subsidy-programs'),
  getProgramById: (id) => api.get(`/subsidy-programs/${id}`),
  updateProgram: (id, data) => api.put(`/subsidy-programs/${id}`, data),
  deleteProgram: (id) => api.delete(`/subsidy-programs/${id}`),
  getDisbursements: () => api.get('/disbursements'),
  createDisbursement: (data) => api.post('/disbursements', data),
  getDisbursementsByFarmer: (farmerId) => api.get(`/disbursements/farmer/${farmerId}`),
};

// ─── AUDIT & COMPLIANCE ─────────────────────────────────────
export const auditAPI = {
  createAudit: (data) => api.post('/api/audits/create', data),
  getAllAudits: () => api.get('/api/audits/all'),
  getAuditById: (id) => api.get(`/api/audits/${id}`),
  updateAudit: (id, data) => api.put(`/api/audits/${id}`, data),
  deleteAudit: (id) => api.delete(`/api/audits/${id}`),
  getAuditsByStatus: (status) => api.get(`/api/audits/status/${status}`),
  getAllCompliances: () => api.get('/api/compliances'),
  // FIXED: Audit-Compliance service serves GET /api/auditlogs/all (not /api/auditlogs)
  getAuditLogs: () => api.get('/api/auditlogs/all'),
  // Registration service logs: GET /api/logs/GetAllLogs
  getRegistrationLogs: (page = 0, size = 50) =>
    api.get(`/api/logs/GetAllLogs?page=${page}&size=${size}`),
};

// ─── REPORTS ────────────────────────────────────────────────
export const reportAPI = {
  generateReport: (data) => api.post('/api/report/generate', data),
  getAllReports: () => api.get('/api/report/all'),
  getReportById: (id) => api.get(`/api/report/${id}`),
  updateReport: (id, data) => api.put(`/api/report/update/${id}`, data),
  deleteReport: (id) => api.delete(`/api/report/delete/${id}`),
  getByScope: (scope) => api.get(`/api/report/scope/${scope}`),
  generateTransactionReport: (status) =>
    api.get(`/api/report/transactionsreport/${status}`),
};

export default api;
