# AgriChain — Frontend ↔ Backend Connection Fixes

## Summary of Issues Found & Fixed

---

## 🔴 Issue 1: Service Name Mismatches (Eureka / API Gateway)

**Problem:** The API Gateway routes traffic using `lb://SERVICE-NAME`, which matches the
`spring.application.name` property. Three services had lowercase names that didn't
match what the Gateway expected (uppercase).

| Service           | Was                  | Fixed To              |
|-------------------|----------------------|-----------------------|
| Croplisting-Order | `croplisting-service`| `CROPLISTING-SERVICE` |
| report-service    | `report-service`     | `REPORT-SERVICE`      |
| Transaction-Payment | `transaction-payment` | `TRANSACTION-PAYMENT` |

**Files Changed:**
- `Croplisting-Order/src/main/resources/application.properties`
- `report-service/src/main/resources/application.properties`
- `Transaction-Payment/src/main/resources/application.properties`

---

## 🔴 Issue 2: Missing Eureka Config in Croplisting-Order

**Problem:** `Croplisting-Order` was missing Eureka client registration config entirely.

**Fix Added** to `croplisting-order-application.properties`:
```properties
eureka.client.service-url.defaultZone=http://localhost:8761/eureka/
eureka.client.register-with-eureka=true
eureka.client.fetch-registry=true
```

---

## 🔴 Issue 3: Audit Logs Endpoint Mismatch

**Problem:** Frontend called `GET /api/auditlogs` but the Audit-Compliance backend
controller maps to `GET /api/auditlogs/all`.

**Fix in:** `frontend-src/services/api.js`
```js
// Before (broken):
getAuditLogs: () => api.get('/api/auditlogs'),

// After (fixed):
getAuditLogs: () => api.get('/api/auditlogs/all'),
```

Also added `getRegistrationLogs()` to access the Registration service's logs at
`GET /api/logs/GetAllLogs`.

---

## 🔴 Issue 4: Documents Endpoint Mismatch

**Problem:** The frontend `DocumentsPage.js` sent `POST /documents` with a JSON body
(`{ farmerId, docType, documentNumber, documentUrl }`), but the backend only accepts
`POST /documents/farmer/{farmerId}/upload` as **multipart/form-data** with an actual
file and docType query param. There is no JSON document creation endpoint.

**Fix in:** `frontend-src/pages/DocumentsPage.js`
- Replaced JSON form with actual file picker input
- Now uses `FormData` and sends file + docType correctly
- Added `documentsAPI` to `api.js` with correct endpoints

**Fix in:** `frontend-src/services/api.js`
- Added `documentsAPI` export with correct endpoints:
  ```js
  documentsAPI.getByFarmer(farmerId)        → GET /documents/farmer/{farmerId}
  documentsAPI.getAll()                      → GET /documents/all
  documentsAPI.uploadDocument(id, file, type)→ POST /documents/farmer/{id}/upload (multipart)
  documentsAPI.verifyDocument(docId, status) → PATCH /documents/{id}/verify?status=...
  ```

---

## 🔴 Issue 5: JWT Role Not Decoded After Login

**Problem:** After login, the frontend stored `role: 'USER'` for every user regardless
of their actual role, breaking all role-based UI logic.

**Fix in:** `frontend-src/pages/LoginPage.js`
- Added `decodeJwtPayload(token)` helper (no external library needed)
- Now reads `claims.role`, `claims.userRole`, or `claims.authorities[0]` from JWT
- Stores the actual role and email from the token claims

---

## 📁 Files Changed

### Frontend
| File | Change |
|------|--------|
| `src/services/api.js` | Fixed audit log endpoint, added `documentsAPI`, added `getRegistrationLogs` |
| `src/pages/LoginPage.js` | Added JWT decode to extract real role |
| `src/pages/DocumentsPage.js` | Changed to multipart file upload |
| `src/pages/AuditLogsPage.js` | Fixed to use `/api/auditlogs/all`, added source toggle |

### Backend (application.properties only)
| File | Change |
|------|--------|
| `Croplisting-Order/application.properties` | `spring.application.name=CROPLISTING-SERVICE` + Eureka config |
| `report-service/application.properties` | `spring.application.name=REPORT-SERVICE` |
| `Transaction-Payment/application.properties` | `spring.application.name=TRANSACTION-PAYMENT` |

---

## ✅ Already Working (No Changes Needed)

- API Gateway routes — all paths match controllers correctly
- JWT secret — same across all services (`BYDBCQAgCEVn+1N0Nol6ICbR+gfRfvgxcqypqsDtc7MB`)
- CORS config — Gateway allows `localhost:3000`
- Auth endpoints — `/users/register`, `/users/login` ✓
- Farmers CRUD — `/farmers/**` ✓
- Crop Listings & Orders — `/market/**` ✓
- Transactions & Payments — `/transactions/**` ✓
- Subsidy Programs & Disbursements — `/subsidy-programs/**`, `/disbursements/**` ✓
- Audits & Compliances — `/api/audits/**`, `/api/compliances/**` ✓
- Reports — `/api/report/**` ✓

---

## 🚀 Startup Order

1. Eureka Server (port 8761)
2. Registration Service (port 8091)
3. API Gateway (port 8090)
4. Croplisting-Order (port 8081)
5. Transaction-Payment (port 8093)
6. Subsidy (port 9091)
7. Audit-Compliance (port 8094)
8. Report Service (port 8095)
9. Frontend — `npm start` (port 3000)
