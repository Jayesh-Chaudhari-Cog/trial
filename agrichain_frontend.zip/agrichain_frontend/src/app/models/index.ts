// src/app/models/index.ts

export interface User {
  id: number;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  status: string;
}

export interface LoginRequest { email: string; password: string; }

export interface LoginResponse {
  token: string;
  role: string;
  email: string;
  name: string;
  userId: number;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

export type UserRole =
  'FARMER' | 'TRADER' | 'MARKET_OFFICER' |
  'PROGRAM_MANAGER' | 'ADMIN' | 'COMPLIANCE_OFFICER' | 'GOVERNMENT_AUDITOR';

export interface Farmer {
  id: number;
  userId: number;
  name: string;
  email: string;
  contactInfo?: string;
  dob?: string;
  gender?: string;
  address?: string;
  landDetails?: string;
  aadharNumber?: string;
  bankAccount?: string;
  ifscCode?: string;
  status: string;
}

export interface CropListing {
  id: number;
  farmerId: number;
  cropName: string;
  variety?: string;
  quantityKg: number;
  pricePerKg: number;
  harvestDate?: string;
  availableFrom?: string;
  availableUntil?: string;
  location?: string;
  description?: string;
  qualityGrade?: string;
  status: string;
  createdAt?: string;
}

export interface Order {
  id: number;
  listingId: number;
  buyerUserId: number;
  farmerId: number;
  quantityKg: number;
  pricePerKg: number;
  totalAmount: number;
  status: string;
  deliveryAddress?: string;
  notes?: string;
  orderedAt?: string;
}

export interface Transaction {
  id: number;
  orderId: number;
  senderId: number;
  receiverId: number;
  amount: number;
  transactionType: string;
  status: string;
  referenceNo?: string;
  description?: string;
  createdAt?: string;
}

export interface Payment {
  id: number;
  transactionId: number;
  paymentMethod: string;
  paymentStatus: string;
  gatewayRef?: string;
  paidAt?: string;
  createdAt?: string;
}

export interface SubsidyProgram {
  id: number;
  name: string;
  description?: string;
  budgetTotal: number;
  budgetUsed: number;
  subsidyType: string;
  eligibilityCriteria?: string;
  startDate: string;
  endDate: string;
  status: string;
  createdBy?: number;
}

export interface SubsidyDisbursement {
  id: number;
  programId: number;
  farmerId: number;
  amount: number;
  status: string;
  applicationDate: string;
  disbursementDate?: string;
  remarks?: string;
  reviewedBy?: number;
}

export interface Audit {
  id: number;
  title: string;
  description?: string;
  auditScope: string;
  targetId?: number;
  status: string;
  auditorId?: number;
  findings?: string;
  scheduledDate?: string;
  completedDate?: string;
}

export interface ComplianceRecord {
  id: number;
  farmerId: number;
  complianceType: string;
  result: string;
  officerId?: number;
  notes?: string;
  validUntil?: string;
  checkedAt?: string;
}

export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  type: string;
  category: string;
  isRead: boolean;
  referenceId?: number;
  referenceType?: string;
  createdAt: string;
}

export interface MarketPrice {
  id: number;
  cropName: string;
  marketName?: string;
  state?: string;
  pricePerKg: number;
  recordedDate: string;
}

export interface DashboardStats {
  totalFarmers?: number;
  totalListings?: number;
  activeListings?: number;
  totalOrders?: number;
  pendingOrders?: number;
  totalRevenue?: number;
  totalTransactions?: number;
  totalPrograms?: number;
  activePrograms?: number;
  totalDisbursedAmount?: number;
  totalAudits?: number;
  completedAudits?: number;
  compliantCount?: number;
  nonCompliantCount?: number;
}
