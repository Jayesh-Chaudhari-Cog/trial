import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./pages/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'dashboard/farmer',
    loadComponent: () => import('./pages/dashboard/farmer/farmer-dashboard.component').then(m => m.FarmerDashboardComponent),
    canActivate: [authGuard], data: { roles: ['FARMER'] }
  },
  {
    path: 'dashboard/trader',
    loadComponent: () => import('./pages/dashboard/trader/trader-dashboard.component').then(m => m.TraderDashboardComponent),
    canActivate: [authGuard], data: { roles: ['TRADER'] }
  },
  {
    path: 'dashboard/admin',
    loadComponent: () => import('./pages/dashboard/admin/admin-dashboard.component').then(m => m.AdminDashboardComponent),
    canActivate: [authGuard], data: { roles: ['ADMIN'] }
  },
  {
    path: 'dashboard/market-officer',
    loadComponent: () => import('./pages/dashboard/market-officer/market-officer-dashboard.component').then(m => m.MarketOfficerDashboardComponent),
    canActivate: [authGuard], data: { roles: ['MARKET_OFFICER'] }
  },
  {
    path: 'dashboard/program-manager',
    loadComponent: () => import('./pages/dashboard/program-manager/program-manager-dashboard.component').then(m => m.ProgramManagerDashboardComponent),
    canActivate: [authGuard], data: { roles: ['PROGRAM_MANAGER'] }
  },
  {
    path: 'dashboard/compliance',
    loadComponent: () => import('./pages/dashboard/compliance/compliance-dashboard.component').then(m => m.ComplianceDashboardComponent),
    canActivate: [authGuard], data: { roles: ['COMPLIANCE_OFFICER'] }
  },
  {
    path: 'dashboard/auditor',
    loadComponent: () => import('./pages/dashboard/auditor/auditor-dashboard.component').then(m => m.AuditorDashboardComponent),
    canActivate: [authGuard], data: { roles: ['GOVERNMENT_AUDITOR'] }
  },
  { path: '**', redirectTo: '/login' }
];
