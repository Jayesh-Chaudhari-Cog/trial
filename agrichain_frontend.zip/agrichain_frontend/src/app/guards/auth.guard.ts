import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route) => {
  const auth   = inject(AuthService);
  const router = inject(Router);
  if (!auth.isLoggedIn()) { router.navigate(['/login']); return false; }
  const roles: string[] = route.data['roles'] ?? [];
  if (roles.length && !roles.includes(auth.getRole()!)) {
    auth.redirectToDashboard(); return false;
  }
  return true;
};
