import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  ApiResponse, Farmer, CropListing, Order, Transaction, Payment,
  SubsidyProgram, SubsidyDisbursement, Audit, ComplianceRecord,
  Notification, MarketPrice, User
} from '../models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private BASE = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // ─── USERS ───────────────────────────────────────────────────────────────
  getUsers(): Observable<ApiResponse<User[]>> {
    return this.http.get<ApiResponse<User[]>>(`${this.BASE}/api/users`);
  }
  getUserById(id: number): Observable<ApiResponse<User>> {
    return this.http.get<ApiResponse<User>>(`${this.BASE}/api/users/${id}`);
  }
  updateUser(id: number, data: any): Observable<ApiResponse<User>> {
    return this.http.put<ApiResponse<User>>(`${this.BASE}/api/users/${id}`, data);
  }
  deactivateUser(id: number): Observable<ApiResponse<string>> {
    return this.http.delete<ApiResponse<string>>(`${this.BASE}/api/users/${id}`);
  }

  // ─── FARMERS ─────────────────────────────────────────────────────────────
  getFarmers(): Observable<ApiResponse<Farmer[]>> {
    return this.http.get<ApiResponse<Farmer[]>>(`${this.BASE}/api/farmers`);
  }
  getFarmerById(id: number): Observable<ApiResponse<Farmer>> {
    return this.http.get<ApiResponse<Farmer>>(`${this.BASE}/api/farmers/${id}`);
  }
  getFarmerByUserId(userId: number): Observable<ApiResponse<Farmer>> {
    return this.http.get<ApiResponse<Farmer>>(`${this.BASE}/api/farmers/by-user/${userId}`);
  }
  getFarmerCount(): Observable<ApiResponse<number>> {
    return this.http.get<ApiResponse<number>>(`${this.BASE}/api/farmers/count`);
  }
  updateFarmer(id: number, data: any): Observable<ApiResponse<Farmer>> {
    return this.http.put<ApiResponse<Farmer>>(`${this.BASE}/api/farmers/${id}`, data);
  }
  updateFarmerStatus(id: number, status: string): Observable<ApiResponse<string>> {
    return this.http.patch<ApiResponse<string>>(`${this.BASE}/api/farmers/${id}/status`, { status });
  }
  getFarmersByStatus(status: string): Observable<ApiResponse<Farmer[]>> {
    return this.http.get<ApiResponse<Farmer[]>>(`${this.BASE}/api/farmers/status/${status}`);
  }
  getDocuments(farmerId: number): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.BASE}/api/farmers/${farmerId}/documents`);
  }
  addDocument(farmerId: number, data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.BASE}/api/farmers/${farmerId}/documents`, data);
  }
  verifyDocument(docId: number, status: string): Observable<ApiResponse<string>> {
    return this.http.patch<ApiResponse<string>>(`${this.BASE}/api/farmers/documents/${docId}/verify`, { status });
  }

  // ─── CROP LISTINGS ───────────────────────────────────────────────────────
  getListings(): Observable<ApiResponse<CropListing[]>> {
    return this.http.get<ApiResponse<CropListing[]>>(`${this.BASE}/api/listings`);
  }
  getActiveListings(): Observable<ApiResponse<CropListing[]>> {
    return this.http.get<ApiResponse<CropListing[]>>(`${this.BASE}/api/listings/active`);
  }
  getListingsByFarmer(farmerId: number): Observable<ApiResponse<CropListing[]>> {
    return this.http.get<ApiResponse<CropListing[]>>(`${this.BASE}/api/listings/farmer/${farmerId}`);
  }
  getListingById(id: number): Observable<ApiResponse<CropListing>> {
    return this.http.get<ApiResponse<CropListing>>(`${this.BASE}/api/listings/${id}`);
  }
  createListing(data: any): Observable<ApiResponse<CropListing>> {
    return this.http.post<ApiResponse<CropListing>>(`${this.BASE}/api/listings`, data);
  }
  updateListing(id: number, data: any): Observable<ApiResponse<CropListing>> {
    return this.http.put<ApiResponse<CropListing>>(`${this.BASE}/api/listings/${id}`, data);
  }
  updateListingStatus(id: number, status: string): Observable<ApiResponse<string>> {
    return this.http.patch<ApiResponse<string>>(`${this.BASE}/api/listings/${id}/status`, { status });
  }
  searchListings(crop: string): Observable<ApiResponse<CropListing[]>> {
    return this.http.get<ApiResponse<CropListing[]>>(`${this.BASE}/api/listings/search?crop=${crop}`);
  }
  getListingStats(): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.BASE}/api/listings/stats`);
  }

  // ─── ORDERS ──────────────────────────────────────────────────────────────
  getOrders(): Observable<ApiResponse<Order[]>> {
    return this.http.get<ApiResponse<Order[]>>(`${this.BASE}/api/orders`);
  }
  getOrdersByBuyer(buyerUserId: number): Observable<ApiResponse<Order[]>> {
    return this.http.get<ApiResponse<Order[]>>(`${this.BASE}/api/orders/buyer/${buyerUserId}`);
  }
  getOrdersByFarmer(farmerId: number): Observable<ApiResponse<Order[]>> {
    return this.http.get<ApiResponse<Order[]>>(`${this.BASE}/api/orders/farmer/${farmerId}`);
  }
  getOrderById(id: number): Observable<ApiResponse<Order>> {
    return this.http.get<ApiResponse<Order>>(`${this.BASE}/api/orders/${id}`);
  }
  createOrder(data: any): Observable<ApiResponse<Order>> {
    return this.http.post<ApiResponse<Order>>(`${this.BASE}/api/orders`, data);
  }
  updateOrderStatus(id: number, status: string): Observable<ApiResponse<Order>> {
    return this.http.patch<ApiResponse<Order>>(`${this.BASE}/api/orders/${id}/status`, { status });
  }

  // ─── MARKET PRICES ───────────────────────────────────────────────────────
  getMarketPrices(): Observable<ApiResponse<MarketPrice[]>> {
    return this.http.get<ApiResponse<MarketPrice[]>>(`${this.BASE}/api/market/prices`);
  }
  getMarketPricesByCrop(crop: string): Observable<ApiResponse<MarketPrice[]>> {
    return this.http.get<ApiResponse<MarketPrice[]>>(`${this.BASE}/api/market/prices/${crop}`);
  }
  addMarketPrice(data: any): Observable<ApiResponse<MarketPrice>> {
    return this.http.post<ApiResponse<MarketPrice>>(`${this.BASE}/api/market/prices`, data);
  }

  // ─── TRANSACTIONS ─────────────────────────────────────────────────────────
  getTransactions(): Observable<any> {
    return this.http.get(`${this.BASE}/api/transactions`);
  }
  getTransactionById(id: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/transactions/${id}`);
  }
  getTransactionsBySender(senderId: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/transactions/sender/${senderId}`);
  }
  initiateTransaction(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/transactions/initiate`, data);
  }
  getTransactionStats(): Observable<any> {
    return this.http.get(`${this.BASE}/api/transactions/stats`);
  }
  getPayments(): Observable<any> {
    return this.http.get(`${this.BASE}/api/payments`);
  }
  initiatePayment(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/payments/initiate`, data);
  }
  completePayment(id: number): Observable<any> {
    return this.http.patch(`${this.BASE}/api/payments/${id}/complete`, {});
  }

  // ─── SUBSIDIES ────────────────────────────────────────────────────────────
  getSubsidyPrograms(): Observable<any> {
    return this.http.get(`${this.BASE}/api/subsidies`);
  }
  getActiveSubsidyPrograms(): Observable<any> {
    return this.http.get(`${this.BASE}/api/subsidies/active`);
  }
  getSubsidyProgramById(id: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/subsidies/${id}`);
  }
  createSubsidyProgram(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/subsidies`, data);
  }
  updateSubsidyStatus(id: number, status: string): Observable<any> {
    return this.http.patch(`${this.BASE}/api/subsidies/${id}/status`, { status });
  }
  getSubsidyStats(): Observable<any> {
    return this.http.get(`${this.BASE}/api/subsidies/stats`);
  }
  getDisbursements(): Observable<any> {
    return this.http.get(`${this.BASE}/api/disbursements`);
  }
  getDisbursementsByFarmer(farmerId: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/disbursements/farmer/${farmerId}`);
  }
  getPendingDisbursements(): Observable<any> {
    return this.http.get(`${this.BASE}/api/disbursements/pending`);
  }
  applyForSubsidy(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/disbursements`, data);
  }
  updateDisbursementStatus(id: number, data: any): Observable<any> {
    return this.http.patch(`${this.BASE}/api/disbursements/${id}/status`, data);
  }

  // ─── AUDITS ────────────────────────────────────────────────────────────────
  getAudits(): Observable<any> {
    return this.http.get(`${this.BASE}/api/audits`);
  }
  getAuditById(id: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/audits/${id}`);
  }
  createAudit(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/audits`, data);
  }
  updateAudit(id: number, data: any): Observable<any> {
    return this.http.put(`${this.BASE}/api/audits/${id}`, data);
  }
  getAuditStats(): Observable<any> {
    return this.http.get(`${this.BASE}/api/audits/stats`);
  }
  getCompliance(): Observable<any> {
    return this.http.get(`${this.BASE}/api/compliance`);
  }
  getComplianceByFarmer(farmerId: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/compliance/farmer/${farmerId}`);
  }
  createCompliance(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/compliance`, data);
  }
  updateComplianceResult(id: number, result: string, notes: string): Observable<any> {
    return this.http.patch(`${this.BASE}/api/compliance/${id}/result`, { result, notes });
  }
  getAuditLogs(limit = 50): Observable<any> {
    return this.http.get(`${this.BASE}/api/audit-logs?limit=${limit}`);
  }

  // ─── NOTIFICATIONS ─────────────────────────────────────────────────────────
  getNotifications(userId: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/notifications/user/${userId}`);
  }
  getUnreadNotifications(userId: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/notifications/user/${userId}/unread`);
  }
  getUnreadCount(userId: number): Observable<any> {
    return this.http.get(`${this.BASE}/api/notifications/user/${userId}/unread-count`);
  }
  markNotificationRead(id: number): Observable<any> {
    return this.http.patch(`${this.BASE}/api/notifications/${id}/read`, {});
  }
  markAllNotificationsRead(userId: number): Observable<any> {
    return this.http.patch(`${this.BASE}/api/notifications/user/${userId}/mark-all-read`, {});
  }

  // ─── REPORTS ───────────────────────────────────────────────────────────────
  getReports(): Observable<any> {
    return this.http.get(`${this.BASE}/api/reports`);
  }
  generateReport(data: any): Observable<any> {
    return this.http.post(`${this.BASE}/api/reports`, data);
  }
}
