import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApiResponse, LoginRequest, LoginResponse, UserRole } from '../models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly API = environment.apiUrl;
  private readonly TOKEN_KEY = 'agrichain_token';
  private readonly USER_KEY  = 'agrichain_user';

  private currentUserSubject = new BehaviorSubject<LoginResponse | null>(this.loadUser());
  currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: LoginRequest): Observable<ApiResponse<LoginResponse>> {
    return this.http.post<ApiResponse<LoginResponse>>(`${this.API}/api/auth/login`, credentials)
      .pipe(tap(res => {
        if (res.success && res.data) {
          localStorage.setItem(this.TOKEN_KEY, res.data.token);
          localStorage.setItem(this.USER_KEY, JSON.stringify(res.data));
          this.currentUserSubject.next(res.data);
        }
      }));
  }

  register(payload: any): Observable<ApiResponse<string>> {
    return this.http.post<ApiResponse<string>>(`${this.API}/api/auth/register`, payload);
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getCurrentUser(): LoginResponse | null {
    return this.currentUserSubject.value;
  }

  getRole(): UserRole | null {
    return (this.getCurrentUser()?.role as UserRole) ?? null;
  }

  getUserId(): number | null {
    return this.getCurrentUser()?.userId ?? null;
  }

  redirectToDashboard(): void {
    const role = this.getRole();
    const routes: Record<string, string> = {
      FARMER:              '/dashboard/farmer',
      TRADER:              '/dashboard/trader',
      MARKET_OFFICER:      '/dashboard/market-officer',
      PROGRAM_MANAGER:     '/dashboard/program-manager',
      ADMIN:               '/dashboard/admin',
      COMPLIANCE_OFFICER:  '/dashboard/compliance',
      GOVERNMENT_AUDITOR:  '/dashboard/auditor'
    };
    this.router.navigate([routes[role!] ?? '/login']);
  }

  private loadUser(): LoginResponse | null {
    try {
      const raw = localStorage.getItem(this.USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }
}
