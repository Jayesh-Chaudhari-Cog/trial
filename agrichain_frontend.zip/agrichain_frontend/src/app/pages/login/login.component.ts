import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loading  = false;
  error    = '';
  showPass = false;

  demoUsers = [
    { role: 'Farmer',             email: 'farmer1@example.com',    pass: 'Admin@123' },
    { role: 'Trader',             email: 'trader1@example.com',    pass: 'Admin@123' },
    { role: 'Admin',              email: 'admin@agrichain.in',     pass: 'Admin@123' },
    { role: 'Market Officer',     email: 'officer@agrichain.in',   pass: 'Admin@123' },
    { role: 'Program Manager',    email: 'manager@agrichain.in',   pass: 'Admin@123' },
    { role: 'Compliance Officer', email: 'compliance@agrichain.in',pass: 'Admin@123' },
    { role: 'Govt Auditor',       email: 'auditor@agrichain.in',   pass: 'Admin@123' },
  ];

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    if (this.auth.isLoggedIn()) { this.auth.redirectToDashboard(); return; }
    this.loginForm = this.fb.group({
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  fillDemo(user: { email: string; pass: string }): void {
    this.loginForm.patchValue({ email: user.email, password: user.pass });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) { this.loginForm.markAllAsTouched(); return; }
    this.loading = true; this.error = '';
    this.auth.login(this.loginForm.value).subscribe({
      next: res => { this.loading = false; if (res.success) this.auth.redirectToDashboard(); },
      error: err => { this.loading = false; this.error = err.error?.message ?? 'Login failed. Check credentials.'; }
    });
  }

  get f() { return this.loginForm.controls; }
}
