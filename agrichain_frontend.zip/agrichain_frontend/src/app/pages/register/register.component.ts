import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  form!: FormGroup;
  loading  = false;
  error    = '';
  success  = '';
  showPass = false;
  step     = 1;

  roles = [
    { value: 'FARMER',   label: 'Farmer',    icon: 'fa-tractor',    desc: 'List crops, manage orders & apply for subsidies' },
    { value: 'TRADER',   label: 'Trader/Buyer', icon: 'fa-store',   desc: 'Browse listings and place orders for crops' },
  ];

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      name:        ['', [Validators.required, Validators.minLength(2)]],
      email:       ['', [Validators.required, Validators.email]],
      phone:       ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      password:    ['', [Validators.required, Validators.minLength(6)]],
      role:        ['FARMER', Validators.required],
      address:     [''],
      landDetails: [''],
      aadharNumber:[''],
    });
  }

  selectRole(role: string): void {
    this.form.patchValue({ role });
  }

  nextStep(): void {
    const controls = ['name', 'email', 'phone', 'password'];
    controls.forEach(c => this.form.get(c)?.markAsTouched());
    const valid = controls.every(c => this.form.get(c)?.valid);
    if (valid) this.step = 2;
  }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading = true; this.error = ''; this.success = '';
    this.auth.register(this.form.value).subscribe({
      next: res => {
        this.loading = false;
        if (res.success) {
          this.success = 'Account created! Redirecting to login...';
          setTimeout(() => this.router.navigate(['/login']), 2000);
        }
      },
      error: err => { this.loading = false; this.error = err.error?.message ?? 'Registration failed.'; }
    });
  }

  get f() { return this.form.controls; }
  get isFarmer() { return this.form.get('role')?.value === 'FARMER'; }
}
