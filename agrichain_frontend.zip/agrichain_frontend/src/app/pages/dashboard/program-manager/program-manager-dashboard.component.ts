import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';

@Component({
  selector: 'app-program-manager-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './program-manager-dashboard.component.html',
  styleUrls: ['./program-manager-dashboard.component.scss']
})
export class ProgramManagerDashboardComponent implements OnInit {
  activeSection = 'overview';
  alertMsg = ''; alertType = 'success';

  programs: any[]       = [];
  disbursements: any[]  = [];
  pendingDisb: any[]    = [];
  subsidyStats: any     = {};
  farmers: any[]        = [];

  showProgramModal = false;
  programForm!: FormGroup;

  subsidyTypes = ['SEED','FERTILIZER','EQUIPMENT','IRRIGATION','GENERAL','CROP_INSURANCE'];

  navItems = [
    { label: 'Overview',          icon: 'fa-home',            section: 'overview' },
    { label: 'Subsidy Programs',  icon: 'fa-hand-holding-usd',section: 'programs' },
    { label: 'Disbursements',     icon: 'fa-money-bill-wave', section: 'disbursements' },
    { label: 'Pending Approvals', icon: 'fa-clock',           section: 'pending' },
    { label: 'Reports',           icon: 'fa-chart-bar',       section: 'reports' },
  ];

  constructor(private api: ApiService, private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.programForm = this.fb.group({
      name:                ['', Validators.required],
      description:         [''],
      budgetTotal:         ['', [Validators.required, Validators.min(1)]],
      subsidyType:         ['GENERAL', Validators.required],
      eligibilityCriteria: [''],
      startDate:           ['', Validators.required],
      endDate:             ['', Validators.required]
    });
    this.loadAll();
  }

  loadAll(): void {
    const userId = this.auth.getUserId()!;
    this.api.getSubsidyPrograms().subscribe({ next: r => this.programs = r.data ?? [] });
    this.api.getDisbursements().subscribe({ next: r => {
      this.disbursements = r.data ?? [];
      this.pendingDisb = this.disbursements.filter((d: any) => d.status === 'APPLIED');
    }});
    this.api.getSubsidyStats().subscribe({ next: r => this.subsidyStats = r.data ?? {} });
    this.api.getFarmers().subscribe({ next: r => this.farmers = r.data ?? [] });
  }

  setSection(s: string): void { this.activeSection = s; }

  openProgramModal(): void { this.showProgramModal = true; this.programForm.reset({ subsidyType: 'GENERAL' }); }
  closeProgramModal(): void { this.showProgramModal = false; }

  saveProgram(): void {
    if (this.programForm.invalid) { this.programForm.markAllAsTouched(); return; }
    const userId = this.auth.getUserId()!;
    const data = { ...this.programForm.value, createdBy: String(userId), budgetTotal: String(this.programForm.value.budgetTotal) };
    this.api.createSubsidyProgram(data).subscribe({
      next: () => { this.showAlert('Program created!', 'success'); this.closeProgramModal(); this.loadAll(); },
      error: () => this.showAlert('Failed to create program', 'danger')
    });
  }

  updateProgramStatus(id: number, status: string): void {
    this.api.updateSubsidyStatus(id, status).subscribe({
      next: () => { this.showAlert('Program status updated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  approveDisbursement(id: number): void {
    const userId = this.auth.getUserId()!;
    this.api.updateDisbursementStatus(id, { status: 'APPROVED', reviewedBy: String(userId), remarks: 'Approved by Program Manager' }).subscribe({
      next: () => { this.showAlert('Disbursement approved!', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  disburseFunds(id: number): void {
    const userId = this.auth.getUserId()!;
    this.api.updateDisbursementStatus(id, { status: 'DISBURSED', reviewedBy: String(userId), remarks: 'Funds disbursed' }).subscribe({
      next: () => { this.showAlert('Funds disbursed!', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  rejectDisbursement(id: number): void {
    const userId = this.auth.getUserId()!;
    this.api.updateDisbursementStatus(id, { status: 'REJECTED', reviewedBy: String(userId), remarks: 'Rejected by Program Manager' }).subscribe({
      next: () => { this.showAlert('Disbursement rejected', 'warning'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  getStatusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'success',DRAFT:'secondary',PAUSED:'warning',EXPIRED:'danger',CANCELLED:'danger',APPLIED:'warning',UNDER_REVIEW:'info',APPROVED:'primary',DISBURSED:'success',REJECTED:'danger' };
    return m[s] ?? 'secondary';
  }
  showAlert(msg: string, type: string): void { this.alertMsg = msg; this.alertType = type; setTimeout(() => this.alertMsg = '', 4000); }
  get pf() { return this.programForm.controls; }
}
