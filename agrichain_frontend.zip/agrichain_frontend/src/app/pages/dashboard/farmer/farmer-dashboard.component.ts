import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';
import { CropListing, Farmer, Notification, Order, SubsidyDisbursement, SubsidyProgram } from '../../../models';

@Component({
  selector: 'app-farmer-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './farmer-dashboard.component.html',
  styleUrls: ['./farmer-dashboard.component.scss']
})
export class FarmerDashboardComponent implements OnInit {
  activeSection = 'overview';
  loading = false;
  alertMsg = ''; alertType = 'success';

  farmer: Farmer | null = null;
  listings: CropListing[] = [];
  orders: Order[] = [];
  subsidyPrograms: SubsidyProgram[] = [];
  myDisbursements: SubsidyDisbursement[] = [];
  notifications: Notification[] = [];
  unreadCount = 0;
  marketPrices: any[] = [];

  stats = { totalListings: 0, activeListings: 0, totalOrders: 0, pendingOrders: 0 };

  listingForm!: FormGroup;
  profileForm!: FormGroup;
  subsidyForm!: FormGroup;
  showListingModal = false;
  showSubsidyModal = false;
  editListingId: number | null = null;

  navItems = [
    { label: 'Overview',       icon: 'fa-home',            section: 'overview' },
    { label: 'My Profile',     icon: 'fa-user',            section: 'profile' },
    { label: 'Crop Listings',  icon: 'fa-leaf',            section: 'listings' },
    { label: 'My Orders',      icon: 'fa-shopping-cart',   section: 'orders' },
    { label: 'Subsidies',      icon: 'fa-hand-holding-usd',section: 'subsidies' },
    { label: 'Market Prices',  icon: 'fa-chart-line',      section: 'market' },
    { label: 'Notifications',  icon: 'fa-bell',            section: 'notifications' },
  ];

  qualityGrades = ['A', 'B', 'C', 'ORGANIC'];
  crops = ['Wheat','Rice','Cotton','Groundnut','Maize','Soybean','Tomato','Onion','Potato','Sugarcane','Mustard','Barley'];

  constructor(private api: ApiService, private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initForms();
    this.loadFarmerData();
    this.navItems.forEach(i => { (i as any).action = undefined; });
  }

  initForms(): void {
    this.listingForm = this.fb.group({
      cropName:     ['', Validators.required],
      variety:      [''],
      quantityKg:   ['', [Validators.required, Validators.min(1)]],
      pricePerKg:   ['', [Validators.required, Validators.min(0.01)]],
      harvestDate:  [''],
      availableFrom:[''],
      availableUntil:[''],
      location:     [''],
      description:  [''],
      qualityGrade: ['B']
    });

    this.profileForm = this.fb.group({
      name:        [''],
      phone:       [''],
      address:     [''],
      landDetails: [''],
      bankAccount: [''],
      ifscCode:    ['']
    });

    this.subsidyForm = this.fb.group({
      programId: ['', Validators.required],
      amount:    ['', [Validators.required, Validators.min(1)]],
    });
  }

  loadFarmerData(): void {
    this.loading = true;
    const userId = this.auth.getUserId()!;
    this.api.getFarmerByUserId(userId).subscribe({
      next: res => {
        this.farmer = res.data;
        this.loading = false;
        if (this.farmer) {
          this.profileForm.patchValue({
            name: this.farmer.name, phone: this.farmer.contactInfo,
            address: this.farmer.address, landDetails: this.farmer.landDetails,
            bankAccount: this.farmer.bankAccount, ifscCode: this.farmer.ifscCode
          });
          this.loadListings();
          this.loadOrders();
          this.loadNotifications(userId);
        }
      },
      error: () => { this.loading = false; }
    });
    this.api.getActiveSubsidyPrograms().subscribe({ next: r => this.subsidyPrograms = r.data ?? [] });
    this.api.getMarketPrices().subscribe({ next: r => this.marketPrices = r.data ?? [] });
  }

  loadListings(): void {
    if (!this.farmer) return;
    this.api.getListingsByFarmer(this.farmer.id).subscribe({
      next: r => {
        this.listings = r.data ?? [];
        this.stats.totalListings  = this.listings.length;
        this.stats.activeListings = this.listings.filter(l => l.status === 'ACTIVE').length;
      }
    });
  }

  loadOrders(): void {
    if (!this.farmer) return;
    this.api.getOrdersByFarmer(this.farmer.id).subscribe({
      next: r => {
        this.orders = r.data ?? [];
        this.stats.totalOrders   = this.orders.length;
        this.stats.pendingOrders = this.orders.filter(o => o.status === 'PENDING').length;
      }
    });
  }

  loadNotifications(userId: number): void {
    this.api.getNotifications(userId).subscribe({ next: r => {
      this.notifications = r.data ?? [];
      this.unreadCount   = this.notifications.filter(n => !n.isRead).length;
    }});
  }

  loadDisbursements(): void {
    if (!this.farmer) return;
    this.api.getDisbursementsByFarmer(this.farmer.id).subscribe({ next: r => this.myDisbursements = r.data ?? [] });
  }

  setSection(section: string): void {
    this.activeSection = section;
    if (section === 'subsidies') this.loadDisbursements();
  }

  // ── Listings ──
  openListingModal(listing?: CropListing): void {
    this.showListingModal = true;
    if (listing) {
      this.editListingId = listing.id;
      this.listingForm.patchValue(listing);
    } else {
      this.editListingId = null;
      this.listingForm.reset({ qualityGrade: 'B' });
    }
  }
  closeListingModal(): void { this.showListingModal = false; }

  saveListing(): void {
    if (this.listingForm.invalid) { this.listingForm.markAllAsTouched(); return; }
    const data = { ...this.listingForm.value, farmerId: this.farmer!.id };
    const req = this.editListingId
      ? this.api.updateListing(this.editListingId, data)
      : this.api.createListing(data);
    req.subscribe({
      next: () => {
        this.showAlert('Listing saved successfully!', 'success');
        this.closeListingModal(); this.loadListings();
      },
      error: () => this.showAlert('Failed to save listing.', 'danger')
    });
  }

  deactivateListing(id: number): void {
    this.api.updateListingStatus(id, 'CANCELLED').subscribe({
      next: () => { this.showAlert('Listing cancelled.', 'success'); this.loadListings(); },
      error: () => this.showAlert('Failed to cancel listing.', 'danger')
    });
  }

  // ── Orders ──
  updateOrderStatus(id: number, status: string): void {
    this.api.updateOrderStatus(id, status).subscribe({
      next: () => { this.showAlert('Order status updated!', 'success'); this.loadOrders(); },
      error: () => this.showAlert('Failed to update order.', 'danger')
    });
  }

  // ── Subsidy ──
  openSubsidyModal(): void { this.showSubsidyModal = true; this.subsidyForm.reset(); }
  closeSubsidyModal(): void { this.showSubsidyModal = false; }

  applySubsidy(): void {
    if (this.subsidyForm.invalid) { this.subsidyForm.markAllAsTouched(); return; }
    const data = { ...this.subsidyForm.value, farmerId: String(this.farmer!.id), amount: String(this.subsidyForm.value.amount) };
    this.api.applyForSubsidy(data).subscribe({
      next: () => {
        this.showAlert('Subsidy application submitted!', 'success');
        this.closeSubsidyModal(); this.loadDisbursements();
      },
      error: () => this.showAlert('Subsidy application failed.', 'danger')
    });
  }

  // ── Profile ──
  saveProfile(): void {
    if (!this.farmer) return;
    this.api.updateFarmer(this.farmer.id, this.profileForm.value).subscribe({
      next: r => { this.farmer = r.data; this.showAlert('Profile updated!', 'success'); },
      error: () => this.showAlert('Profile update failed.', 'danger')
    });
  }

  // ── Notifications ──
  markRead(id: number): void {
    this.api.markNotificationRead(id).subscribe({ next: () => {
      const n = this.notifications.find(x => x.id === id);
      if (n) { n.isRead = true; this.unreadCount = Math.max(0, this.unreadCount - 1); }
    }});
  }
  markAllRead(): void {
    const userId = this.auth.getUserId()!;
    this.api.markAllNotificationsRead(userId).subscribe({ next: () => {
      this.notifications.forEach(n => n.isRead = true); this.unreadCount = 0;
    }});
  }

  showAlert(msg: string, type: string): void {
    this.alertMsg = msg; this.alertType = type;
    setTimeout(() => this.alertMsg = '', 4000);
  }

  getStatusBadge(status: string): string {
    const map: Record<string, string> = {
      ACTIVE:'success', PENDING:'warning', SOLD:'info', CANCELLED:'danger',
      DELIVERED:'success', IN_TRANSIT:'info', CONFIRMED:'primary',
      APPROVED:'success', DISBURSED:'success', REJECTED:'danger', APPLIED:'warning',
      COMPLIANT:'success', NON_COMPLIANT:'danger'
    };
    return map[status] ?? 'secondary';
  }

  get lf() { return this.listingForm.controls; }
  get sf() { return this.subsidyForm.controls; }
}
