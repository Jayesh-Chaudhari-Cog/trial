import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';

@Component({
  selector: 'app-compliance-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './compliance-dashboard.component.html',
  styleUrls: ['./compliance-dashboard.component.scss']
})
export class ComplianceDashboardComponent implements OnInit {
  activeSection = 'overview';
  alertMsg = ''; alertType = 'success';

  compliance: any[] = [];
  farmers: any[]    = [];
  auditStats: any   = {};

  showCheckModal = false;
  checkForm!: FormGroup;
  complianceTypes = ['KYC','LAND_VERIFICATION','QUALITY_CHECK','FINANCIAL','ENVIRONMENTAL'];

  navItems = [
    { label: 'Overview',           icon: 'fa-home',        section: 'overview' },
    { label: 'Compliance Checks',  icon: 'fa-shield-alt',  section: 'compliance' },
    { label: 'Farmer Docs',        icon: 'fa-file-alt',    section: 'documents' },
    { label: 'Statistics',         icon: 'fa-chart-bar',   section: 'stats' },
  ];

  constructor(private api: ApiService, private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.checkForm = this.fb.group({
      farmerId:       ['', Validators.required],
      complianceType: ['KYC', Validators.required],
      notes:          [''],
      validUntil:     ['']
    });
    this.loadAll();
  }

  loadAll(): void {
    this.api.getCompliance().subscribe({ next: r => this.compliance = r.data ?? [] });
    this.api.getFarmers().subscribe({ next: r => this.farmers = r.data ?? [] });
    this.api.getAuditStats().subscribe({ next: r => this.auditStats = r.data ?? {} });
  }

  setSection(s: string): void { this.activeSection = s; }

  openCheckModal(): void { this.showCheckModal = true; this.checkForm.reset({ complianceType: 'KYC' }); }
  closeCheckModal(): void { this.showCheckModal = false; }

  saveCheck(): void {
    if (this.checkForm.invalid) { this.checkForm.markAllAsTouched(); return; }
    const userId = this.auth.getUserId()!;
    const data = { ...this.checkForm.value, farmerId: String(this.checkForm.value.farmerId), officerId: String(userId) };
    this.api.createCompliance(data).subscribe({
      next: () => { this.showAlert('Compliance check created!', 'success'); this.closeCheckModal(); this.loadAll(); },
      error: () => this.showAlert('Failed to create check', 'danger')
    });
  }

  updateResult(id: number, result: string): void {
    this.api.updateComplianceResult(id, result, `Marked ${result} by officer`).subscribe({
      next: () => { this.showAlert(`Marked as ${result}`, 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  verifyDoc(docId: number, status: string): void {
    this.api.verifyDocument(docId, status).subscribe({
      next: () => { this.showAlert('Document status updated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  get compliant()    { return this.compliance.filter(c => c.result === 'COMPLIANT').length; }
  get nonCompliant() { return this.compliance.filter(c => c.result === 'NON_COMPLIANT').length; }
  get pending()      { return this.compliance.filter(c => c.result === 'PENDING').length; }

  getResultBadge(r: string): string {
    const m: Record<string,string> = { COMPLIANT:'success', NON_COMPLIANT:'danger', PENDING:'warning', UNDER_REVIEW:'info' };
    return m[r] ?? 'secondary';
  }
  getStatusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'success', INACTIVE:'secondary', SUSPENDED:'danger', PENDING_VERIFICATION:'warning' };
    return m[s] ?? 'secondary';
  }
  showAlert(msg: string, type: string): void { this.alertMsg = msg; this.alertType = type; setTimeout(() => this.alertMsg = '', 4000); }
  get cf() { return this.checkForm.controls; }
}
