import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';

@Component({
  selector: 'app-market-officer-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './market-officer-dashboard.component.html',
  styleUrls: ['./market-officer-dashboard.component.scss']
})
export class MarketOfficerDashboardComponent implements OnInit {
  activeSection = 'overview';
  alertMsg = ''; alertType = 'success';

  listings: any[]      = [];
  farmers: any[]       = [];
  orders: any[]        = [];
  marketPrices: any[]  = [];
  listingStats: any    = {};

  showPriceModal = false;
  priceForm!: FormGroup;

  crops = ['Wheat','Rice','Cotton','Groundnut','Maize','Soybean','Tomato','Onion','Potato','Sugarcane','Mustard','Barley','Jowar','Bajra'];
  states = ['Andhra Pradesh','Gujarat','Maharashtra','Punjab','Uttar Pradesh','Rajasthan','Madhya Pradesh','Karnataka','Tamil Nadu','Telangana'];

  navItems = [
    { label: 'Overview',         icon: 'fa-home',          section: 'overview' },
    { label: 'Crop Listings',    icon: 'fa-leaf',          section: 'listings' },
    { label: 'Market Prices',    icon: 'fa-chart-line',    section: 'prices' },
    { label: 'Farmer Registry',  icon: 'fa-tractor',       section: 'farmers' },
    { label: 'Orders Monitor',   icon: 'fa-shopping-cart', section: 'orders' },
  ];

  constructor(private api: ApiService, private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.priceForm = this.fb.group({
      cropName:   ['', Validators.required],
      marketName: ['', Validators.required],
      state:      ['', Validators.required],
      pricePerKg: ['', [Validators.required, Validators.min(0.01)]]
    });
    this.loadAll();
  }

  loadAll(): void {
    this.api.getListings().subscribe({ next: r => this.listings = r.data ?? [] });
    this.api.getFarmers().subscribe({ next: r => this.farmers = r.data ?? [] });
    this.api.getOrders().subscribe({ next: r => this.orders = r.data ?? [] });
    this.api.getMarketPrices().subscribe({ next: r => this.marketPrices = r.data ?? [] });
    this.api.getListingStats().subscribe({ next: r => this.listingStats = r.data ?? {} });
  }

  setSection(s: string): void { this.activeSection = s; }

  updateListingStatus(id: number, status: string): void {
    this.api.updateListingStatus(id, status).subscribe({
      next: () => { this.showAlert('Listing updated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  updateOrderStatus(id: number, status: string): void {
    this.api.updateOrderStatus(id, status).subscribe({
      next: () => { this.showAlert('Order updated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  openPriceModal(): void { this.showPriceModal = true; this.priceForm.reset(); }
  closePriceModal(): void { this.showPriceModal = false; }

  savePrice(): void {
    if (this.priceForm.invalid) { this.priceForm.markAllAsTouched(); return; }
    const d = this.priceForm.value;
    this.api.addMarketPrice({ ...d, pricePerKg: String(d.pricePerKg) }).subscribe({
      next: () => { this.showAlert('Market price added!', 'success'); this.closePriceModal(); this.loadAll(); },
      error: () => this.showAlert('Failed to save price', 'danger')
    });
  }

  getStatusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'success',PENDING:'warning',SOLD:'info',CANCELLED:'danger',EXPIRED:'secondary',DELIVERED:'success',IN_TRANSIT:'info',CONFIRMED:'primary',REJECTED:'danger' };
    return m[s] ?? 'secondary';
  }
  showAlert(msg: string, type: string): void { this.alertMsg = msg; this.alertType = type; setTimeout(() => this.alertMsg = '', 4000); }
  get pf() { return this.priceForm.controls; }
}
