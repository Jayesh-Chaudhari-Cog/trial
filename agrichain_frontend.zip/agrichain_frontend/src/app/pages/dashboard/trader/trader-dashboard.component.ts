import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';
import { CropListing, Order, Transaction, MarketPrice } from '../../../models';

@Component({
  selector: 'app-trader-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, SidebarComponent],
  templateUrl: './trader-dashboard.component.html',
  styleUrls: ['./trader-dashboard.component.scss']
})
export class TraderDashboardComponent implements OnInit {
  activeSection = 'overview';
  loading = false;
  alertMsg = ''; alertType = 'success';

  listings: CropListing[]  = [];
  filteredListings: CropListing[] = [];
  myOrders: Order[]        = [];
  transactions: Transaction[] = [];
  marketPrices: MarketPrice[] = [];

  stats = { totalListings: 0, myOrders: 0, pendingOrders: 0, totalSpent: 0 };

  orderForm!: FormGroup;
  selectedListing: CropListing | null = null;
  showOrderModal = false;

  searchCrop    = '';
  filterGrade   = '';
  sortBy        = 'price_asc';

  navItems = [
    { label: 'Overview',       icon: 'fa-home',          section: 'overview' },
    { label: 'Browse Crops',   icon: 'fa-leaf',          section: 'browse' },
    { label: 'My Orders',      icon: 'fa-shopping-cart', section: 'orders' },
    { label: 'Payments',       icon: 'fa-rupee-sign',    section: 'payments' },
    { label: 'Market Prices',  icon: 'fa-chart-bar',     section: 'market' },
  ];

  constructor(private api: ApiService, private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.orderForm = this.fb.group({
      quantityKg:      ['', [Validators.required, Validators.min(1)]],
      deliveryAddress: ['', Validators.required],
      notes:           ['']
    });
    this.loadData();
  }

  loadData(): void {
    this.api.getActiveListings().subscribe({ next: r => {
      this.listings = r.data ?? [];
      this.filteredListings = [...this.listings];
      this.stats.totalListings = this.listings.length;
      this.applyFilters();
    }});
    const userId = this.auth.getUserId()!;
    this.api.getOrdersByBuyer(userId).subscribe({ next: r => {
      this.myOrders = r.data ?? [];
      this.stats.myOrders     = this.myOrders.length;
      this.stats.pendingOrders = this.myOrders.filter(o => o.status === 'PENDING').length;
      this.stats.totalSpent    = this.myOrders
        .filter(o => o.status === 'DELIVERED')
        .reduce((s, o) => s + +o.totalAmount, 0);
    }});
    this.api.getTransactionsBySender(userId).subscribe({ next: r => this.transactions = r.data ?? [] });
    this.api.getMarketPrices().subscribe({ next: r => this.marketPrices = r.data ?? [] });
  }

  applyFilters(): void {
    let result = [...this.listings];
    if (this.searchCrop) result = result.filter(l => l.cropName.toLowerCase().includes(this.searchCrop.toLowerCase()));
    if (this.filterGrade) result = result.filter(l => l.qualityGrade === this.filterGrade);
    if (this.sortBy === 'price_asc')  result.sort((a,b) => +a.pricePerKg - +b.pricePerKg);
    if (this.sortBy === 'price_desc') result.sort((a,b) => +b.pricePerKg - +a.pricePerKg);
    if (this.sortBy === 'qty_desc')   result.sort((a,b) => +b.quantityKg - +a.quantityKg);
    this.filteredListings = result;
  }

  setSection(s: string): void { this.activeSection = s; }

  openOrderModal(listing: CropListing): void {
    this.selectedListing = listing;
    this.showOrderModal  = true;
    this.orderForm.reset();
  }
  closeOrderModal(): void { this.showOrderModal = false; this.selectedListing = null; }

  placeOrder(): void {
    if (this.orderForm.invalid) { this.orderForm.markAllAsTouched(); return; }
    const userId = this.auth.getUserId()!;
    const payload = {
      listingId:       this.selectedListing!.id,
      buyerUserId:     userId,
      quantityKg:      this.orderForm.value.quantityKg,
      deliveryAddress: this.orderForm.value.deliveryAddress,
      notes:           this.orderForm.value.notes
    };
    this.api.createOrder(payload).subscribe({
      next: () => {
        this.showAlert('Order placed successfully!', 'success');
        this.closeOrderModal();
        this.loadData();
        this.setSection('orders');
      },
      error: err => this.showAlert(err.error?.message ?? 'Order failed.', 'danger')
    });
  }

  initiatePayment(order: Order): void {
    const txnPayload = {
      orderId: String(order.id),
      senderId: String(this.auth.getUserId()),
      receiverId: String(order.farmerId),
      amount: String(order.totalAmount),
      description: `Payment for Order #${order.id}`
    };
    this.api.initiateTransaction(txnPayload).subscribe({
      next: txnRes => {
        const txn = txnRes.data;
        this.api.initiatePayment({ transactionId: String(txn.id), method: 'BANK_TRANSFER' }).subscribe({
          next: payRes => {
            this.api.completePayment(payRes.data.id).subscribe({
              next: () => { this.showAlert('Payment successful!', 'success'); this.loadData(); },
              error: () => this.showAlert('Payment completion failed.', 'danger')
            });
          }
        });
      },
      error: () => this.showAlert('Payment initiation failed.', 'danger')
    });
  }

  get estimatedTotal(): number {
    if (!this.selectedListing || !this.orderForm.value.quantityKg) return 0;
    return +this.selectedListing.pricePerKg * +this.orderForm.value.quantityKg;
  }

  showAlert(msg: string, type: string): void {
    this.alertMsg = msg; this.alertType = type;
    setTimeout(() => this.alertMsg = '', 4000);
  }

  getStatusBadge(status: string): string {
    const map: Record<string, string> = {
      ACTIVE:'success', PENDING:'warning', SOLD:'info', CANCELLED:'danger', EXPIRED:'secondary',
      DELIVERED:'success', IN_TRANSIT:'info', CONFIRMED:'primary', REJECTED:'danger'
    };
    return map[status] ?? 'secondary';
  }

  get of() { return this.orderForm.controls; }
}
