import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';

@Component({
  selector: 'app-auditor-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './auditor-dashboard.component.html',
  styleUrls: ['./auditor-dashboard.component.scss']
})
export class AuditorDashboardComponent implements OnInit {
  activeSection = 'overview';
  alertMsg = ''; alertType = 'success';

  audits: any[]      = [];
  auditLogs: any[]   = [];
  transactions: any[]= [];
  compliance: any[]  = [];
  farmers: any[]     = [];
  auditStats: any    = {};
  txnStats: any      = {};

  showAuditModal = false;
  auditForm!: FormGroup;
  auditScopes = ['FARMER','TRANSACTION','SUBSIDY','COMPLIANCE','SYSTEM'];

  navItems = [
    { label: 'Overview',      icon: 'fa-home',          section: 'overview' },
    { label: 'Audits',        icon: 'fa-clipboard-list',section: 'audits' },
    { label: 'Transactions',  icon: 'fa-rupee-sign',    section: 'transactions' },
    { label: 'Compliance',    icon: 'fa-shield-alt',    section: 'compliance' },
    { label: 'System Logs',   icon: 'fa-history',       section: 'logs' },
    { label: 'Reports',       icon: 'fa-chart-bar',     section: 'reports' },
  ];

  constructor(private api: ApiService, private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.auditForm = this.fb.group({
      title:       ['', Validators.required],
      description: [''],
      auditScope:  ['SYSTEM', Validators.required],
      targetId:    [''],
      scheduledDate:['']
    });
    this.loadAll();
  }

  loadAll(): void {
    const userId = this.auth.getUserId()!;
    this.api.getAudits().subscribe({ next: r => this.audits = r.data ?? [] });
    this.api.getAuditLogs(200).subscribe({ next: r => this.auditLogs = r.data ?? [] });
    this.api.getTransactions().subscribe({ next: r => this.transactions = r.data ?? [] });
    this.api.getCompliance().subscribe({ next: r => this.compliance = r.data ?? [] });
    this.api.getFarmers().subscribe({ next: r => this.farmers = r.data ?? [] });
    this.api.getAuditStats().subscribe({ next: r => this.auditStats = r.data ?? {} });
    this.api.getTransactionStats().subscribe({ next: r => this.txnStats = r.data ?? {} });
  }

  setSection(s: string): void { this.activeSection = s; }

  openAuditModal(): void { this.showAuditModal = true; this.auditForm.reset({ auditScope:'SYSTEM' }); }
  closeAuditModal(): void { this.showAuditModal = false; }

  createAudit(): void {
    if (this.auditForm.invalid) { this.auditForm.markAllAsTouched(); return; }
    const userId = this.auth.getUserId()!;
    const data = { ...this.auditForm.value, auditorId: String(userId) };
    this.api.createAudit(data).subscribe({
      next: () => { this.showAlert('Audit created!', 'success'); this.closeAuditModal(); this.loadAll(); },
      error: () => this.showAlert('Failed to create audit', 'danger')
    });
  }

  updateAuditStatus(id: number, status: string, findings?: string): void {
    const data: any = { status };
    if (findings) data.findings = findings;
    if (status === 'COMPLETED') data.completedDate = new Date().toISOString().split('T')[0];
    this.api.updateAudit(id, data).subscribe({
      next: () => { this.showAlert('Audit updated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  generateReport(type: string): void {
    const userId = this.auth.getUserId()!;
    this.api.generateReport({ title: `${type} Report`, reportType: type, generatedBy: String(userId) }).subscribe({
      next: () => this.showAlert(`${type} report generated!`, 'success'),
      error: () => this.showAlert('Report generation failed', 'danger')
    });
  }

  getStatusBadge(s: string): string {
    const m: Record<string,string> = { PLANNED:'warning',IN_PROGRESS:'info',COMPLETED:'success',CANCELLED:'danger',SUCCESS:'success',FAILURE:'danger',COMPLIANT:'success',NON_COMPLIANT:'danger',PENDING:'warning' };
    return m[s] ?? 'secondary';
  }
  showAlert(msg: string, type: string): void { this.alertMsg = msg; this.alertType = type; setTimeout(() => this.alertMsg = '', 4000); }
  get af() { return this.auditForm.controls; }
}
