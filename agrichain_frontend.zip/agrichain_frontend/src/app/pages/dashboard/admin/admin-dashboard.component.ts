import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { AuthService } from '../../../services/auth.service';
import { SidebarComponent } from '../../../shared/sidebar/sidebar.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, SidebarComponent],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {
  activeSection = 'overview';
  alertMsg = ''; alertType = 'success';

  users: any[]    = [];
  farmers: any[]  = [];
  listings: any[] = [];
  orders: any[]   = [];
  auditLogs: any[]= [];
  txnStats: any   = {};
  listingStats: any = {};
  subsidyStats: any = {};
  auditStats: any   = {};

  navItems = [
    { label: 'Overview',     icon: 'fa-home',          section: 'overview' },
    { label: 'Users',        icon: 'fa-users',         section: 'users' },
    { label: 'Farmers',      icon: 'fa-tractor',       section: 'farmers' },
    { label: 'Listings',     icon: 'fa-leaf',          section: 'listings' },
    { label: 'Orders',       icon: 'fa-shopping-cart', section: 'orders' },
    { label: 'Audit Logs',   icon: 'fa-history',       section: 'logs' },
  ];

  constructor(private api: ApiService, private auth: AuthService) {}

  ngOnInit(): void { this.loadAll(); }

  loadAll(): void {
    this.api.getUsers().subscribe({ next: r => this.users = r.data ?? [] });
    this.api.getFarmers().subscribe({ next: r => this.farmers = r.data ?? [] });
    this.api.getListings().subscribe({ next: r => this.listings = r.data ?? [] });
    this.api.getOrders().subscribe({ next: r => this.orders = r.data ?? [] });
    this.api.getAuditLogs(100).subscribe({ next: r => this.auditLogs = r.data ?? [] });
    this.api.getTransactionStats().subscribe({ next: r => this.txnStats = r.data ?? {} });
    this.api.getListingStats().subscribe({ next: r => this.listingStats = r.data ?? {} });
    this.api.getSubsidyStats().subscribe({ next: r => this.subsidyStats = r.data ?? {} });
    this.api.getAuditStats().subscribe({ next: r => this.auditStats = r.data ?? {} });
  }

  setSection(s: string): void { this.activeSection = s; }

  deactivateUser(id: number): void {
    if (!confirm('Deactivate this user?')) return;
    this.api.deactivateUser(id).subscribe({
      next: () => { this.showAlert('User deactivated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  updateFarmerStatus(id: number, status: string): void {
    this.api.updateFarmerStatus(id, status).subscribe({
      next: () => { this.showAlert('Farmer status updated', 'success'); this.loadAll(); },
      error: () => this.showAlert('Failed', 'danger')
    });
  }

  getRoleBadge(role: string): string {
    const m: Record<string,string> = { ADMIN:'danger', FARMER:'success', TRADER:'info', MARKET_OFFICER:'warning', PROGRAM_MANAGER:'primary', COMPLIANCE_OFFICER:'warning', GOVERNMENT_AUDITOR:'secondary' };
    return m[role] ?? 'secondary';
  }
  getStatusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'success', INACTIVE:'secondary', SUSPENDED:'danger', PENDING_VERIFICATION:'warning', PENDING:'warning', DELIVERED:'success', CANCELLED:'danger' };
    return m[s] ?? 'secondary';
  }
  showAlert(msg: string, type: string): void {
    this.alertMsg = msg; this.alertType = type; setTimeout(() => this.alertMsg = '', 4000);
  }
}
