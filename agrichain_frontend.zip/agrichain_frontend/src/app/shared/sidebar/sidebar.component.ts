import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

export interface NavItem {
  label: string;
  icon:  string;
  section?: string;
  action?: () => void;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  @Input() navItems: NavItem[] = [];
  @Input() activeSection = '';
  @Input() onSectionChange!: (s: string) => void;

  userName = '';
  userRole = '';
  userInitials = '';

  constructor(private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    const user = this.auth.getCurrentUser();
    if (user) {
      this.userName = user.name;
      this.userRole = user.role.replace(/_/g, ' ');
      this.userInitials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2);
    }
  }

  navigate(item: NavItem): void {
    if (item.action) { item.action(); return; }
    if (item.section && this.onSectionChange) this.onSectionChange(item.section);
  }

  logout(): void { this.auth.logout(); }
}
