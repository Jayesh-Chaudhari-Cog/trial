package com.project.controller;

import com.project.model.Company;
import com.project.service.CompanyService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/company")
public class CompanyController {

    private final CompanyService companyService;

    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    // Register company
    @PostMapping("/register")
    public Company register(@RequestParam String name) {
        return companyService.registerCompany(name);
    }

    // Record emission
    @PostMapping("/emission")
    public String recordEmission(@RequestParam String name,
                                 @RequestParam int co2) {
        return companyService.recordEmission(name, co2);
    }

    // Trade credits
    @PostMapping("/trade")
    public String trade(@RequestParam String from,
                        @RequestParam String to,
                        @RequestParam int amount) {
        return companyService.tradeCredits(from, to, amount);
    }

    // Get all companies (Admin only)
    @GetMapping("/all")
    public List<Company> getAllCompanies() {
        return companyService.getAllCompanies();
    }
}