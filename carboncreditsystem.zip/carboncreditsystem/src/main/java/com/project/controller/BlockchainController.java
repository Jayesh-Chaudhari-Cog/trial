package com.project.controller;

import com.project.blockchain.Block;
import com.project.service.BlockchainService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/blockchain")
public class BlockchainController {

    private final BlockchainService blockchainService;

    public BlockchainController(BlockchainService blockchainService) {
        this.blockchainService = blockchainService;
    }

    @GetMapping("/chain")
    public List<Block> getChain() {
        return blockchainService.getChain();
    }

    @GetMapping("/validate")
    public String validate() {
        if (blockchainService.isChainValid()) {
            return "Blockchain is valid ✅";
        } else {
            return "Blockchain is corrupted ❌";
        }
    }
}