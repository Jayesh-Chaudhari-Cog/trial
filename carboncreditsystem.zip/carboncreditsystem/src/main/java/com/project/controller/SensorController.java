package com.project.controller;

import com.project.service.BlockchainService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class SensorController {

    private final BlockchainService blockchainService;

    public SensorController(BlockchainService blockchainService) {
        this.blockchainService = blockchainService;
    }

    @GetMapping("/add")
    public String addSensorData(@RequestParam String data) {
        blockchainService.addBlock(data);
        return "Data added to Blockchain!";
    }

    @GetMapping("/chain")
    public List<?> getBlockchain() {
        return blockchainService.getChain();
    }
}