package com.project.service;

import com.project.model.Company;
import com.project.repository.CompanyRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyService {

    private final CompanyRepository companyRepository;
    private final BlockchainService blockchainService;

    public CompanyService(CompanyRepository companyRepository,
                          BlockchainService blockchainService) {
        this.companyRepository = companyRepository;
        this.blockchainService = blockchainService;
    }

    // Register new company with 10 credits
    public Company registerCompany(String name) {

        if (companyRepository.existsById(name)) {
            return companyRepository.findById(name).orElse(null);
        }

        Company company = new Company(name, 10);
        companyRepository.save(company);

        blockchainService.addBlock(
                "Company Registered | Name: " + name + " | Credits: 10"
        );

        return company;
    }

    // Get all companies
    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    // Record emission
    public String recordEmission(String name, int co2) {

        Company company = companyRepository.findById(name).orElse(null);

        if (company == null) {
            return "Company not found!";
        }

        int creditsToReduce = co2 / 100;

        if (company.getCarbonCredits() < creditsToReduce) {
            return "Not enough carbon credits!";
        }

        company.setCarbonCredits(
                company.getCarbonCredits() - creditsToReduce
        );

        companyRepository.save(company);

        blockchainService.addBlock(
                "Emission Recorded | Company: " + name +
                " | CO2: " + co2 +
                " | Credits Reduced: " + creditsToReduce
        );

        return "Emission recorded successfully!";
    }

    // Trade credits
    public String tradeCredits(String from, String to, int amount) {

        Company sender = companyRepository.findById(from).orElse(null);
        Company receiver = companyRepository.findById(to).orElse(null);

        if (sender == null || receiver == null) {
            return "One or both companies not found!";
        }

        if (sender.getCarbonCredits() < amount) {
            return "Sender does not have enough credits!";
        }

        sender.setCarbonCredits(sender.getCarbonCredits() - amount);
        receiver.setCarbonCredits(receiver.getCarbonCredits() + amount);

        companyRepository.save(sender);
        companyRepository.save(receiver);

        blockchainService.addBlock(
                "Trade Executed | From: " + from +
                " | To: " + to +
                " | Amount: " + amount
        );

        return "Trade successful!";
    }
}