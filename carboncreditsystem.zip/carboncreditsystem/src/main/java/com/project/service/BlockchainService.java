package com.project.service;

import com.project.blockchain.Block;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BlockchainService {

    private List<Block> chain = new ArrayList<>();

    public BlockchainService() {
        chain.add(new Block(0, "Genesis Block", "0"));
    }

    public void addBlock(String data) {
        Block previousBlock = chain.get(chain.size() - 1);
        Block newBlock = new Block(chain.size(), data, previousBlock.getHash());
        chain.add(newBlock);
    }

    public List<Block> getChain() {
        return chain;
    }
    
    public boolean isChainValid() {

        for (int i = 1; i < chain.size(); i++) {

            Block currentBlock = chain.get(i);
            Block previousBlock = chain.get(i - 1);

            // Recalculate hash and compare
            if (!currentBlock.getHash().equals(currentBlock.calculateHash())) {
                return false;
            }

            // Compare previous hash link
            if (!currentBlock.getPreviousHash().equals(previousBlock.getHash())) {
                return false;
            }
        }

        return true;
    }
}