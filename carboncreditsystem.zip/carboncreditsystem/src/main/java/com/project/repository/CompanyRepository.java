package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.model.Company;

public interface CompanyRepository extends JpaRepository<Company, String> {
}