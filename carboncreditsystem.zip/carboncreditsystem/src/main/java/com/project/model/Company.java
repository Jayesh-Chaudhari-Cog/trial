package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Company {

    @Id
    private String name;

    private int carbonCredits;

    public Company() {}

    public Company(String name, int carbonCredits) {
        this.name = name;
        this.carbonCredits = carbonCredits;
    }

    public String getName() {
        return name;
    }

    public int getCarbonCredits() {
        return carbonCredits;
    }

    public void setCarbonCredits(int carbonCredits) {
        this.carbonCredits = carbonCredits;
    }
}