@echo off
REM AgriChain Backend Startup Script (Windows)

echo 🌿 AgriChain Backend Startup
echo ================================

echo Starting Eureka Server (port 8761)...
start "Eureka-Server" cmd /k "cd /d %~dp0Eureka-Server && mvn spring-boot:run"
timeout /t 12 /nobreak >nul

echo Starting Registration Service (port 8091)...
start "Registration" cmd /k "cd /d %~dp0Registration && mvn spring-boot:run"
timeout /t 10 /nobreak >nul

echo Starting API Gateway (port 8090)...
start "API-Gateway" cmd /k "cd /d %~dp0API-Gateway && mvn spring-boot:run"
timeout /t 10 /nobreak >nul

echo Starting Crop Listing Service (port 8081)...
start "Croplisting-Order" cmd /k "cd /d %~dp0Croplisting-Order && mvn spring-boot:run"
timeout /t 8 /nobreak >nul

echo Starting Transaction Service (port 8093)...
start "Transaction-Payment" cmd /k "cd /d %~dp0Transaction-Payment && mvn spring-boot:run"
timeout /t 8 /nobreak >nul

echo Starting Subsidy Service (port 9091)...
start "Subsidy" cmd /k "cd /d %~dp0Subsidy && mvn spring-boot:run"
timeout /t 8 /nobreak >nul

echo Starting Audit Service (port 8094)...
start "Audit-Compliance" cmd /k "cd /d %~dp0Audit-Compliance && mvn spring-boot:run"
timeout /t 8 /nobreak >nul

echo Starting Report Service (port 8095)...
start "report-service" cmd /k "cd /d %~dp0report-service && mvn spring-boot:run"
timeout /t 8 /nobreak >nul

echo.
echo ================================
echo All services started in separate windows!
echo.
echo Eureka Dashboard: http://localhost:8761
echo API Gateway:      http://localhost:8090
echo.
echo Now start frontend: cd agrichain-frontend ^&^& npm install ^&^& npm start
pause
