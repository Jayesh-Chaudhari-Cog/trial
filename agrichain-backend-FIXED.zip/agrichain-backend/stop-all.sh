#!/bin/bash
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "🛑 Stopping all AgriChain services..."
for pidfile in "$BASE_DIR/pids"/*.pid; do
    [ -f "$pidfile" ] || continue
    name=$(basename "$pidfile" .pid)
    pid=$(cat "$pidfile")
    if kill -0 "$pid" 2>/dev/null; then
        kill "$pid"
        echo "  ✓ Stopped $name (PID $pid)"
    fi
    rm -f "$pidfile"
done
echo "✅ All services stopped."
