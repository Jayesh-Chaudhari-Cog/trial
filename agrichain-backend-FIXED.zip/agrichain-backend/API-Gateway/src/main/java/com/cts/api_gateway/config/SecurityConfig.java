package com.cts.api_gateway.config;

import com.cts.api_gateway.filter.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.http.HttpMethod;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(
            "http://localhost:3000",
            "http://localhost:3001",
            "http://127.0.0.1:3000"
        ));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"));
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "Accept", "X-Requested-With"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http, JwtFilter jwtFilter) {
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .cors(corsSpec -> corsSpec.configurationSource(corsConfigurationSource()))
                .authorizeExchange(exchanges -> exchanges
                        // Public Endpoints
                        .pathMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .pathMatchers("/users/login", "/users/register", "/actuator/**").permitAll()
                        .pathMatchers("/market/test-proxy").permitAll()

                        // Role-based Endpoints
                        .pathMatchers("/api/report/**").hasAnyRole("ADMIN", "MANAGER", "AUDITOR")
                        .pathMatchers("/api/transactions/**").hasAnyRole("TRADER", "FARMER", "ADMIN")

                        // Crop Listing Permissions
                        .pathMatchers(HttpMethod.POST, "/market/createlisting").hasAnyRole("FARMER", "ADMIN", "OFFICER")
                        .pathMatchers(HttpMethod.PUT, "/market/listings/validate/**").hasAnyRole("OFFICER", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/market/listings/**").authenticated()
                        .pathMatchers(HttpMethod.GET, "/market/**").authenticated()

                        // Order Permissions
                        .pathMatchers(HttpMethod.POST, "/market/placeorder").hasAnyRole("TRADER", "ADMIN")
                        .pathMatchers("/market/orders/**").authenticated()

                        // Farmer Management
                        .pathMatchers("/farmers/**").authenticated()

                        // Documents
                        .pathMatchers("/documents/**").authenticated()

                        // API Logs
                        .pathMatchers("/api/logs/**").authenticated()

                        // Subsidy Program
                        .pathMatchers(HttpMethod.POST, "/subsidy-programs/**").hasAnyRole("ADMIN", "MANAGER")
                        .pathMatchers(HttpMethod.PUT, "/subsidy-programs/**").hasAnyRole("ADMIN", "MANAGER")
                        .pathMatchers(HttpMethod.DELETE, "/subsidy-programs/**").hasAnyRole("ADMIN", "MANAGER")
                        .pathMatchers(HttpMethod.GET, "/subsidy-programs/**").authenticated()

                        // Disbursement
                        .pathMatchers(HttpMethod.POST, "/disbursements/**").authenticated()
                        .pathMatchers(HttpMethod.PUT, "/disbursements/**").authenticated()
                        .pathMatchers(HttpMethod.PATCH, "/disbursements/*/review").authenticated()
                        .pathMatchers(HttpMethod.GET, "/disbursements/**").authenticated()

                        // Transactions & Payments
                        .pathMatchers("/transactions/**").authenticated()
                        .pathMatchers("/payments/**").authenticated()

                        // Audit & Compliance
                        .pathMatchers("/api/audits/**").hasAnyRole("AUDITOR", "ADMIN", "MANAGER", "OFFICER")
                        .pathMatchers("/api/compliances/**").authenticated()
                        .pathMatchers(HttpMethod.POST, "/api/auditlogs/**").authenticated()
                        .pathMatchers(HttpMethod.GET, "/api/auditlogs/**").authenticated()

                        .anyExchange().authenticated()
                )
                .addFilterAt(jwtFilter, SecurityWebFiltersOrder.AUTHENTICATION)
                .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
