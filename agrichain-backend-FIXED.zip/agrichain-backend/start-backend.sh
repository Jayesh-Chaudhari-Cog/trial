#!/bin/bash
# AgriChain Backend Startup Script
# Starts all microservices in correct dependency order

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "🌿 AgriChain Backend Startup"
echo "================================"
echo "Starting services in dependency order..."
echo ""

start_service() {
  local name=$1
  local dir=$2
  local port=$3

  echo "▶ Starting $name on port $port..."
  cd "$SCRIPT_DIR/$dir"
  mvn spring-boot:run -q &
  sleep 8
  echo "  ✓ $name started (PID: $!)"
  echo ""
}

# 1. Eureka Server - Service Registry (must be first)
start_service "Eureka Server" "Eureka-Server" 8761

# 2. Registration Service - needed for JWT auth
start_service "Registration Service" "Registration" 8091

# 3. API Gateway - routes traffic, needs Eureka + Registration
start_service "API Gateway" "API-Gateway" 8090

# 4. Crop Listing & Order Service
start_service "Crop Listing Service" "Croplisting-Order" 8081

# 5. Transaction & Payment Service
start_service "Transaction Service" "Transaction-Payment" 8093

# 6. Subsidy Service
start_service "Subsidy Service" "Subsidy" 9091

# 7. Audit & Compliance Service
start_service "Audit Service" "Audit-Compliance" 8094

# 8. Report Service
start_service "Report Service" "report-service" 8095

echo "================================"
echo "✅ All services started!"
echo ""
echo "🌐 Eureka Dashboard: http://localhost:8761"
echo "🔀 API Gateway:      http://localhost:8090"
echo "💻 Frontend (start separately): cd agrichain-frontend && npm start"
echo ""
echo "Press Ctrl+C to stop all services"
wait
