# AgriChain Backend — Spring Boot Microservices

## Prerequisites
- Java 17+, Maven 3.8+, MySQL 8.0+

## Database Setup
```sql
CREATE DATABASE registration_db;
CREATE DATABASE croplisting_db;
CREATE DATABASE transaction_db;
CREATE DATABASE subsidy_db;
CREATE DATABASE audit_db;
CREATE DATABASE report_db;
```

## Startup Order
1. Eureka-Server :8761
2. Registration :8091
3. API-Gateway :8090
4. Croplisting-Order :8081
5. Transaction-Payment :8093
6. Subsidy :9091
7. Audit-Compliance :8094
8. report-service :8095

## Quick Start
Linux/Mac: `chmod +x start-backend.sh && ./start-backend.sh`
Windows: double-click `start-backend.bat`
Manual: `cd <service> && mvn spring-boot:run`

## What Was Changed
- API-Gateway SecurityConfig.java: added CORS bean so Security headers pass through
- Registration WebConfig.java: added addCorsMappings for localhost:3000
- All other services already had CorsConfig.java configured
