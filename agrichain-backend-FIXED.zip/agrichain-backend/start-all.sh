#!/bin/bash
# AgriChain Backend - Start All Microservices
# Run this script from the root of agrichain-backend folder

echo "🌿 AgriChain Backend Startup"
echo "=============================="

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

start_service() {
    local name="$1"
    local dir="$2"
    local port="$3"
    echo -e "${YELLOW}▶ Starting $name on port $port...${NC}"
    cd "$BASE_DIR/$dir"
    nohup mvn spring-boot:run > "$BASE_DIR/logs/${name}.log" 2>&1 &
    echo $! > "$BASE_DIR/pids/${name}.pid"
    echo -e "${GREEN}  ✓ $name started (PID $!)${NC}"
    cd "$BASE_DIR"
}

mkdir -p "$BASE_DIR/logs" "$BASE_DIR/pids"

echo ""
echo "Step 1: Starting Eureka Server (Service Registry)..."
start_service "eureka-server" "Eureka-Server" "8761"
echo "  Waiting 20s for Eureka to be ready..."
sleep 20

echo ""
echo "Step 2: Starting Registration Service..."
start_service "registration" "Registration" "8091"
sleep 10

echo ""
echo "Step 3: Starting API Gateway..."
start_service "api-gateway" "API-Gateway" "8090"
sleep 8

echo ""
echo "Step 4: Starting Crop Listing Service..."
start_service "croplisting" "Croplisting-Order" "8081"
sleep 6

echo ""
echo "Step 5: Starting Transaction-Payment Service..."
start_service "transaction" "Transaction-Payment" "8093"
sleep 6

echo ""
echo "Step 6: Starting Subsidy Service..."
start_service "subsidy" "Subsidy" "9091"
sleep 6

echo ""
echo "Step 7: Starting Audit-Compliance Service..."
start_service "audit" "Audit-Compliance" "8094"
sleep 6

echo ""
echo "Step 8: Starting Report Service..."
start_service "report" "report-service" "8095"
sleep 4

echo ""
echo "=============================="
echo -e "${GREEN}✅ All services started!${NC}"
echo ""
echo "Service URLs:"
echo "  Eureka Dashboard  → http://localhost:8761"
echo "  API Gateway       → http://localhost:8090"
echo "  Registration      → http://localhost:8091"
echo "  Crop Listing      → http://localhost:8081"
echo "  Transaction       → http://localhost:8093"
echo "  Subsidy           → http://localhost:9091"
echo "  Audit             → http://localhost:8094"
echo "  Report            → http://localhost:8095"
echo ""
echo "Logs are in: $BASE_DIR/logs/"
echo "To stop all: ./stop-all.sh"
