package com.cts.agrichain.subsidy.service;
// Placeholder - JWT authentication handled via token claims in JwtFilter
public class SecurityServiceImpl {}
