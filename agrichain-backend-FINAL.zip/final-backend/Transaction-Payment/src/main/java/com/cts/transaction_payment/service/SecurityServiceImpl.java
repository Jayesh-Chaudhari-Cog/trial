package com.cts.transaction_payment.service;
// Placeholder - JWT authentication handled via token claims in JwtFilter
public class SecurityServiceImpl {}
