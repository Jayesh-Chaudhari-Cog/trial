package com.cts.croplisting_service.filter;

import com.cts.croplisting_service.service.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired private JwtService jwtService;

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        String header = req.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            if (SecurityContextHolder.getContext().getAuthentication() == null) {
                try {
                    String username = jwtService.extractUserName(token);
                    String role     = jwtService.extractRole(token);
                    if (username != null && !jwtService.isTokenExpired(token)) {
                        String auth = role.startsWith("ROLE_") ? role : "ROLE_" + role;
                        UsernamePasswordAuthenticationToken token2 =
                                new UsernamePasswordAuthenticationToken(username, null,
                                        List.of(new SimpleGrantedAuthority(auth)));
                        token2.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
                        SecurityContextHolder.getContext().setAuthentication(token2);
                    }
                } catch (Exception e) {
                    System.err.println("Croplisting JWT failed: " + e.getMessage());
                }
            }
        }
        chain.doFilter(req, res);
    }
}
