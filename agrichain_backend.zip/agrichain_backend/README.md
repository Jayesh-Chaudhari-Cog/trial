# 🌾 AgriChain – Agricultural Supply Chain & Market Linkage System

A production-ready, full-stack microservices application connecting farmers, traders, government bodies, and market stakeholders across the agricultural supply chain.

---

## 📋 Table of Contents
- [Architecture](#architecture)
- [Tech Stack](#tech-stack)
- [System Roles](#system-roles)
- [Modules](#modules)
- [Quick Start (Docker)](#quick-start-docker)
- [Manual Setup](#manual-setup)
- [API Reference](#api-reference)
- [Demo Credentials](#demo-credentials)
- [Service Ports](#service-ports)

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Angular Frontend                      │
│              (Port 4200 / Docker: 80)                   │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP / REST
┌────────────────────────▼────────────────────────────────┐
│              API Gateway (Port 8090)                    │
│         JWT Validation · CORS · Load Balancing          │
└──┬──────┬──────┬──────┬──────┬──────┬──────┬───────────┘
   │      │      │      │      │      │      │
   ▼      ▼      ▼      ▼      ▼      ▼      ▼
 Reg   Crop   Txn   Sub   Aud  Notif  Rpt   (Eureka: 8761)
 8091  8092  8093  8094  8095  8096  8097
   │      │      │      │      │      │      │
   └──────┴──────┴──────┴──────┴──────┴──────┘
                         │
              ┌──────────▼──────────┐
              │   MySQL Database    │
              │    (Port 3306)      │
              └─────────────────────┘
```

---

## 🛠️ Tech Stack

| Layer       | Technology                                         |
|-------------|----------------------------------------------------|
| Frontend    | Angular 19, TypeScript, SCSS                       |
| Backend     | Spring Boot 3.4.3, Java 21, Spring Cloud 2024.0.0 |
| Gateway     | Spring Cloud Gateway (reactive)                    |
| Discovery   | Netflix Eureka Server                              |
| Database    | MySQL 8.0                                          |
| Auth        | JWT (JJWT 0.12.5), BCrypt password hashing         |
| Container   | Docker, Docker Compose                             |
| Web Server  | Nginx (frontend), embedded Tomcat (backend)        |

---

## 👥 System Roles

| Role                | Dashboard URL              | Capabilities                                      |
|---------------------|---------------------------|---------------------------------------------------|
| Farmer              | `/dashboard/farmer`        | Listings, Orders, Subsidies, Market Prices        |
| Trader/Buyer        | `/dashboard/trader`        | Browse Crops, Place Orders, Payments              |
| Market Officer      | `/dashboard/market-officer`| Manage Listings, Market Prices, Order Monitoring  |
| Program Manager     | `/dashboard/program-manager`| Subsidy Programs, Disbursements, Reports         |
| Admin               | `/dashboard/admin`         | Full system access, User Management               |
| Compliance Officer  | `/dashboard/compliance`    | KYC, Document Verification, Compliance Checks     |
| Government Auditor  | `/dashboard/auditor`       | Read-only audit access, Reports, Audit Trail      |

---

## 🧩 Modules

1. **Identity & Access Management** – JWT auth, RBAC, user registration
2. **Farmer Management** – Profiles, documents, status management
3. **Crop Listing & Market Linkage** – Create listings, browse, search, market prices
4. **Transactions & Payments** – Order payment lifecycle, UPI/NEFT/RTGS
5. **Subsidy Management** – Program creation, applications, disbursements
6. **Compliance & Audit** – KYC checks, document verification, audit trail
7. **Reporting & Analytics** – Dashboard metrics, report generation
8. **Notifications** – In-app event-driven notification system

---

## 🚀 Quick Start (Docker)

### Prerequisites
- Docker 24+ and Docker Compose v2+
- 8 GB RAM recommended
- Ports 80, 3306, 8090–8097, 8761 must be free

### Steps

```bash
# 1. Clone / extract the project
cd agrichain_backend

# 2. Copy environment file
cp .env.example .env

# 3. Start all services
docker compose up -d --build

# 4. Wait for services to be healthy (~2-3 minutes)
docker compose ps

# 5. Open the app
open http://localhost
# API Gateway: http://localhost:8090
# Eureka Dashboard: http://localhost:8761
```

### Stop Services
```bash
docker compose down
# To also remove database volume:
docker compose down -v
```

---

## 💻 Manual Setup (Development)

### Prerequisites
- Java 21 (JDK)
- Maven 3.9+
- Node.js 20+ and npm 10+
- MySQL 8.0
- Angular CLI 19: `npm install -g @angular/cli@19`

### 1. Database Setup

```bash
mysql -u root -p < schema.sql
```

### 2. Start Backend Services (in order)

```bash
# Terminal 1 – Eureka Server
cd eureka-server && mvn spring-boot:run

# Terminal 2 – API Gateway
cd api-gateway && mvn spring-boot:run

# Terminal 3 – Registration Service
cd registration-service && mvn spring-boot:run

# Terminal 4 – CropListing Service
cd croplisting-service && mvn spring-boot:run

# Terminal 5 – Transaction Service
cd transaction-service && mvn spring-boot:run

# Terminal 6 – Subsidy Service
cd subsidy-service && mvn spring-boot:run

# Terminal 7 – Audit Service
cd audit-service && mvn spring-boot:run

# Terminal 8 – Notification Service
cd notification-service && mvn spring-boot:run

# Terminal 9 – Report Service
cd report-service && mvn spring-boot:run
```

### 3. Start Frontend

```bash
cd agrichain_frontend
npm install --legacy-peer-deps
ng serve
# Opens at http://localhost:4200
```

---

## 🔑 Demo Credentials

All demo accounts use password: **`Admin@123`**

| Role                | Email                        |
|---------------------|------------------------------|
| Admin               | admin@agrichain.in           |
| Market Officer      | officer@agrichain.in         |
| Program Manager     | manager@agrichain.in         |
| Government Auditor  | auditor@agrichain.in         |
| Compliance Officer  | compliance@agrichain.in      |
| Farmer 1            | farmer1@example.com          |
| Farmer 2            | farmer2@example.com          |
| Trader 1            | trader1@example.com          |
| Trader 2            | trader2@example.com          |

---

## 🌐 Service Ports

| Service              | Port  |
|----------------------|-------|
| MySQL Database       | 3306  |
| Eureka Server        | 8761  |
| API Gateway          | 8090  |
| Registration Service | 8091  |
| CropListing Service  | 8092  |
| Transaction Service  | 8093  |
| Subsidy Service      | 8094  |
| Audit Service        | 8095  |
| Notification Service | 8096  |
| Report Service       | 8097  |
| Angular Frontend     | 4200 (dev) / 80 (Docker) |

---

## 📡 API Reference

### Auth
```
POST /api/auth/register   – Register new user
POST /api/auth/login      – Login (returns JWT)
```

### Farmers
```
GET    /api/farmers           – List all farmers
GET    /api/farmers/{id}      – Get farmer by ID
GET    /api/farmers/by-user/{userId}
PUT    /api/farmers/{id}      – Update farmer
PATCH  /api/farmers/{id}/status
POST   /api/farmers/{id}/documents
GET    /api/farmers/{id}/documents
PATCH  /api/farmers/documents/{docId}/verify
```

### Crop Listings
```
GET    /api/listings          – All listings
GET    /api/listings/active   – Active listings
GET    /api/listings/farmer/{farmerId}
GET    /api/listings/search?crop=Wheat
POST   /api/listings          – Create listing
PUT    /api/listings/{id}     – Update listing
PATCH  /api/listings/{id}/status
GET    /api/listings/stats
```

### Orders
```
GET    /api/orders            – All orders
POST   /api/orders            – Place order
GET    /api/orders/buyer/{buyerUserId}
GET    /api/orders/farmer/{farmerId}
GET    /api/orders/{id}
PATCH  /api/orders/{id}/status
```

### Market Prices
```
GET    /api/market/prices             – Latest prices
GET    /api/market/prices/{cropName}  – By crop
POST   /api/market/prices             – Add price
```

### Transactions & Payments
```
POST   /api/transactions/initiate
GET    /api/transactions
GET    /api/transactions/{id}
GET    /api/transactions/stats
POST   /api/payments/initiate
PATCH  /api/payments/{id}/complete
PATCH  /api/payments/{id}/fail
```

### Subsidies
```
GET    /api/subsidies          – All programs
GET    /api/subsidies/active   – Active programs
POST   /api/subsidies          – Create program
PATCH  /api/subsidies/{id}/status
GET    /api/subsidies/stats
POST   /api/disbursements      – Apply for subsidy
GET    /api/disbursements/farmer/{farmerId}
GET    /api/disbursements/pending
PATCH  /api/disbursements/{id}/status
```

### Audits & Compliance
```
GET    /api/audits             – All audits
POST   /api/audits             – Create audit
PUT    /api/audits/{id}        – Update audit
GET    /api/audits/stats
GET    /api/compliance         – All compliance records
POST   /api/compliance         – Create check
PATCH  /api/compliance/{id}/result
GET    /api/audit-logs         – System audit logs
```

### Notifications
```
GET    /api/notifications/user/{userId}
GET    /api/notifications/user/{userId}/unread
GET    /api/notifications/user/{userId}/unread-count
PATCH  /api/notifications/{id}/read
PATCH  /api/notifications/user/{userId}/mark-all-read
POST   /api/notifications/event/order-placed
POST   /api/notifications/event/payment-success
POST   /api/notifications/event/subsidy-approved
POST   /api/notifications/event/compliance-action
```

### Reports
```
GET    /api/reports
POST   /api/reports
GET    /api/reports/user/{userId}
GET    /api/reports/type/{type}
```

---

## 🔒 Security Notes

- All passwords hashed with BCrypt (strength 12)
- JWT tokens expire in 10 hours (configurable)
- API Gateway validates JWT on all non-public endpoints
- Public endpoints: `/api/auth/login`, `/api/auth/register`, `/api/market/prices`
- CORS configured for `http://localhost:4200` (update for production)

---

## 📁 Project Structure

```
agrichain/
├── agrichain_backend/
│   ├── docker-compose.yml
│   ├── schema.sql
│   ├── .env.example
│   ├── README.md
│   ├── eureka-server/
│   ├── api-gateway/
│   ├── registration-service/
│   ├── croplisting-service/
│   ├── transaction-service/
│   ├── subsidy-service/
│   ├── audit-service/
│   ├── notification-service/
│   └── report-service/
└── agrichain_frontend/
    ├── src/
    │   ├── app/
    │   │   ├── pages/
    │   │   │   ├── login/
    │   │   │   ├── register/
    │   │   │   └── dashboard/
    │   │   │       ├── farmer/
    │   │   │       ├── trader/
    │   │   │       ├── admin/
    │   │   │       ├── market-officer/
    │   │   │       ├── program-manager/
    │   │   │       ├── compliance/
    │   │   │       └── auditor/
    │   │   ├── services/
    │   │   ├── guards/
    │   │   ├── interceptors/
    │   │   ├── models/
    │   │   └── shared/
    │   ├── environments/
    │   └── styles.scss
    ├── Dockerfile
    ├── nginx.conf
    └── package.json
```

---

## 🐛 Troubleshooting

**Services not registering with Eureka?**
- Wait 30–60 seconds after starting Eureka before starting other services
- Check `EUREKA_HOST` environment variable is set correctly

**MySQL connection refused?**
- Ensure MySQL is running: `docker compose ps mysql`
- Check DB credentials in `.env`

**CORS errors in browser?**
- Ensure API Gateway CORS is configured for your frontend URL
- In `api-gateway/src/main/resources/application.yml`, update `allowedOrigins`

**JWT token errors?**
- Ensure `jwt.secret` is identical in all services
- Default: `QWdyaUNoYWluU2VjcmV0S2V5MjAyNUFncmlDaGFpblNlY3JldEtleQ==`
