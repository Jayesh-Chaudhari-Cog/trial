package com.agrichain.audit.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "compliance_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "compliance_id") private Long id;

    @Column(name = "farmer_id", nullable = false) private Long farmerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "compliance_type", nullable = false) private ComplianceType complianceType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private ComplianceResult result;

    @Column(name = "officer_id") private Long officerId;
    @Column(columnDefinition = "TEXT") private String notes;
    @Column(name = "valid_until") private LocalDate validUntil;
    @Column(name = "checked_at") private LocalDateTime checkedAt;
    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;

    public enum ComplianceType { KYC, LAND_VERIFICATION, QUALITY_CHECK, FINANCIAL, ENVIRONMENTAL }
    public enum ComplianceResult { COMPLIANT, NON_COMPLIANT, PENDING, UNDER_REVIEW }
}
