package com.agrichain.audit.dao;
import com.agrichain.audit.entity.Audit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface AuditRepo extends JpaRepository<Audit, Long> {
    List<Audit> findByAuditorId(Long auditorId);
    List<Audit> findByStatus(Audit.AuditStatus status);
    List<Audit> findByAuditScope(Audit.AuditScope scope);
}
