package com.agrichain.audit.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "audits")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Audit {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "audit_id") private Long id;

    @Column(nullable = false) private String title;
    @Column(columnDefinition = "TEXT") private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "audit_scope", nullable = false) private AuditScope auditScope;

    @Column(name = "target_id") private Long targetId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private AuditStatus status;

    @Column(name = "auditor_id") private Long auditorId;
    @Column(columnDefinition = "TEXT") private String findings;
    @Column(name = "scheduled_date") private LocalDate scheduledDate;
    @Column(name = "completed_date") private LocalDate completedDate;

    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;
    @UpdateTimestamp @Column(name = "updated_at") private LocalDateTime updatedAt;

    public enum AuditScope { FARMER, TRANSACTION, SUBSIDY, COMPLIANCE, SYSTEM }
    public enum AuditStatus { PLANNED, IN_PROGRESS, COMPLETED, CANCELLED }
}
