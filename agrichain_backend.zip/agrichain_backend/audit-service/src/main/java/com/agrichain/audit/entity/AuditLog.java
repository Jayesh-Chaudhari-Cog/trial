package com.agrichain.audit.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "audit_logs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id") private Long id;

    @Column(name = "user_id") private Long userId;
    @Column(nullable = false, length = 100) private String action;
    @Column(name = "entity_type", length = 50) private String entityType;
    @Column(name = "entity_id", length = 50) private String entityId;
    @Column(name = "old_value", columnDefinition = "TEXT") private String oldValue;
    @Column(name = "new_value", columnDefinition = "TEXT") private String newValue;
    @Column(name = "ip_address", length = 45) private String ipAddress;
    @Enumerated(EnumType.STRING) private LogStatus status;
    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;

    public enum LogStatus { SUCCESS, FAILURE }
}
