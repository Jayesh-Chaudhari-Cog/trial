package com.agrichain.audit.service;

import com.agrichain.audit.dao.AuditLogRepo;
import com.agrichain.audit.dao.AuditRepo;
import com.agrichain.audit.dao.ComplianceRepo;
import com.agrichain.audit.entity.Audit;
import com.agrichain.audit.entity.AuditLog;
import com.agrichain.audit.entity.ComplianceRecord;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
public class AuditService {

    @Autowired private AuditRepo auditRepo;
    @Autowired private ComplianceRepo complianceRepo;
    @Autowired private AuditLogRepo auditLogRepo;

    // ---- AUDITS ----
    @Transactional
    public Audit createAudit(Map<String, String> body) {
        Audit audit = Audit.builder()
                .title(body.get("title"))
                .description(body.get("description"))
                .auditScope(Audit.AuditScope.valueOf(body.getOrDefault("auditScope", "SYSTEM").toUpperCase()))
                .targetId(body.get("targetId") != null ? Long.parseLong(body.get("targetId")) : null)
                .status(Audit.AuditStatus.PLANNED)
                .auditorId(body.get("auditorId") != null ? Long.parseLong(body.get("auditorId")) : null)
                .scheduledDate(body.get("scheduledDate") != null ? LocalDate.parse(body.get("scheduledDate")) : null)
                .build();
        return auditRepo.save(audit);
    }

    public List<Audit> getAllAudits() { return auditRepo.findAll(); }

    public Audit getAuditById(Long id) {
        return auditRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Audit not found: " + id));
    }

    public List<Audit> getAuditsByAuditor(Long auditorId) {
        return auditRepo.findByAuditorId(auditorId);
    }

    public List<Audit> getAuditsByStatus(String status) {
        return auditRepo.findByStatus(Audit.AuditStatus.valueOf(status.toUpperCase()));
    }

    @Transactional
    public Audit updateAudit(Long id, Map<String, String> body) {
        Audit audit = getAuditById(id);
        if (body.get("status") != null)
            audit.setStatus(Audit.AuditStatus.valueOf(body.get("status").toUpperCase()));
        if (body.get("findings") != null)
            audit.setFindings(body.get("findings"));
        if (body.get("completedDate") != null)
            audit.setCompletedDate(LocalDate.parse(body.get("completedDate")));
        return auditRepo.save(audit);
    }

    // ---- COMPLIANCE ----
    @Transactional
    public ComplianceRecord createCompliance(Map<String, String> body) {
        ComplianceRecord record = ComplianceRecord.builder()
                .farmerId(Long.parseLong(body.get("farmerId")))
                .complianceType(ComplianceRecord.ComplianceType.valueOf(
                        body.get("complianceType").toUpperCase()))
                .result(ComplianceRecord.ComplianceResult.PENDING)
                .officerId(body.get("officerId") != null ? Long.parseLong(body.get("officerId")) : null)
                .notes(body.get("notes"))
                .checkedAt(LocalDateTime.now())
                .validUntil(body.get("validUntil") != null ? LocalDate.parse(body.get("validUntil")) : null)
                .build();
        return complianceRepo.save(record);
    }

    public List<ComplianceRecord> getAllCompliance() { return complianceRepo.findAll(); }

    public List<ComplianceRecord> getComplianceByFarmer(Long farmerId) {
        return complianceRepo.findByFarmerId(farmerId);
    }

    @Transactional
    public ComplianceRecord updateComplianceResult(Long id, String result, String notes) {
        ComplianceRecord record = complianceRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Compliance record not found: " + id));
        record.setResult(ComplianceRecord.ComplianceResult.valueOf(result.toUpperCase()));
        if (notes != null) record.setNotes(notes);
        record.setCheckedAt(LocalDateTime.now());
        return complianceRepo.save(record);
    }

    // ---- AUDIT LOGS ----
    @Transactional
    public AuditLog createLog(Long userId, String action, String entityType,
                               String entityId, String oldValue, String newValue, String ipAddress) {
        AuditLog log = AuditLog.builder()
                .userId(userId).action(action).entityType(entityType)
                .entityId(entityId).oldValue(oldValue).newValue(newValue)
                .ipAddress(ipAddress).status(AuditLog.LogStatus.SUCCESS)
                .build();
        return auditLogRepo.save(log);
    }

    public List<AuditLog> getRecentLogs(int limit) {
        return auditLogRepo.findAllByOrderByCreatedAtDesc(PageRequest.of(0, limit)).getContent();
    }

    public List<AuditLog> getLogsByUser(Long userId) {
        return auditLogRepo.findByUserId(userId);
    }

    public List<AuditLog> getAllLogs() { return auditLogRepo.findAll(); }

    // ---- STATS ----
    public Map<String, Object> getStats() {
        long compliant = complianceRepo.findByResult(ComplianceRecord.ComplianceResult.COMPLIANT).size();
        long nonCompliant = complianceRepo.findByResult(ComplianceRecord.ComplianceResult.NON_COMPLIANT).size();
        return Map.of(
            "totalAudits", auditRepo.count(),
            "plannedAudits", auditRepo.findByStatus(Audit.AuditStatus.PLANNED).size(),
            "completedAudits", auditRepo.findByStatus(Audit.AuditStatus.COMPLETED).size(),
            "totalComplianceChecks", complianceRepo.count(),
            "compliantCount", compliant,
            "nonCompliantCount", nonCompliant,
            "totalLogs", auditLogRepo.count()
        );
    }
}
