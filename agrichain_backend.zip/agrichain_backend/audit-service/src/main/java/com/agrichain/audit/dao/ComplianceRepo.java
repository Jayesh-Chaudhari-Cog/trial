package com.agrichain.audit.dao;
import com.agrichain.audit.entity.ComplianceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ComplianceRepo extends JpaRepository<ComplianceRecord, Long> {
    List<ComplianceRecord> findByFarmerId(Long farmerId);
    List<ComplianceRecord> findByResult(ComplianceRecord.ComplianceResult result);
}
