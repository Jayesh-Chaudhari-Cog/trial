package com.agrichain.audit.controller;

import com.agrichain.audit.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AuditController {

    @Autowired private AuditService service;

    @PostMapping("/audits")
    public ResponseEntity<?> create(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.createAudit(body)));
    }

    @GetMapping("/audits")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllAudits()));
    }

    @GetMapping("/audits/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAuditById(id)));
    }

    @GetMapping("/audits/auditor/{auditorId}")
    public ResponseEntity<?> getByAuditor(@PathVariable Long auditorId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAuditsByAuditor(auditorId)));
    }

    @GetMapping("/audits/status/{status}")
    public ResponseEntity<?> getByStatus(@PathVariable String status) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAuditsByStatus(status)));
    }

    @PutMapping("/audits/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.updateAudit(id, body)));
    }

    @GetMapping("/audits/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getStats()));
    }

    // COMPLIANCE
    @PostMapping("/compliance")
    public ResponseEntity<?> createCompliance(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.createCompliance(body)));
    }

    @GetMapping("/compliance")
    public ResponseEntity<?> getAllCompliance() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllCompliance()));
    }

    @GetMapping("/compliance/farmer/{farmerId}")
    public ResponseEntity<?> getByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getComplianceByFarmer(farmerId)));
    }

    @PatchMapping("/compliance/{id}/result")
    public ResponseEntity<?> updateResult(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data",
                service.updateComplianceResult(id, body.get("result"), body.get("notes"))));
    }

    // AUDIT LOGS
    @PostMapping("/audit-logs")
    public ResponseEntity<?> createLog(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data",
                service.createLog(
                        body.get("userId") != null ? Long.parseLong(body.get("userId")) : null,
                        body.get("action"), body.get("entityType"), body.get("entityId"),
                        body.get("oldValue"), body.get("newValue"), body.get("ipAddress")
                )));
    }

    @GetMapping("/audit-logs")
    public ResponseEntity<?> getLogs(@RequestParam(defaultValue = "50") int limit) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getRecentLogs(limit)));
    }

    @GetMapping("/audit-logs/user/{userId}")
    public ResponseEntity<?> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getLogsByUser(userId)));
    }
}
