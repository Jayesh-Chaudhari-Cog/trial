package com.agrichain.registration.dao;
import com.agrichain.registration.entity.FarmerDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface FarmerDocumentRepo extends JpaRepository<FarmerDocument, Long> {
    List<FarmerDocument> findByFarmer_Id(Long farmerId);
}
