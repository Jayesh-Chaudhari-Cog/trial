package com.agrichain.registration.enums;

public enum UserRole {
    FARMER,
    TRADER,
    MARKET_OFFICER,
    PROGRAM_MANAGER,
    ADMIN,
    COMPLIANCE_OFFICER,
    GOVERNMENT_AUDITOR
}
