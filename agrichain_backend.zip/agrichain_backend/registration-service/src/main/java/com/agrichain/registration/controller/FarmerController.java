package com.agrichain.registration.controller;

import com.agrichain.registration.dto.request.UserRequestDTO;
import com.agrichain.registration.dto.response.ApiResponse;
import com.agrichain.registration.dto.response.FarmerResponseDTO;
import com.agrichain.registration.entity.FarmerDocument;
import com.agrichain.registration.service.FarmerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/farmers")
public class FarmerController {

    @Autowired private FarmerService farmerService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MARKET_OFFICER','PROGRAM_MANAGER','GOVERNMENT_AUDITOR','COMPLIANCE_OFFICER','TRADER')")
    public ResponseEntity<ApiResponse<List<FarmerResponseDTO>>> getAllFarmers() {
        return ResponseEntity.ok(ApiResponse.success("Farmers fetched", farmerService.getAllFarmers()));
    }

    @GetMapping("/count")
    public ResponseEntity<ApiResponse<Long>> countFarmers() {
        return ResponseEntity.ok(ApiResponse.success("Count", farmerService.countFarmers()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<FarmerResponseDTO>> getFarmerById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Farmer fetched", farmerService.getFarmerById(id)));
    }

    @GetMapping("/by-user/{userId}")
    public ResponseEntity<ApiResponse<FarmerResponseDTO>> getFarmerByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("Farmer fetched", farmerService.getFarmerByUserId(userId)));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('ADMIN','MARKET_OFFICER','COMPLIANCE_OFFICER')")
    public ResponseEntity<ApiResponse<List<FarmerResponseDTO>>> getFarmersByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.success("Farmers by status", farmerService.getFarmersByStatus(status)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<FarmerResponseDTO>> updateFarmer(@PathVariable Long id,
                                                                         @RequestBody UserRequestDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("Farmer updated", farmerService.updateFarmer(id, dto)));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','MARKET_OFFICER','COMPLIANCE_OFFICER')")
    public ResponseEntity<ApiResponse<String>> updateStatus(@PathVariable Long id,
                                                             @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(ApiResponse.success("Status updated",
                farmerService.updateFarmerStatus(id, body.get("status"))));
    }

    @PostMapping("/{id}/documents")
    public ResponseEntity<ApiResponse<FarmerDocument>> addDocument(@PathVariable Long id,
                                                                     @RequestBody Map<String, String> body) {
        FarmerDocument doc = farmerService.addDocument(id, body.get("docType"),
                body.get("docUrl"), body.get("fileName"));
        return ResponseEntity.ok(ApiResponse.success("Document added", doc));
    }

    @GetMapping("/{id}/documents")
    public ResponseEntity<ApiResponse<List<FarmerDocument>>> getDocuments(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Documents fetched", farmerService.getDocuments(id)));
    }

    @PatchMapping("/documents/{docId}/verify")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE_OFFICER','MARKET_OFFICER')")
    public ResponseEntity<ApiResponse<String>> verifyDocument(@PathVariable Long docId,
                                                               @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(ApiResponse.success("Document verified",
                farmerService.verifyDocument(docId, body.get("status"))));
    }
}
