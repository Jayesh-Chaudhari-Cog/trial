package com.agrichain.registration.enums;
public enum VerificationStatus { PENDING, VERIFIED, REJECTED }
