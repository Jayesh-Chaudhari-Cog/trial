package com.agrichain.registration.service;

import com.agrichain.registration.dao.FarmerRepo;
import com.agrichain.registration.dao.UserRepo;
import com.agrichain.registration.dto.request.LoginRequestDTO;
import com.agrichain.registration.dto.request.UserRequestDTO;
import com.agrichain.registration.dto.response.LoginResponseDTO;
import com.agrichain.registration.dto.response.UserResponseDTO;
import com.agrichain.registration.entity.Farmer;
import com.agrichain.registration.entity.Users;
import com.agrichain.registration.enums.FarmerGender;
import com.agrichain.registration.enums.FarmerStatus;
import com.agrichain.registration.enums.UserRole;
import com.agrichain.registration.enums.UserStatus;
import com.agrichain.registration.exception.ResourceNotFoundException;
import com.agrichain.registration.exception.UserConflictException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class UserService {

    @Autowired private UserRepo userRepo;
    @Autowired private FarmerRepo farmerRepo;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private JWTService jwtService;

    @Transactional
    public String registerUser(UserRequestDTO dto) {
        if (userRepo.existsByEmail(dto.getEmail())) {
            throw new UserConflictException("Email already registered: " + dto.getEmail());
        }
        userRepo.findByPhone(dto.getPhone()).ifPresent(u -> {
            throw new UserConflictException("Phone number already registered: " + dto.getPhone());
        });

        UserRole role = (dto.getRole() != null) ? dto.getRole() : UserRole.FARMER;

        Users user = Users.builder()
                .email(dto.getEmail())
                .name(dto.getName())
                .phone(dto.getPhone())
                .password(passwordEncoder.encode(dto.getPassword()))
                .role(role)
                .status(UserStatus.ACTIVE)
                .build();

        Users saved = userRepo.save(user);

        if (role == UserRole.FARMER) {
            Farmer farmer = new Farmer();
            farmer.setUsers(saved);
            farmer.setName(saved.getName());
            farmer.setEmail(saved.getEmail());
            farmer.setContactInfo(saved.getPhone());
            farmer.setStatus(FarmerStatus.ACTIVE);

            if (dto.getDob() != null && !dto.getDob().isBlank()) {
                try { farmer.setDob(LocalDate.parse(dto.getDob())); } catch (Exception ignored) {}
            }
            if (dto.getGender() != null) {
                try { farmer.setGender(FarmerGender.valueOf(dto.getGender().toUpperCase())); } catch (Exception ignored) {}
            }
            farmer.setAddress(dto.getAddress());
            farmer.setLandDetails(dto.getLandDetails());
            farmer.setAadharNumber(dto.getAadharNumber());
            farmer.setBankAccount(dto.getBankAccount());
            farmer.setIfscCode(dto.getIfscCode());
            farmerRepo.save(farmer);
        }
        return "User registered successfully as " + role;
    }

    public LoginResponseDTO login(LoginRequestDTO dto) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getPassword()));
        } catch (Exception e) {
            throw new UserConflictException("Invalid email or password");
        }
        Users user = userRepo.findByEmail(dto.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        if (user.getStatus() != UserStatus.ACTIVE) {
            throw new UserConflictException("Account is not active");
        }
        String token = jwtService.generateToken(user.getEmail(), user.getRole().name());
        return new LoginResponseDTO(token, user.getRole().name(), user.getEmail(), user.getName(), user.getId());
    }

    public UserResponseDTO getUserById(Long id) {
        return mapToResponse(userRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id)));
    }

    public List<UserResponseDTO> getAllUsers() {
        return userRepo.findAll().stream().map(this::mapToResponse).toList();
    }

    @Transactional
    public UserResponseDTO updateUser(Long id, UserRequestDTO dto) {
        Users user = userRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        if (dto.getName() != null) user.setName(dto.getName());
        if (dto.getPhone() != null) user.setPhone(dto.getPhone());
        farmerRepo.findByUsers_Id(id).ifPresent(farmer -> {
            if (dto.getName() != null) farmer.setName(dto.getName());
            if (dto.getPhone() != null) farmer.setContactInfo(dto.getPhone());
            if (dto.getAddress() != null) farmer.setAddress(dto.getAddress());
            if (dto.getLandDetails() != null) farmer.setLandDetails(dto.getLandDetails());
            farmerRepo.save(farmer);
        });
        return mapToResponse(userRepo.save(user));
    }

    @Transactional
    public String deactivateUser(Long id) {
        Users user = userRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        user.setStatus(UserStatus.INACTIVE);
        userRepo.save(user);
        return "User deactivated successfully";
    }

    private UserResponseDTO mapToResponse(Users user) {
        return UserResponseDTO.builder()
                .id(user.getId()).name(user.getName()).email(user.getEmail())
                .phone(user.getPhone()).role(user.getRole()).status(user.getStatus())
                .build();
    }
}
