package com.agrichain.registration.controller;

import com.agrichain.registration.dto.request.LoginRequestDTO;
import com.agrichain.registration.dto.request.UserRequestDTO;
import com.agrichain.registration.dto.response.ApiResponse;
import com.agrichain.registration.dto.response.LoginResponseDTO;
import com.agrichain.registration.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> register(@Valid @RequestBody UserRequestDTO dto) {
        String msg = userService.registerUser(dto);
        return ResponseEntity.ok(ApiResponse.success(msg, null));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponseDTO>> login(@Valid @RequestBody LoginRequestDTO dto) {
        LoginResponseDTO response = userService.login(dto);
        return ResponseEntity.ok(ApiResponse.success("Login successful", response));
    }
}
