package com.agrichain.registration.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class LoginResponseDTO {
    private String token;
    private String role;
    private String email;
    private String name;
    private Long userId;
}
