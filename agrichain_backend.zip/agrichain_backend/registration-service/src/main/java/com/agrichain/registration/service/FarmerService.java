package com.agrichain.registration.service;

import com.agrichain.registration.dao.FarmerDocumentRepo;
import com.agrichain.registration.dao.FarmerRepo;
import com.agrichain.registration.dto.request.UserRequestDTO;
import com.agrichain.registration.dto.response.FarmerResponseDTO;
import com.agrichain.registration.entity.Farmer;
import com.agrichain.registration.entity.FarmerDocument;
import com.agrichain.registration.enums.DocType;
import com.agrichain.registration.enums.FarmerGender;
import com.agrichain.registration.enums.FarmerStatus;
import com.agrichain.registration.enums.VerificationStatus;
import com.agrichain.registration.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class FarmerService {

    @Autowired private FarmerRepo farmerRepo;
    @Autowired private FarmerDocumentRepo docRepo;

    public List<FarmerResponseDTO> getAllFarmers() {
        return farmerRepo.findAll().stream().map(this::toDto).toList();
    }

    public FarmerResponseDTO getFarmerById(Long id) {
        return toDto(farmerRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer not found: " + id)));
    }

    public FarmerResponseDTO getFarmerByUserId(Long userId) {
        return toDto(farmerRepo.findByUsers_Id(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer profile not found for userId: " + userId)));
    }

    public List<FarmerResponseDTO> getFarmersByStatus(String status) {
        FarmerStatus fs = FarmerStatus.valueOf(status.toUpperCase());
        return farmerRepo.findByStatus(fs).stream().map(this::toDto).toList();
    }

    @Transactional
    public FarmerResponseDTO updateFarmer(Long id, UserRequestDTO dto) {
        Farmer farmer = farmerRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer not found: " + id));
        if (dto.getName() != null)        farmer.setName(dto.getName());
        if (dto.getPhone() != null)       farmer.setContactInfo(dto.getPhone());
        if (dto.getAddress() != null)     farmer.setAddress(dto.getAddress());
        if (dto.getLandDetails() != null) farmer.setLandDetails(dto.getLandDetails());
        if (dto.getBankAccount() != null) farmer.setBankAccount(dto.getBankAccount());
        if (dto.getIfscCode() != null)    farmer.setIfscCode(dto.getIfscCode());
        if (dto.getDob() != null && !dto.getDob().isBlank()) {
            try { farmer.setDob(LocalDate.parse(dto.getDob())); } catch (Exception ignored) {}
        }
        if (dto.getGender() != null) {
            try { farmer.setGender(FarmerGender.valueOf(dto.getGender().toUpperCase())); } catch (Exception ignored) {}
        }
        return toDto(farmerRepo.save(farmer));
    }

    @Transactional
    public String updateFarmerStatus(Long id, String status) {
        Farmer farmer = farmerRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer not found: " + id));
        farmer.setStatus(FarmerStatus.valueOf(status.toUpperCase()));
        farmerRepo.save(farmer);
        return "Farmer status updated to " + status;
    }

    @Transactional
    public FarmerDocument addDocument(Long farmerId, String docType, String docUrl, String fileName) {
        Farmer farmer = farmerRepo.findById(farmerId)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer not found: " + farmerId));
        FarmerDocument doc = FarmerDocument.builder()
                .farmer(farmer)
                .docType(DocType.valueOf(docType.toUpperCase()))
                .docUrl(docUrl)
                .fileName(fileName)
                .verificationStatus(VerificationStatus.PENDING)
                .build();
        return docRepo.save(doc);
    }

    public List<FarmerDocument> getDocuments(Long farmerId) {
        return docRepo.findByFarmer_Id(farmerId);
    }

    @Transactional
    public String verifyDocument(Long docId, String status) {
        FarmerDocument doc = docRepo.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + docId));
        doc.setVerificationStatus(VerificationStatus.valueOf(status.toUpperCase()));
        docRepo.save(doc);
        return "Document verification status updated";
    }

    public long countFarmers() { return farmerRepo.count(); }

    private FarmerResponseDTO toDto(Farmer f) {
        return FarmerResponseDTO.builder()
                .id(f.getId())
                .userId(f.getUsers() != null ? f.getUsers().getId() : null)
                .name(f.getName()).email(f.getEmail()).contactInfo(f.getContactInfo())
                .dob(f.getDob() != null ? f.getDob().toString() : null)
                .gender(f.getGender()).address(f.getAddress()).landDetails(f.getLandDetails())
                .aadharNumber(f.getAadharNumber()).bankAccount(f.getBankAccount())
                .ifscCode(f.getIfscCode()).status(f.getStatus())
                .build();
    }
}
