package com.agrichain.registration.enums;
public enum FarmerStatus { ACTIVE, INACTIVE, SUSPENDED, PENDING_VERIFICATION }
