package com.agrichain.registration.dao;
import com.agrichain.registration.entity.Farmer;
import com.agrichain.registration.enums.FarmerStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface FarmerRepo extends JpaRepository<Farmer, Long> {
    Optional<Farmer> findByEmail(String email);
    List<Farmer> findByStatus(FarmerStatus status);
    Optional<Farmer> findByUsers_Id(Long userId);
}
