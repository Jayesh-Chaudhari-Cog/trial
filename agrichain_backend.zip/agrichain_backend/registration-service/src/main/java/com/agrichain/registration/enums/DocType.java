package com.agrichain.registration.enums;
public enum DocType { AADHAR, PAN, LAND_RECORD, BANK_PASSBOOK, PHOTO, OTHER }
