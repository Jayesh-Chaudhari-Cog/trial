package com.agrichain.registration.enums;
public enum FarmerGender { MALE, FEMALE, OTHER }
