package com.agrichain.registration.enums;
public enum UserStatus { ACTIVE, INACTIVE, SUSPENDED }
