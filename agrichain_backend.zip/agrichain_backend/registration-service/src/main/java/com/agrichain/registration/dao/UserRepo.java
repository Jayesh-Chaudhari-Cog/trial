package com.agrichain.registration.dao;
import com.agrichain.registration.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface UserRepo extends JpaRepository<Users, Long> {
    Optional<Users> findByEmail(String email);
    Optional<Users> findByPhone(String phone);
    boolean existsByEmail(String email);
}
