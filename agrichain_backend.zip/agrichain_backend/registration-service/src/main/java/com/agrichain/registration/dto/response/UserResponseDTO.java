package com.agrichain.registration.dto.response;

import com.agrichain.registration.enums.UserRole;
import com.agrichain.registration.enums.UserStatus;
import lombok.Builder;
import lombok.Data;

@Data @Builder
public class UserResponseDTO {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private UserRole role;
    private UserStatus status;
}
