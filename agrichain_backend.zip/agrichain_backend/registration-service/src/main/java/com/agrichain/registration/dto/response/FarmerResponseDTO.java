package com.agrichain.registration.dto.response;

import com.agrichain.registration.enums.FarmerGender;
import com.agrichain.registration.enums.FarmerStatus;
import lombok.Builder;
import lombok.Data;

@Data @Builder
public class FarmerResponseDTO {
    private Long id;
    private Long userId;
    private String name;
    private String email;
    private String contactInfo;
    private String dob;
    private FarmerGender gender;
    private String address;
    private String landDetails;
    private String aadharNumber;
    private String bankAccount;
    private String ifscCode;
    private FarmerStatus status;
}
