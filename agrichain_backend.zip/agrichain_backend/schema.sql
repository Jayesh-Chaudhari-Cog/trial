-- AgriChain Database Schema
-- MySQL 8.0+

CREATE DATABASE IF NOT EXISTS agrichain_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE agrichain_db;

-- ============================================================
-- USERS & AUTHENTICATION
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    user_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    email       VARCHAR(255) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    name        VARCHAR(100) NOT NULL,
    phone       VARCHAR(15),
    role        ENUM('FARMER','TRADER','MARKET_OFFICER','PROGRAM_MANAGER','ADMIN','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR') NOT NULL DEFAULT 'FARMER',
    status      ENUM('ACTIVE','INACTIVE','SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
);

-- ============================================================
-- FARMERS
-- ============================================================
CREATE TABLE IF NOT EXISTS farmers (
    farmer_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL UNIQUE,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(255) NOT NULL UNIQUE,
    contact_info    VARCHAR(15),
    dob             DATE,
    gender          ENUM('MALE','FEMALE','OTHER'),
    address         TEXT,
    land_details    TEXT,
    aadhar_number   VARCHAR(12) UNIQUE,
    bank_account    VARCHAR(20),
    ifsc_code       VARCHAR(11),
    status          ENUM('ACTIVE','INACTIVE','SUSPENDED','PENDING_VERIFICATION') NOT NULL DEFAULT 'ACTIVE',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_farmers_email (email),
    INDEX idx_farmers_status (status)
);

CREATE TABLE IF NOT EXISTS farmer_documents (
    doc_id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    farmer_id       BIGINT NOT NULL,
    doc_type        ENUM('AADHAR','PAN','LAND_RECORD','BANK_PASSBOOK','PHOTO','OTHER') NOT NULL,
    doc_url         VARCHAR(500),
    file_name       VARCHAR(255),
    verification_status ENUM('PENDING','VERIFIED','REJECTED') DEFAULT 'PENDING',
    uploaded_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE,
    INDEX idx_docs_farmer (farmer_id)
);

-- ============================================================
-- CROP LISTINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS crop_listings (
    listing_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    farmer_id       BIGINT NOT NULL,
    crop_name       VARCHAR(100) NOT NULL,
    variety         VARCHAR(100),
    quantity_kg     DECIMAL(10,2) NOT NULL,
    price_per_kg    DECIMAL(10,2) NOT NULL,
    harvest_date    DATE,
    available_from  DATE,
    available_until DATE,
    location        VARCHAR(255),
    description     TEXT,
    quality_grade   ENUM('A','B','C','ORGANIC') DEFAULT 'B',
    status          ENUM('PENDING','ACTIVE','SOLD','EXPIRED','CANCELLED') DEFAULT 'PENDING',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE,
    INDEX idx_listings_status (status),
    INDEX idx_listings_crop (crop_name),
    INDEX idx_listings_farmer (farmer_id)
);

-- ============================================================
-- ORDERS
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
    order_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    listing_id      BIGINT NOT NULL,
    buyer_user_id   BIGINT NOT NULL,
    farmer_id       BIGINT NOT NULL,
    quantity_kg     DECIMAL(10,2) NOT NULL,
    price_per_kg    DECIMAL(10,2) NOT NULL,
    total_amount    DECIMAL(12,2) NOT NULL,
    status          ENUM('PENDING','CONFIRMED','IN_TRANSIT','DELIVERED','CANCELLED','REJECTED') DEFAULT 'PENDING',
    delivery_address TEXT,
    notes           TEXT,
    ordered_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (listing_id) REFERENCES crop_listings(listing_id),
    FOREIGN KEY (buyer_user_id) REFERENCES users(user_id),
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id),
    INDEX idx_orders_status (status),
    INDEX idx_orders_buyer (buyer_user_id),
    INDEX idx_orders_farmer (farmer_id)
);

-- ============================================================
-- TRANSACTIONS & PAYMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id  BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id        BIGINT NOT NULL,
    sender_id       BIGINT NOT NULL,
    receiver_id     BIGINT NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    transaction_type ENUM('PAYMENT','REFUND','SUBSIDY_TRANSFER') DEFAULT 'PAYMENT',
    status          ENUM('PENDING','SUCCESS','FAILED','REVERSED') DEFAULT 'PENDING',
    reference_no    VARCHAR(100) UNIQUE,
    description     TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (sender_id) REFERENCES users(user_id),
    FOREIGN KEY (receiver_id) REFERENCES users(user_id),
    INDEX idx_txn_order (order_id),
    INDEX idx_txn_status (status)
);

CREATE TABLE IF NOT EXISTS payments (
    payment_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    transaction_id  BIGINT NOT NULL,
    payment_method  ENUM('UPI','BANK_TRANSFER','NEFT','RTGS','CASH') DEFAULT 'BANK_TRANSFER',
    payment_status  ENUM('INITIATED','PROCESSING','COMPLETED','FAILED','REFUNDED') DEFAULT 'INITIATED',
    gateway_ref     VARCHAR(255),
    paid_at         TIMESTAMP NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id),
    INDEX idx_payments_txn (transaction_id)
);

-- ============================================================
-- SUBSIDY PROGRAMS
-- ============================================================
CREATE TABLE IF NOT EXISTS subsidy_programs (
    program_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    budget_total    DECIMAL(15,2) NOT NULL,
    budget_used     DECIMAL(15,2) DEFAULT 0,
    subsidy_type    ENUM('SEED','FERTILIZER','EQUIPMENT','IRRIGATION','GENERAL','CROP_INSURANCE') DEFAULT 'GENERAL',
    eligibility_criteria TEXT,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    status          ENUM('DRAFT','ACTIVE','PAUSED','EXPIRED','CANCELLED') DEFAULT 'DRAFT',
    created_by      BIGINT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_subsidy_status (status)
);

CREATE TABLE IF NOT EXISTS subsidy_disbursements (
    disbursement_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    program_id      BIGINT NOT NULL,
    farmer_id       BIGINT NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    status          ENUM('APPLIED','UNDER_REVIEW','APPROVED','DISBURSED','REJECTED') DEFAULT 'APPLIED',
    application_date DATE NOT NULL,
    disbursement_date DATE,
    remarks         TEXT,
    reviewed_by     BIGINT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (program_id) REFERENCES subsidy_programs(program_id),
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id),
    FOREIGN KEY (reviewed_by) REFERENCES users(user_id),
    INDEX idx_disb_farmer (farmer_id),
    INDEX idx_disb_program (program_id),
    INDEX idx_disb_status (status)
);

-- ============================================================
-- AUDIT & COMPLIANCE
-- ============================================================
CREATE TABLE IF NOT EXISTS audits (
    audit_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    audit_scope     ENUM('FARMER','TRANSACTION','SUBSIDY','COMPLIANCE','SYSTEM') NOT NULL,
    target_id       BIGINT,
    status          ENUM('PLANNED','IN_PROGRESS','COMPLETED','CANCELLED') DEFAULT 'PLANNED',
    auditor_id      BIGINT,
    findings        TEXT,
    scheduled_date  DATE,
    completed_date  DATE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (auditor_id) REFERENCES users(user_id),
    INDEX idx_audits_status (status),
    INDEX idx_audits_scope (audit_scope)
);

CREATE TABLE IF NOT EXISTS compliance_records (
    compliance_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    farmer_id       BIGINT NOT NULL,
    compliance_type ENUM('KYC','LAND_VERIFICATION','QUALITY_CHECK','FINANCIAL','ENVIRONMENTAL') NOT NULL,
    result          ENUM('COMPLIANT','NON_COMPLIANT','PENDING','UNDER_REVIEW') DEFAULT 'PENDING',
    officer_id      BIGINT,
    notes           TEXT,
    valid_until     DATE,
    checked_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id),
    FOREIGN KEY (officer_id) REFERENCES users(user_id),
    INDEX idx_compliance_farmer (farmer_id),
    INDEX idx_compliance_type (compliance_type)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    log_id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT,
    action          VARCHAR(100) NOT NULL,
    entity_type     VARCHAR(50),
    entity_id       VARCHAR(50),
    old_value       TEXT,
    new_value       TEXT,
    ip_address      VARCHAR(45),
    user_agent      VARCHAR(500),
    status          ENUM('SUCCESS','FAILURE') DEFAULT 'SUCCESS',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_auditlog_user (user_id),
    INDEX idx_auditlog_entity (entity_type, entity_id),
    INDEX idx_auditlog_created (created_at)
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    title           VARCHAR(255) NOT NULL,
    message         TEXT NOT NULL,
    type            ENUM('INFO','SUCCESS','WARNING','ERROR','ALERT') DEFAULT 'INFO',
    category        ENUM('ORDER','PAYMENT','SUBSIDY','COMPLIANCE','SYSTEM','GENERAL') DEFAULT 'GENERAL',
    is_read         BOOLEAN DEFAULT FALSE,
    reference_id    BIGINT,
    reference_type  VARCHAR(50),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_notif_user (user_id),
    INDEX idx_notif_read (user_id, is_read)
);

-- ============================================================
-- REPORTS
-- ============================================================
CREATE TABLE IF NOT EXISTS reports (
    report_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(255) NOT NULL,
    report_type     ENUM('TRANSACTION_SUMMARY','FARMER_ACTIVITY','SUBSIDY_UTILIZATION','COMPLIANCE_STATUS','MARKET_TRENDS','CUSTOM') NOT NULL,
    generated_by    BIGINT,
    parameters      JSON,
    file_path       VARCHAR(500),
    status          ENUM('GENERATING','READY','FAILED') DEFAULT 'GENERATING',
    generated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (generated_by) REFERENCES users(user_id),
    INDEX idx_reports_type (report_type)
);

-- ============================================================
-- MARKET PRICES
-- ============================================================
CREATE TABLE IF NOT EXISTS market_prices (
    price_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    crop_name       VARCHAR(100) NOT NULL,
    market_name     VARCHAR(100),
    state           VARCHAR(50),
    price_per_kg    DECIMAL(10,2) NOT NULL,
    recorded_date   DATE NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_market_crop (crop_name),
    INDEX idx_market_date (recorded_date)
);

-- ============================================================
-- SEED DATA
-- ============================================================
-- Admin user (password: Admin@123)
INSERT INTO users (email, password, name, phone, role, status) VALUES
('admin@agrichain.in', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'System Admin', '9000000001', 'ADMIN', 'ACTIVE'),
('officer@agrichain.in', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Market Officer', '9000000002', 'MARKET_OFFICER', 'ACTIVE'),
('manager@agrichain.in', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Program Manager', '9000000003', 'PROGRAM_MANAGER', 'ACTIVE'),
('auditor@agrichain.in', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Govt Auditor', '9000000004', 'GOVERNMENT_AUDITOR', 'ACTIVE'),
('compliance@agrichain.in', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Compliance Officer', '9000000005', 'COMPLIANCE_OFFICER', 'ACTIVE'),
('farmer1@example.com', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Ramesh Kumar', '9111111111', 'FARMER', 'ACTIVE'),
('farmer2@example.com', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Suresh Patel', '9111111112', 'FARMER', 'ACTIVE'),
('trader1@example.com', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Mahesh Traders', '9222222221', 'TRADER', 'ACTIVE'),
('trader2@example.com', '$2a$12$rJcEBeBz0z5lKVCvEAb.9.Wr7OAQz1CMUTY6/s/l4dMHEnwQKq1ry', 'Agro Buyers Ltd', '9222222222', 'TRADER', 'ACTIVE');

-- Farmer profiles
INSERT INTO farmers (user_id, name, email, contact_info, dob, gender, address, land_details, aadhar_number, status) VALUES
(6, 'Ramesh Kumar', 'farmer1@example.com', '9111111111', '1980-04-15', 'MALE', 'Village Kothapeta, Andhra Pradesh - 521201', '5 acres - Rice, Wheat', '123456789012', 'ACTIVE'),
(7, 'Suresh Patel', 'farmer2@example.com', '9111111112', '1975-08-22', 'MALE', 'Anand, Gujarat - 388001', '8 acres - Cotton, Groundnut', '234567890123', 'ACTIVE');

-- Crop listings
INSERT INTO crop_listings (farmer_id, crop_name, variety, quantity_kg, price_per_kg, harvest_date, available_from, available_until, location, quality_grade, status) VALUES
(1, 'Wheat', 'Sharbati', 5000, 22.50, '2025-03-01', '2025-03-15', '2025-06-30', 'Anand, Gujarat', 'A', 'ACTIVE'),
(1, 'Rice', 'Basmati', 3000, 45.00, '2025-01-15', '2025-02-01', '2025-05-31', 'Kothapeta, AP', 'A', 'ACTIVE'),
(2, 'Cotton', 'BT Cotton', 2000, 55.00, '2025-02-20', '2025-03-01', '2025-07-31', 'Anand, Gujarat', 'B', 'ACTIVE'),
(2, 'Groundnut', 'Bold', 1500, 62.00, '2025-01-10', '2025-01-20', '2025-04-30', 'Anand, Gujarat', 'A', 'ACTIVE');

-- Subsidy programs
INSERT INTO subsidy_programs (name, description, budget_total, subsidy_type, start_date, end_date, status, created_by) VALUES
('PM-KISAN 2025', 'Direct income support to farmers - Rs 6000/year', 10000000.00, 'GENERAL', '2025-01-01', '2025-12-31', 'ACTIVE', 3),
('Organic Farming Incentive', 'Support for organic certification and transition', 5000000.00, 'FERTILIZER', '2025-02-01', '2025-11-30', 'ACTIVE', 3),
('Drip Irrigation Subsidy', '50% subsidy on drip irrigation installation', 8000000.00, 'IRRIGATION', '2025-01-15', '2025-10-31', 'ACTIVE', 3);

-- Market prices
INSERT INTO market_prices (crop_name, market_name, state, price_per_kg, recorded_date) VALUES
('Wheat', 'Anand APMC', 'Gujarat', 22.80, CURDATE()),
('Rice', 'Kakinada Market', 'Andhra Pradesh', 43.50, CURDATE()),
('Cotton', 'Rajkot Cotton Exchange', 'Gujarat', 56.20, CURDATE()),
('Tomato', 'Azadpur Mandi', 'Delhi', 18.00, CURDATE()),
('Onion', 'Lasalgaon Market', 'Maharashtra', 25.50, CURDATE()),
('Potato', 'Agra Market', 'UP', 12.00, CURDATE()),
('Maize', 'Davangere Market', 'Karnataka', 19.50, CURDATE()),
('Soybean', 'Indore Market', 'MP', 42.00, CURDATE());

