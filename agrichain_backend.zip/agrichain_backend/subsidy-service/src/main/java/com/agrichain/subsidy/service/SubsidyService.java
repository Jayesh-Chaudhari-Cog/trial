package com.agrichain.subsidy.service;

import com.agrichain.subsidy.dao.SubsidyDisbursementRepo;
import com.agrichain.subsidy.dao.SubsidyProgramRepo;
import com.agrichain.subsidy.entity.SubsidyDisbursement;
import com.agrichain.subsidy.entity.SubsidyProgram;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class SubsidyService {

    @Autowired private SubsidyProgramRepo programRepo;
    @Autowired private SubsidyDisbursementRepo disbursementRepo;

    // PROGRAMS
    @Transactional
    public SubsidyProgram createProgram(Map<String, String> body) {
        SubsidyProgram p = SubsidyProgram.builder()
                .name(body.get("name"))
                .description(body.get("description"))
                .budgetTotal(new BigDecimal(body.get("budgetTotal")))
                .budgetUsed(BigDecimal.ZERO)
                .subsidyType(SubsidyProgram.SubsidyType.valueOf(
                        body.getOrDefault("subsidyType", "GENERAL").toUpperCase()))
                .eligibilityCriteria(body.get("eligibilityCriteria"))
                .startDate(LocalDate.parse(body.get("startDate")))
                .endDate(LocalDate.parse(body.get("endDate")))
                .status(SubsidyProgram.ProgramStatus.ACTIVE)
                .createdBy(body.get("createdBy") != null ? Long.parseLong(body.get("createdBy")) : null)
                .build();
        return programRepo.save(p);
    }

    public List<SubsidyProgram> getAllPrograms() { return programRepo.findAll(); }

    public List<SubsidyProgram> getActivePrograms() {
        return programRepo.findByStatus(SubsidyProgram.ProgramStatus.ACTIVE);
    }

    public SubsidyProgram getProgramById(Long id) {
        return programRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Program not found: " + id));
    }

    @Transactional
    public SubsidyProgram updateProgramStatus(Long id, String status) {
        SubsidyProgram p = getProgramById(id);
        p.setStatus(SubsidyProgram.ProgramStatus.valueOf(status.toUpperCase()));
        return programRepo.save(p);
    }

    // DISBURSEMENTS
    @Transactional
    public SubsidyDisbursement applyForSubsidy(Long programId, Long farmerId, BigDecimal amount) {
        SubsidyProgram program = getProgramById(programId);
        if (program.getStatus() != SubsidyProgram.ProgramStatus.ACTIVE)
            throw new IllegalStateException("Program is not active");

        SubsidyDisbursement d = SubsidyDisbursement.builder()
                .programId(programId)
                .farmerId(farmerId)
                .amount(amount)
                .status(SubsidyDisbursement.DisbursementStatus.APPLIED)
                .applicationDate(LocalDate.now())
                .build();
        return disbursementRepo.save(d);
    }

    @Transactional
    public SubsidyDisbursement updateDisbursementStatus(Long id, String status, Long reviewedBy, String remarks) {
        SubsidyDisbursement d = disbursementRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Disbursement not found: " + id));
        SubsidyDisbursement.DisbursementStatus newStatus =
                SubsidyDisbursement.DisbursementStatus.valueOf(status.toUpperCase());
        d.setStatus(newStatus);
        d.setReviewedBy(reviewedBy);
        if (remarks != null) d.setRemarks(remarks);
        if (newStatus == SubsidyDisbursement.DisbursementStatus.DISBURSED) {
            d.setDisbursementDate(LocalDate.now());
            SubsidyProgram program = getProgramById(d.getProgramId());
            program.setBudgetUsed(program.getBudgetUsed().add(d.getAmount()));
            programRepo.save(program);
        }
        return disbursementRepo.save(d);
    }

    public List<SubsidyDisbursement> getAllDisbursements() { return disbursementRepo.findAll(); }
    public List<SubsidyDisbursement> getDisbursementsByFarmer(Long farmerId) {
        return disbursementRepo.findByFarmerId(farmerId);
    }
    public List<SubsidyDisbursement> getDisbursementsByProgram(Long programId) {
        return disbursementRepo.findByProgramId(programId);
    }
    public List<SubsidyDisbursement> getPendingDisbursements() {
        return disbursementRepo.findByStatus(SubsidyDisbursement.DisbursementStatus.APPLIED);
    }

    public Map<String, Object> getStats() {
        return Map.of(
            "totalPrograms", programRepo.count(),
            "activePrograms", programRepo.findByStatus(SubsidyProgram.ProgramStatus.ACTIVE).size(),
            "totalDisbursements", disbursementRepo.count(),
            "totalDisbursedAmount", disbursementRepo.sumDisbursed()
        );
    }
}
