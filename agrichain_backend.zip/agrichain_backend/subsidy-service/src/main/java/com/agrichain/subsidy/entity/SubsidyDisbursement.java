package com.agrichain.subsidy.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "subsidy_disbursements")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SubsidyDisbursement {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "disbursement_id") private Long id;

    @Column(name = "program_id", nullable = false) private Long programId;
    @Column(name = "farmer_id", nullable = false) private Long farmerId;

    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private DisbursementStatus status;

    @Column(name = "application_date", nullable = false) private LocalDate applicationDate;
    @Column(name = "disbursement_date") private LocalDate disbursementDate;

    @Column(columnDefinition = "TEXT") private String remarks;
    @Column(name = "reviewed_by") private Long reviewedBy;

    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;
    @UpdateTimestamp @Column(name = "updated_at") private LocalDateTime updatedAt;

    public enum DisbursementStatus { APPLIED, UNDER_REVIEW, APPROVED, DISBURSED, REJECTED }
}
