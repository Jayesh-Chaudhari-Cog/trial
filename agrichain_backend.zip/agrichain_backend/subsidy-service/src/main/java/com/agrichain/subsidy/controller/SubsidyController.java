package com.agrichain.subsidy.controller;

import com.agrichain.subsidy.entity.SubsidyDisbursement;
import com.agrichain.subsidy.entity.SubsidyProgram;
import com.agrichain.subsidy.service.SubsidyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SubsidyController {

    @Autowired private SubsidyService service;

    @PostMapping("/subsidies")
    public ResponseEntity<?> createProgram(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.createProgram(body)));
    }

    @GetMapping("/subsidies")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllPrograms()));
    }

    @GetMapping("/subsidies/active")
    public ResponseEntity<?> getActive() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getActivePrograms()));
    }

    @GetMapping("/subsidies/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getProgramById(id)));
    }

    @PatchMapping("/subsidies/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data",
                service.updateProgramStatus(id, body.get("status"))));
    }

    @GetMapping("/subsidies/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getStats()));
    }

    @PostMapping("/disbursements")
    public ResponseEntity<?> apply(@RequestBody Map<String, String> body) {
        SubsidyDisbursement d = service.applyForSubsidy(
                Long.parseLong(body.get("programId")),
                Long.parseLong(body.get("farmerId")),
                new BigDecimal(body.get("amount")));
        return ResponseEntity.ok(Map.of("success", true, "data", d));
    }

    @GetMapping("/disbursements")
    public ResponseEntity<?> getAllDisbursements() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllDisbursements()));
    }

    @GetMapping("/disbursements/farmer/{farmerId}")
    public ResponseEntity<?> getByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getDisbursementsByFarmer(farmerId)));
    }

    @GetMapping("/disbursements/program/{programId}")
    public ResponseEntity<?> getByProgram(@PathVariable Long programId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getDisbursementsByProgram(programId)));
    }

    @GetMapping("/disbursements/pending")
    public ResponseEntity<?> getPending() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getPendingDisbursements()));
    }

    @PatchMapping("/disbursements/{id}/status")
    public ResponseEntity<?> updateDisbursement(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Long reviewedBy = body.get("reviewedBy") != null ? Long.parseLong(body.get("reviewedBy")) : null;
        SubsidyDisbursement d = service.updateDisbursementStatus(id, body.get("status"),
                reviewedBy, body.get("remarks"));
        return ResponseEntity.ok(Map.of("success", true, "data", d));
    }
}
