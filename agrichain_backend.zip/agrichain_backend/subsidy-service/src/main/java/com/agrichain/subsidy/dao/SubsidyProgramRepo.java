package com.agrichain.subsidy.dao;

import com.agrichain.subsidy.entity.SubsidyProgram;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SubsidyProgramRepo extends JpaRepository<SubsidyProgram, Long> {
    List<SubsidyProgram> findByStatus(SubsidyProgram.ProgramStatus status);
    List<SubsidyProgram> findByCreatedBy(Long userId);
}
