package com.agrichain.subsidy.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "subsidy_programs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SubsidyProgram {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "program_id") private Long id;

    @Column(nullable = false) private String name;
    @Column(columnDefinition = "TEXT") private String description;

    @Column(name = "budget_total", nullable = false, precision = 15, scale = 2)
    private BigDecimal budgetTotal;

    @Column(name = "budget_used", precision = 15, scale = 2)
    private BigDecimal budgetUsed = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(name = "subsidy_type") private SubsidyType subsidyType;

    @Column(name = "eligibility_criteria", columnDefinition = "TEXT") private String eligibilityCriteria;

    @Column(name = "start_date", nullable = false) private LocalDate startDate;
    @Column(name = "end_date", nullable = false) private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private ProgramStatus status;

    @Column(name = "created_by") private Long createdBy;

    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;
    @UpdateTimestamp @Column(name = "updated_at") private LocalDateTime updatedAt;

    public enum SubsidyType { SEED, FERTILIZER, EQUIPMENT, IRRIGATION, GENERAL, CROP_INSURANCE }
    public enum ProgramStatus { DRAFT, ACTIVE, PAUSED, EXPIRED, CANCELLED }
}
