package com.agrichain.subsidy.dao;

import com.agrichain.subsidy.entity.SubsidyDisbursement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.math.BigDecimal;
import java.util.List;

public interface SubsidyDisbursementRepo extends JpaRepository<SubsidyDisbursement, Long> {
    List<SubsidyDisbursement> findByFarmerId(Long farmerId);
    List<SubsidyDisbursement> findByProgramId(Long programId);
    List<SubsidyDisbursement> findByStatus(SubsidyDisbursement.DisbursementStatus status);

    @Query("SELECT COALESCE(SUM(d.amount),0) FROM SubsidyDisbursement d WHERE d.status='DISBURSED'")
    BigDecimal sumDisbursed();
}
