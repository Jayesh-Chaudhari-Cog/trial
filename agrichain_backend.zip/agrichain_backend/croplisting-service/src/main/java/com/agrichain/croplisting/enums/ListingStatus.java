package com.agrichain.croplisting.enums;
public enum ListingStatus { PENDING, ACTIVE, SOLD, EXPIRED, CANCELLED }
