package com.agrichain.croplisting.enums;
public enum OrderStatus { PENDING, CONFIRMED, IN_TRANSIT, DELIVERED, CANCELLED, REJECTED }
