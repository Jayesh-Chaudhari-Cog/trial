package com.agrichain.croplisting.dao;

import com.agrichain.croplisting.entity.MarketPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MarketPriceRepo extends JpaRepository<MarketPrice, Long> {
    List<MarketPrice> findByCropNameIgnoreCase(String cropName);
    List<MarketPrice> findTop10ByOrderByRecordedDateDesc();
}
