package com.agrichain.croplisting.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class CropListingRequest {
    @NotNull private Long farmerId;
    @NotBlank private String cropName;
    private String variety;
    @NotNull @DecimalMin("0.01") private BigDecimal quantityKg;
    @NotNull @DecimalMin("0.01") private BigDecimal pricePerKg;
    private String harvestDate;
    private String availableFrom;
    private String availableUntil;
    private String location;
    private String description;
    private String qualityGrade;
}
