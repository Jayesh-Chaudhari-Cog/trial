package com.agrichain.croplisting.dao;

import com.agrichain.croplisting.entity.CropListing;
import com.agrichain.croplisting.enums.ListingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CropListingRepo extends JpaRepository<CropListing, Long> {
    List<CropListing> findByFarmerId(Long farmerId);
    List<CropListing> findByStatus(ListingStatus status);
    List<CropListing> findByCropNameContainingIgnoreCaseAndStatus(String cropName, ListingStatus status);

    @Query("SELECT DISTINCT c.cropName FROM CropListing c WHERE c.status = 'ACTIVE'")
    List<String> findDistinctActiveCropNames();

    long countByStatus(ListingStatus status);
}
