package com.agrichain.croplisting.enums;
public enum QualityGrade { A, B, C, ORGANIC }
