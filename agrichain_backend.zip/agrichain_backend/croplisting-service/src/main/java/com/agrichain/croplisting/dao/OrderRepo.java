package com.agrichain.croplisting.dao;

import com.agrichain.croplisting.entity.Order;
import com.agrichain.croplisting.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;

public interface OrderRepo extends JpaRepository<Order, Long> {
    List<Order> findByBuyerUserId(Long buyerUserId);
    List<Order> findByFarmerId(Long farmerId);
    List<Order> findByStatus(OrderStatus status);

    @Query("SELECT COALESCE(SUM(o.totalAmount),0) FROM Order o WHERE o.status = 'DELIVERED'")
    BigDecimal sumDeliveredAmount();

    long countByStatus(OrderStatus status);
}
