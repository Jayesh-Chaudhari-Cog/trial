package com.agrichain.croplisting.service;

import com.agrichain.croplisting.dao.CropListingRepo;
import com.agrichain.croplisting.dao.MarketPriceRepo;
import com.agrichain.croplisting.dao.OrderRepo;
import com.agrichain.croplisting.dto.request.CropListingRequest;
import com.agrichain.croplisting.dto.request.OrderRequest;
import com.agrichain.croplisting.entity.CropListing;
import com.agrichain.croplisting.entity.MarketPrice;
import com.agrichain.croplisting.entity.Order;
import com.agrichain.croplisting.enums.ListingStatus;
import com.agrichain.croplisting.enums.OrderStatus;
import com.agrichain.croplisting.enums.QualityGrade;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class CropListingService {

    @Autowired private CropListingRepo listingRepo;
    @Autowired private OrderRepo orderRepo;
    @Autowired private MarketPriceRepo marketPriceRepo;

    // ---- LISTINGS ----
    @Transactional
    public CropListing createListing(CropListingRequest req) {
        CropListing listing = CropListing.builder()
                .farmerId(req.getFarmerId())
                .cropName(req.getCropName())
                .variety(req.getVariety())
                .quantityKg(req.getQuantityKg())
                .pricePerKg(req.getPricePerKg())
                .location(req.getLocation())
                .description(req.getDescription())
                .status(ListingStatus.ACTIVE)
                .qualityGrade(req.getQualityGrade() != null
                        ? QualityGrade.valueOf(req.getQualityGrade().toUpperCase()) : QualityGrade.B)
                .build();

        if (req.getHarvestDate() != null)    listing.setHarvestDate(LocalDate.parse(req.getHarvestDate()));
        if (req.getAvailableFrom() != null)  listing.setAvailableFrom(LocalDate.parse(req.getAvailableFrom()));
        if (req.getAvailableUntil() != null) listing.setAvailableUntil(LocalDate.parse(req.getAvailableUntil()));
        return listingRepo.save(listing);
    }

    public List<CropListing> getAllListings() {
        return listingRepo.findAll();
    }

    public List<CropListing> getActiveListings() {
        return listingRepo.findByStatus(ListingStatus.ACTIVE);
    }

    public List<CropListing> getListingsByFarmer(Long farmerId) {
        return listingRepo.findByFarmerId(farmerId);
    }

    public List<CropListing> searchByCrop(String cropName) {
        return listingRepo.findByCropNameContainingIgnoreCaseAndStatus(cropName, ListingStatus.ACTIVE);
    }

    public CropListing getListingById(Long id) {
        return listingRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Listing not found: " + id));
    }

    @Transactional
    public CropListing updateListing(Long id, CropListingRequest req) {
        CropListing listing = getListingById(id);
        if (req.getCropName() != null)   listing.setCropName(req.getCropName());
        if (req.getVariety() != null)    listing.setVariety(req.getVariety());
        if (req.getQuantityKg() != null) listing.setQuantityKg(req.getQuantityKg());
        if (req.getPricePerKg() != null) listing.setPricePerKg(req.getPricePerKg());
        if (req.getLocation() != null)   listing.setLocation(req.getLocation());
        if (req.getDescription() != null) listing.setDescription(req.getDescription());
        return listingRepo.save(listing);
    }

    @Transactional
    public String updateListingStatus(Long id, String status) {
        CropListing listing = getListingById(id);
        listing.setStatus(ListingStatus.valueOf(status.toUpperCase()));
        listingRepo.save(listing);
        return "Listing status updated";
    }

    // ---- ORDERS ----
    @Transactional
    public Order createOrder(OrderRequest req) {
        CropListing listing = getListingById(req.getListingId());
        if (listing.getStatus() != ListingStatus.ACTIVE)
            throw new IllegalStateException("Listing is not available for orders");

        BigDecimal totalAmount = listing.getPricePerKg().multiply(req.getQuantityKg());

        Order order = Order.builder()
                .listingId(req.getListingId())
                .buyerUserId(req.getBuyerUserId())
                .farmerId(listing.getFarmerId())
                .quantityKg(req.getQuantityKg())
                .pricePerKg(listing.getPricePerKg())
                .totalAmount(totalAmount)
                .status(OrderStatus.PENDING)
                .deliveryAddress(req.getDeliveryAddress())
                .notes(req.getNotes())
                .build();

        // Reduce listing quantity
        listing.setQuantityKg(listing.getQuantityKg().subtract(req.getQuantityKg()));
        if (listing.getQuantityKg().compareTo(BigDecimal.ZERO) <= 0)
            listing.setStatus(ListingStatus.SOLD);
        listingRepo.save(listing);

        return orderRepo.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    public List<Order> getOrdersByBuyer(Long buyerUserId) {
        return orderRepo.findByBuyerUserId(buyerUserId);
    }

    public List<Order> getOrdersByFarmer(Long farmerId) {
        return orderRepo.findByFarmerId(farmerId);
    }

    public Order getOrderById(Long id) {
        return orderRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Order not found: " + id));
    }

    @Transactional
    public Order updateOrderStatus(Long id, String status) {
        Order order = getOrderById(id);
        order.setStatus(OrderStatus.valueOf(status.toUpperCase()));
        return orderRepo.save(order);
    }

    // ---- MARKET PRICES ----
    public List<MarketPrice> getLatestPrices() {
        return marketPriceRepo.findTop10ByOrderByRecordedDateDesc();
    }

    public List<MarketPrice> getPricesByCrop(String cropName) {
        return marketPriceRepo.findByCropNameIgnoreCase(cropName);
    }

    @Transactional
    public MarketPrice addMarketPrice(String cropName, String market, String state, BigDecimal price) {
        MarketPrice mp = MarketPrice.builder()
                .cropName(cropName).marketName(market).state(state)
                .pricePerKg(price).recordedDate(LocalDate.now()).build();
        return marketPriceRepo.save(mp);
    }

    // ---- DASHBOARD STATS ----
    public Map<String, Object> getDashboardStats() {
        return Map.of(
                "totalListings", listingRepo.count(),
                "activeListings", listingRepo.countByStatus(ListingStatus.ACTIVE),
                "totalOrders", orderRepo.count(),
                "pendingOrders", orderRepo.countByStatus(OrderStatus.PENDING),
                "totalRevenue", orderRepo.sumDeliveredAmount()
        );
    }
}
