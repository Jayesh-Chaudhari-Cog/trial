package com.agrichain.croplisting.controller;

import com.agrichain.croplisting.dto.request.CropListingRequest;
import com.agrichain.croplisting.dto.request.OrderRequest;
import com.agrichain.croplisting.dto.response.ApiResponse;
import com.agrichain.croplisting.entity.CropListing;
import com.agrichain.croplisting.entity.MarketPrice;
import com.agrichain.croplisting.entity.Order;
import com.agrichain.croplisting.service.CropListingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
public class CropListingController {

    @Autowired private CropListingService service;

    // ---- LISTINGS ----
    @PostMapping("/api/listings")
    public ResponseEntity<ApiResponse<CropListing>> create(@Valid @RequestBody CropListingRequest req) {
        return ResponseEntity.ok(ApiResponse.success("Listing created", service.createListing(req)));
    }

    @GetMapping("/api/listings")
    public ResponseEntity<ApiResponse<List<CropListing>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("All listings", service.getAllListings()));
    }

    @GetMapping("/api/listings/active")
    public ResponseEntity<ApiResponse<List<CropListing>>> getActive() {
        return ResponseEntity.ok(ApiResponse.success("Active listings", service.getActiveListings()));
    }

    @GetMapping("/api/listings/farmer/{farmerId}")
    public ResponseEntity<ApiResponse<List<CropListing>>> getByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(ApiResponse.success("Farmer listings", service.getListingsByFarmer(farmerId)));
    }

    @GetMapping("/api/listings/search")
    public ResponseEntity<ApiResponse<List<CropListing>>> search(@RequestParam String crop) {
        return ResponseEntity.ok(ApiResponse.success("Search results", service.searchByCrop(crop)));
    }

    @GetMapping("/api/listings/{id}")
    public ResponseEntity<ApiResponse<CropListing>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Listing found", service.getListingById(id)));
    }

    @PutMapping("/api/listings/{id}")
    public ResponseEntity<ApiResponse<CropListing>> update(@PathVariable Long id,
                                                            @RequestBody CropListingRequest req) {
        return ResponseEntity.ok(ApiResponse.success("Listing updated", service.updateListing(id, req)));
    }

    @PatchMapping("/api/listings/{id}/status")
    public ResponseEntity<ApiResponse<String>> updateStatus(@PathVariable Long id,
                                                             @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(ApiResponse.success("Status updated",
                service.updateListingStatus(id, body.get("status"))));
    }

    // ---- ORDERS ----
    @PostMapping("/api/orders")
    public ResponseEntity<ApiResponse<Order>> placeOrder(@Valid @RequestBody OrderRequest req) {
        return ResponseEntity.ok(ApiResponse.success("Order placed", service.createOrder(req)));
    }

    @GetMapping("/api/orders")
    public ResponseEntity<ApiResponse<List<Order>>> getAllOrders() {
        return ResponseEntity.ok(ApiResponse.success("All orders", service.getAllOrders()));
    }

    @GetMapping("/api/orders/buyer/{buyerUserId}")
    public ResponseEntity<ApiResponse<List<Order>>> getByBuyer(@PathVariable Long buyerUserId) {
        return ResponseEntity.ok(ApiResponse.success("Buyer orders", service.getOrdersByBuyer(buyerUserId)));
    }

    @GetMapping("/api/orders/farmer/{farmerId}")
    public ResponseEntity<ApiResponse<List<Order>>> getByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(ApiResponse.success("Farmer orders", service.getOrdersByFarmer(farmerId)));
    }

    @GetMapping("/api/orders/{id}")
    public ResponseEntity<ApiResponse<Order>> getOrder(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Order found", service.getOrderById(id)));
    }

    @PatchMapping("/api/orders/{id}/status")
    public ResponseEntity<ApiResponse<Order>> updateOrderStatus(@PathVariable Long id,
                                                                  @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(ApiResponse.success("Order status updated",
                service.updateOrderStatus(id, body.get("status"))));
    }

    // ---- MARKET ----
    @GetMapping("/api/market/prices")
    public ResponseEntity<ApiResponse<List<MarketPrice>>> getLatestPrices() {
        return ResponseEntity.ok(ApiResponse.success("Market prices", service.getLatestPrices()));
    }

    @GetMapping("/api/market/prices/{cropName}")
    public ResponseEntity<ApiResponse<List<MarketPrice>>> getPricesByCrop(@PathVariable String cropName) {
        return ResponseEntity.ok(ApiResponse.success("Prices for " + cropName, service.getPricesByCrop(cropName)));
    }

    @PostMapping("/api/market/prices")
    public ResponseEntity<ApiResponse<MarketPrice>> addPrice(@RequestBody Map<String, String> body) {
        MarketPrice mp = service.addMarketPrice(body.get("cropName"), body.get("marketName"),
                body.get("state"), new BigDecimal(body.get("pricePerKg")));
        return ResponseEntity.ok(ApiResponse.success("Price added", mp));
    }

    // ---- STATS ----
    @GetMapping("/api/listings/stats")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getStats() {
        return ResponseEntity.ok(ApiResponse.success("Stats", service.getDashboardStats()));
    }
}
