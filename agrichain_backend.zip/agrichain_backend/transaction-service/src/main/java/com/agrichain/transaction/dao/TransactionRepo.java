package com.agrichain.transaction.dao;

import com.agrichain.transaction.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.math.BigDecimal;
import java.util.List;

public interface TransactionRepo extends JpaRepository<Transaction, Long> {
    List<Transaction> findByOrderId(Long orderId);
    List<Transaction> findBySenderId(Long senderId);
    List<Transaction> findByReceiverId(Long receiverId);
    List<Transaction> findByStatus(Transaction.TxnStatus status);

    @Query("SELECT COALESCE(SUM(t.amount),0) FROM Transaction t WHERE t.status='SUCCESS'")
    BigDecimal sumSuccessfulAmount();

    long countByStatus(Transaction.TxnStatus status);
}
