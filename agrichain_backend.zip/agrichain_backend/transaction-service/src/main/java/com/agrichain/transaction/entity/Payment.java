package com.agrichain.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "payments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Payment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id") private Long id;

    @Column(name = "transaction_id", nullable = false) private Long transactionId;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method") private PaymentMethod paymentMethod;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_status") private PaymentStatus paymentStatus;

    @Column(name = "gateway_ref") private String gatewayRef;
    @Column(name = "paid_at") private LocalDateTime paidAt;
    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;

    public enum PaymentMethod { UPI, BANK_TRANSFER, NEFT, RTGS, CASH }
    public enum PaymentStatus { INITIATED, PROCESSING, COMPLETED, FAILED, REFUNDED }
}
