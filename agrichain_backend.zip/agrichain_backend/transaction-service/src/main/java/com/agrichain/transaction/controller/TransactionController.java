package com.agrichain.transaction.controller;

import com.agrichain.transaction.entity.Payment;
import com.agrichain.transaction.entity.Transaction;
import com.agrichain.transaction.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class TransactionController {

    @Autowired private TransactionService service;

    @PostMapping("/transactions/initiate")
    public ResponseEntity<?> initiate(@RequestBody Map<String, String> body) {
        Transaction txn = service.initiateTransaction(
                Long.parseLong(body.get("orderId")),
                Long.parseLong(body.get("senderId")),
                Long.parseLong(body.get("receiverId")),
                new BigDecimal(body.get("amount")),
                body.getOrDefault("description", "Payment for order")
        );
        return ResponseEntity.ok(Map.of("success", true, "data", txn));
    }

    @GetMapping("/transactions")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllTransactions()));
    }

    @GetMapping("/transactions/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getTransactionById(id)));
    }

    @GetMapping("/transactions/order/{orderId}")
    public ResponseEntity<?> getByOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getTransactionsByOrder(orderId)));
    }

    @GetMapping("/transactions/sender/{senderId}")
    public ResponseEntity<?> getBySender(@PathVariable Long senderId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getTransactionsBySender(senderId)));
    }

    @GetMapping("/transactions/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getStats()));
    }

    @PostMapping("/payments/initiate")
    public ResponseEntity<?> initiatePayment(@RequestBody Map<String, String> body) {
        Payment payment = service.initiatePayment(
                Long.parseLong(body.get("transactionId")),
                body.getOrDefault("method", "BANK_TRANSFER")
        );
        return ResponseEntity.ok(Map.of("success", true, "data", payment));
    }

    @PatchMapping("/payments/{id}/complete")
    public ResponseEntity<?> completePayment(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.completePayment(id)));
    }

    @PatchMapping("/payments/{id}/fail")
    public ResponseEntity<?> failPayment(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data",
                service.failPayment(id, body.getOrDefault("reason", "Unknown"))));
    }

    @GetMapping("/payments")
    public ResponseEntity<?> getAllPayments() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllPayments()));
    }

    @GetMapping("/payments/transaction/{txnId}")
    public ResponseEntity<?> getByTransaction(@PathVariable Long txnId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getPaymentsForTransaction(txnId)));
    }
}
