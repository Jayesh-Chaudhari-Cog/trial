package com.agrichain.transaction.dao;

import com.agrichain.transaction.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface PaymentRepo extends JpaRepository<Payment, Long> {
    List<Payment> findByTransactionId(Long transactionId);
    Optional<Payment> findByGatewayRef(String gatewayRef);
}
