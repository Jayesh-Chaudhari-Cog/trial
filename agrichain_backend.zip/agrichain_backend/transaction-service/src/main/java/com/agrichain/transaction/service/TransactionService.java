package com.agrichain.transaction.service;

import com.agrichain.transaction.dao.PaymentRepo;
import com.agrichain.transaction.dao.TransactionRepo;
import com.agrichain.transaction.entity.Payment;
import com.agrichain.transaction.entity.Transaction;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class TransactionService {

    @Autowired private TransactionRepo txnRepo;
    @Autowired private PaymentRepo paymentRepo;

    @Transactional
    public Transaction initiateTransaction(Long orderId, Long senderId, Long receiverId,
                                           BigDecimal amount, String description) {
        Transaction txn = Transaction.builder()
                .orderId(orderId).senderId(senderId).receiverId(receiverId)
                .amount(amount)
                .transactionType(Transaction.TxnType.PAYMENT)
                .status(Transaction.TxnStatus.PENDING)
                .referenceNo("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .description(description)
                .build();
        return txnRepo.save(txn);
    }

    @Transactional
    public Payment initiatePayment(Long transactionId, String method) {
        Payment payment = Payment.builder()
                .transactionId(transactionId)
                .paymentMethod(Payment.PaymentMethod.valueOf(method.toUpperCase()))
                .paymentStatus(Payment.PaymentStatus.INITIATED)
                .gatewayRef("PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .build();
        return paymentRepo.save(payment);
    }

    @Transactional
    public Payment completePayment(Long paymentId) {
        Payment payment = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new EntityNotFoundException("Payment not found: " + paymentId));
        payment.setPaymentStatus(Payment.PaymentStatus.COMPLETED);
        payment.setPaidAt(LocalDateTime.now());

        Transaction txn = txnRepo.findById(payment.getTransactionId())
                .orElseThrow(() -> new EntityNotFoundException("Transaction not found"));
        txn.setStatus(Transaction.TxnStatus.SUCCESS);
        txnRepo.save(txn);

        return paymentRepo.save(payment);
    }

    @Transactional
    public Payment failPayment(Long paymentId, String reason) {
        Payment payment = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new EntityNotFoundException("Payment not found: " + paymentId));
        payment.setPaymentStatus(Payment.PaymentStatus.FAILED);
        Transaction txn = txnRepo.findById(payment.getTransactionId())
                .orElseThrow(() -> new EntityNotFoundException("Transaction not found"));
        txn.setStatus(Transaction.TxnStatus.FAILED);
        txn.setDescription(txn.getDescription() + " | Failure: " + reason);
        txnRepo.save(txn);
        return paymentRepo.save(payment);
    }

    public List<Transaction> getAllTransactions() { return txnRepo.findAll(); }
    public Transaction getTransactionById(Long id) {
        return txnRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Transaction not found: " + id));
    }
    public List<Transaction> getTransactionsByOrder(Long orderId) { return txnRepo.findByOrderId(orderId); }
    public List<Transaction> getTransactionsBySender(Long senderId) { return txnRepo.findBySenderId(senderId); }
    public List<Transaction> getTransactionsByReceiver(Long receiverId) { return txnRepo.findByReceiverId(receiverId); }
    public List<Payment> getPaymentsForTransaction(Long txnId) { return paymentRepo.findByTransactionId(txnId); }
    public List<Payment> getAllPayments() { return paymentRepo.findAll(); }

    public Map<String, Object> getStats() {
        return Map.of(
            "totalTransactions", txnRepo.count(),
            "successfulTransactions", txnRepo.countByStatus(Transaction.TxnStatus.SUCCESS),
            "pendingTransactions", txnRepo.countByStatus(Transaction.TxnStatus.PENDING),
            "totalAmount", txnRepo.sumSuccessfulAmount()
        );
    }
}
