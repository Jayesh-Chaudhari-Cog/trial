package com.agrichain.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity @Table(name = "transactions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Transaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transaction_id") private Long id;

    @Column(name = "order_id", nullable = false) private Long orderId;
    @Column(name = "sender_id", nullable = false) private Long senderId;
    @Column(name = "receiver_id", nullable = false) private Long receiverId;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal amount;

    @Column(name = "transaction_type")
    @Enumerated(EnumType.STRING) private TxnType transactionType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private TxnStatus status;

    @Column(name = "reference_no", unique = true) private String referenceNo;
    @Column(columnDefinition = "TEXT") private String description;

    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;
    @UpdateTimestamp @Column(name = "updated_at") private LocalDateTime updatedAt;

    public enum TxnType { PAYMENT, REFUND, SUBSIDY_TRANSFER }
    public enum TxnStatus { PENDING, SUCCESS, FAILED, REVERSED }
}
