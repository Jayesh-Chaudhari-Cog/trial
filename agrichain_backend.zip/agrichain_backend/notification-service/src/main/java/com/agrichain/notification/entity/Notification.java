package com.agrichain.notification.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notification_id") private Long id;

    @Column(name = "user_id", nullable = false) private Long userId;
    @Column(nullable = false) private String title;
    @Column(nullable = false, columnDefinition = "TEXT") private String message;

    @Enumerated(EnumType.STRING) private NotifType type;
    @Enumerated(EnumType.STRING) private NotifCategory category;

    @Column(name = "is_read") private Boolean isRead = false;
    @Column(name = "reference_id") private Long referenceId;
    @Column(name = "reference_type", length = 50) private String referenceType;

    @CreationTimestamp @Column(name = "created_at", updatable = false) private LocalDateTime createdAt;

    public enum NotifType   { INFO, SUCCESS, WARNING, ERROR, ALERT }
    public enum NotifCategory { ORDER, PAYMENT, SUBSIDY, COMPLIANCE, SYSTEM, GENERAL }
}
