package com.agrichain.notification.controller;

import com.agrichain.notification.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired private NotificationService service;

    @PostMapping("/send")
    public ResponseEntity<?> send(@RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.sendFromMap(body)));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getForUser(@PathVariable Long userId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getForUser(userId)));
    }

    @GetMapping("/user/{userId}/unread")
    public ResponseEntity<?> getUnread(@PathVariable Long userId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getUnreadForUser(userId)));
    }

    @GetMapping("/user/{userId}/unread-count")
    public ResponseEntity<?> getUnreadCount(@PathVariable Long userId) {
        return ResponseEntity.ok(Map.of("success", true, "count", service.getUnreadCount(userId)));
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<?> markRead(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.markRead(id)));
    }

    @PatchMapping("/user/{userId}/mark-all-read")
    public ResponseEntity<?> markAllRead(@PathVariable Long userId) {
        int count = service.markAllRead(userId);
        return ResponseEntity.ok(Map.of("success", true, "updated", count));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Notification deleted"));
    }

    // Event hooks called by other microservices
    @PostMapping("/event/order-placed")
    public ResponseEntity<?> onOrderPlaced(@RequestBody Map<String, String> body) {
        service.notifyOrderPlaced(
                Long.parseLong(body.get("farmerId")),
                Long.parseLong(body.get("buyerUserId")),
                Long.parseLong(body.get("orderId")),
                body.get("cropName"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    @PostMapping("/event/payment-success")
    public ResponseEntity<?> onPaymentSuccess(@RequestBody Map<String, String> body) {
        service.notifyPaymentSuccess(
                Long.parseLong(body.get("userId")),
                Long.parseLong(body.get("orderId")),
                body.get("amount"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    @PostMapping("/event/subsidy-approved")
    public ResponseEntity<?> onSubsidyApproved(@RequestBody Map<String, String> body) {
        service.notifySubsidyApproved(
                Long.parseLong(body.get("farmerId")),
                Long.parseLong(body.get("disbursementId")),
                body.get("amount"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    @PostMapping("/event/compliance-action")
    public ResponseEntity<?> onComplianceAction(@RequestBody Map<String, String> body) {
        service.notifyComplianceAction(
                Long.parseLong(body.get("farmerId")),
                body.get("complianceType"),
                body.get("result"));
        return ResponseEntity.ok(Map.of("success", true));
    }
}
