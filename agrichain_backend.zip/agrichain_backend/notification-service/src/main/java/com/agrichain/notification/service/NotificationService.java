package com.agrichain.notification.service;

import com.agrichain.notification.dao.NotificationRepo;
import com.agrichain.notification.entity.Notification;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class NotificationService {

    @Autowired private NotificationRepo repo;

    @Transactional
    public Notification send(Long userId, String title, String message,
                              String type, String category, Long referenceId, String referenceType) {
        Notification n = Notification.builder()
                .userId(userId).title(title).message(message)
                .type(safeType(type))
                .category(safeCategory(category))
                .isRead(false)
                .referenceId(referenceId)
                .referenceType(referenceType)
                .build();
        return repo.save(n);
    }

    @Transactional
    public Notification sendFromMap(Map<String, Object> body) {
        Long userId    = Long.parseLong(body.get("userId").toString());
        String title   = body.get("title").toString();
        String message = body.get("message").toString();
        String type    = body.getOrDefault("type", "INFO").toString();
        String cat     = body.getOrDefault("category", "GENERAL").toString();
        Long refId     = body.get("referenceId") != null ? Long.parseLong(body.get("referenceId").toString()) : null;
        String refType = body.get("referenceType") != null ? body.get("referenceType").toString() : null;
        return send(userId, title, message, type, cat, refId, refType);
    }

    public List<Notification> getForUser(Long userId) {
        return repo.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public List<Notification> getUnreadForUser(Long userId) {
        return repo.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId);
    }

    public long getUnreadCount(Long userId) {
        return repo.countByUserIdAndIsReadFalse(userId);
    }

    @Transactional
    public Notification markRead(Long id) {
        Notification n = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Notification not found: " + id));
        n.setIsRead(true);
        return repo.save(n);
    }

    @Transactional
    public int markAllRead(Long userId) {
        return repo.markAllReadForUser(userId);
    }

    @Transactional
    public void delete(Long id) {
        repo.deleteById(id);
    }

    // ---- Event-based helpers called by other services via HTTP ----
    public void notifyOrderPlaced(Long farmerId, Long buyerUserId, Long orderId, String cropName) {
        send(farmerId, "New Order Received",
                "You have a new order for " + cropName + ". Order #" + orderId,
                "INFO", "ORDER", orderId, "ORDER");
        send(buyerUserId, "Order Placed Successfully",
                "Your order #" + orderId + " for " + cropName + " has been placed.",
                "SUCCESS", "ORDER", orderId, "ORDER");
    }

    public void notifyPaymentSuccess(Long userId, Long orderId, String amount) {
        send(userId, "Payment Successful",
                "Payment of ₹" + amount + " for Order #" + orderId + " was successful.",
                "SUCCESS", "PAYMENT", orderId, "ORDER");
    }

    public void notifySubsidyApproved(Long farmerId, Long disbursementId, String amount) {
        send(farmerId, "Subsidy Approved",
                "Your subsidy application of ₹" + amount + " has been approved. Disbursement #" + disbursementId,
                "SUCCESS", "SUBSIDY", disbursementId, "DISBURSEMENT");
    }

    public void notifyComplianceAction(Long farmerId, String complianceType, String result) {
        send(farmerId, "Compliance Update",
                "Your " + complianceType + " compliance check result: " + result,
                result.equals("COMPLIANT") ? "SUCCESS" : "WARNING",
                "COMPLIANCE", null, null);
    }

    private Notification.NotifType safeType(String type) {
        try { return Notification.NotifType.valueOf(type.toUpperCase()); }
        catch (Exception e) { return Notification.NotifType.INFO; }
    }

    private Notification.NotifCategory safeCategory(String cat) {
        try { return Notification.NotifCategory.valueOf(cat.toUpperCase()); }
        catch (Exception e) { return Notification.NotifCategory.GENERAL; }
    }
}
