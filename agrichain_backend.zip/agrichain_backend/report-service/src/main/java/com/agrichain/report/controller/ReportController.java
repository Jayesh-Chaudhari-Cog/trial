package com.agrichain.report.controller;

import com.agrichain.report.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired private ReportService service;

    @PostMapping
    public ResponseEntity<?> generate(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.generateReport(body)));
    }

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getAllReports()));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getReportsByUser(userId)));
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<?> getByType(@PathVariable String type) {
        return ResponseEntity.ok(Map.of("success", true, "data", service.getReportsByType(type)));
    }
}
