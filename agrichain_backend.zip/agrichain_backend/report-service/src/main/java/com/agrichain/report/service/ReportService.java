package com.agrichain.report.service;

import com.agrichain.report.dao.ReportRepo;
import com.agrichain.report.entity.Report;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class ReportService {

    @Autowired private ReportRepo reportRepo;

    @Transactional
    public Report generateReport(Map<String, String> body) {
        Report report = Report.builder()
                .title(body.getOrDefault("title", "Report"))
                .reportType(Report.ReportType.valueOf(
                        body.getOrDefault("reportType", "CUSTOM").toUpperCase()))
                .generatedBy(body.get("generatedBy") != null
                        ? Long.parseLong(body.get("generatedBy")) : null)
                .status(Report.ReportStatus.READY)
                .build();
        return reportRepo.save(report);
    }

    public List<Report> getAllReports() {
        return reportRepo.findAllByOrderByGeneratedAtDesc();
    }

    public List<Report> getReportsByUser(Long userId) {
        return reportRepo.findByGeneratedBy(userId);
    }

    public List<Report> getReportsByType(String type) {
        return reportRepo.findByReportType(Report.ReportType.valueOf(type.toUpperCase()));
    }
}
