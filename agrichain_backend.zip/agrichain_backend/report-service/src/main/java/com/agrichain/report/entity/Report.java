package com.agrichain.report.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "report_id") private Long id;

    @Column(nullable = false) private String title;

    @Enumerated(EnumType.STRING)
    @Column(name = "report_type", nullable = false) private ReportType reportType;

    @Column(name = "generated_by") private Long generatedBy;
    @Column(name = "file_path") private String filePath;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private ReportStatus status;

    @CreationTimestamp @Column(name = "generated_at", updatable = false) private LocalDateTime generatedAt;

    public enum ReportType {
        TRANSACTION_SUMMARY, FARMER_ACTIVITY, SUBSIDY_UTILIZATION,
        COMPLIANCE_STATUS, MARKET_TRENDS, CUSTOM
    }
    public enum ReportStatus { GENERATING, READY, FAILED }
}
