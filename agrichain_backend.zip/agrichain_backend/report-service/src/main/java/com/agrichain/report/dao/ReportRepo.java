package com.agrichain.report.dao;

import com.agrichain.report.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReportRepo extends JpaRepository<Report, Long> {
    List<Report> findByGeneratedBy(Long userId);
    List<Report> findByReportType(Report.ReportType type);
    List<Report> findAllByOrderByGeneratedAtDesc();
}
