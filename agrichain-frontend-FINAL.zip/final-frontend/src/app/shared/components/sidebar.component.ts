import { Component, computed } from '@angular/core';
import { RouterLink, RouterLinkActive, CommonModule } from '@angular/router';
import { AuthService } from '../../core/auth.service';

const NAV = [
  { label: 'Dashboard',  icon: '⊞',   route: '/dashboard' },
  { label: 'Users',      icon: '👤',  route: '/users',      roles: ['ADMIN','MANAGER','OFFICER','AUDITOR'] },
  { label: 'Farmers',    icon: '🧑‍🌾',  route: '/farmers' },
  { label: 'Market',     icon: '🌽',  route: '/market' },
  { label: 'Subsidy',    icon: '💰',  route: '/subsidy',    roles: ['ADMIN','MANAGER','OFFICER','FARMER'] },
  { label: 'Audit',      icon: '📋',  route: '/audit',      roles: ['ADMIN','MANAGER','AUDITOR','COMPLIANCE','OFFICER'] },
  { label: 'Reports',    icon: '📊',  route: '/reports',    roles: ['ADMIN','MANAGER','AUDITOR','OFFICER'] },
  { label: 'Audit Logs', icon: '🗒️',  route: '/audit-logs', roles: ['ADMIN','MANAGER','AUDITOR'] },
];

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, CommonModule],
  styles: [`
    aside { width:260px; height:100vh; background:#0f2e1a; display:flex; flex-direction:column; position:fixed; left:0; top:0; z-index:100; }
    .brand { display:flex; align-items:center; gap:.875rem; padding:1.5rem 1.25rem; border-bottom:1px solid rgba(255,255,255,.08); }
    .brand-icon { width:40px; height:40px; background:#f59e0b; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:1.25rem; flex-shrink:0; }
    .brand-name { font-size:1rem; font-weight:700; color:#fff; display:block; }
    .brand-sub  { font-size:.65rem; color:rgba(255,255,255,.35); text-transform:uppercase; letter-spacing:.08em; }
    nav { flex:1; padding:1.25rem .75rem; display:flex; flex-direction:column; gap:.125rem; overflow-y:auto; }
    .section-label { font-size:.65rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:rgba(255,255,255,.3); padding:0 .625rem; margin-bottom:.5rem; }
    a.nav-item { display:flex; align-items:center; gap:.75rem; padding:.625rem .875rem; border-radius:10px; color:rgba(255,255,255,.6); text-decoration:none; font-size:.9375rem; font-weight:500; transition:all .15s; }
    a.nav-item:hover { background:rgba(255,255,255,.07); color:rgba(255,255,255,.9); }
    a.nav-item.active { background:#f59e0b; color:#fff; }
    .nav-icon { font-size:1.1rem; line-height:1; opacity:.8; }
    footer { padding:1rem .75rem; border-top:1px solid rgba(255,255,255,.08); display:flex; flex-direction:column; gap:.5rem; }
    .user-chip { display:flex; align-items:center; gap:.75rem; padding:.625rem .75rem; background:rgba(255,255,255,.05); border-radius:10px; }
    .avatar { width:34px; height:34px; background:#1a4d2e; border:2px solid #f59e0b; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.75rem; font-weight:700; color:#fff; flex-shrink:0; }
    .user-email { font-size:.75rem; color:rgba(255,255,255,.65); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .user-role  { font-size:.65rem; font-weight:700; color:#f59e0b; text-transform:uppercase; letter-spacing:.05em; }
    .logout-btn { display:flex; align-items:center; gap:.5rem; width:100%; padding:.5rem .75rem; background:transparent; border:1px solid rgba(255,255,255,.12); border-radius:10px; color:rgba(255,255,255,.5); font-size:.875rem; cursor:pointer; transition:all .15s; font-family:inherit; }
    .logout-btn:hover { border-color:rgba(220,38,38,.5); color:#f87171; background:rgba(220,38,38,.08); }
  `],
  template: `
    <aside>
      <div class="brand">
        <div class="brand-icon">🌾</div>
        <div><span class="brand-name">AgriChain</span><span class="brand-sub">Supply Platform</span></div>
      </div>
      <nav>
        <span class="section-label">Menu</span>
        @for (item of nav(); track item.route) {
          <a class="nav-item" [routerLink]="item.route" routerLinkActive="active">
            <span class="nav-icon">{{item.icon}}</span> {{item.label}}
          </a>
        }
      </nav>
      <footer>
        <a class="nav-item" routerLink="/profile" routerLinkActive="active" style="border:1px solid rgba(255,255,255,.1)">
          <span class="nav-icon">⚙️</span> My Profile
        </a>
        <div class="user-chip">
          <div class="avatar">{{initials()}}</div>
          <div style="min-width:0">
            <div class="user-email">{{auth.email()}}</div>
            <div class="user-role">{{auth.role()}}</div>
          </div>
        </div>
        <button class="logout-btn" (click)="auth.logout()">⎋ Logout</button>
      </footer>
    </aside>`
})
export class SidebarComponent {
  nav = computed(() => {
    const r = this.auth.role();
    return NAV.filter(n => !(n as any).roles || (n as any).roles.includes(r));
  });
  initials = computed(() => this.auth.email().substring(0, 2).toUpperCase());
  constructor(public auth: AuthService) {}
}
