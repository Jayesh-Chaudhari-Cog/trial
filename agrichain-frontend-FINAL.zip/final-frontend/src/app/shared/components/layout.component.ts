import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from './sidebar.component';
import { ToastsComponent } from './toasts.component';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule],
  styles: [`
    header { height:64px; background:#fff; border-bottom:1px solid #e2ddd5; display:flex; align-items:center; justify-content:space-between; padding:0 2rem; position:fixed; top:0; left:260px; right:0; z-index:50; box-shadow:0 1px 3px rgba(0,0,0,.06); }
    .title { font-size:1.1rem; font-weight:600; }
    .sub   { font-size:.875rem; color:#6b6b6b; margin-left:.75rem; }
    .date  { font-size:.875rem; color:#6b6b6b; font-weight:500; }
  `],
  template: `
    <header>
      <div><span class="title">{{title}}</span>@if(subtitle){<span class="sub">{{subtitle}}</span>}</div>
      <span class="date">{{today}}</span>
    </header>`
})
export class TopbarComponent {
  @Input() title = '';
  @Input() subtitle = '';
  today = new Date().toLocaleDateString('en-IN', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
}

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, ToastsComponent],
  template: `
    <div class="app-layout">
      <app-sidebar />
      <div class="main-content"><router-outlet /></div>
    </div>
    <app-toasts />`
})
export class LayoutComponent {}
