import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../core/toast.service';

@Component({
  selector: 'app-toasts',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-wrap">
      @for (t of toast.list(); track t.id) {
        <div class="toast toast-{{t.type}}" (click)="toast.remove(t.id)">
          <span>{{ icon(t.type) }}</span>
          <span style="flex:1">{{ t.msg }}</span>
          <button class="toast-close">✕</button>
        </div>
      }
    </div>`
})
export class ToastsComponent {
  constructor(public toast: ToastService) {}
  icon(t: string) { return { success:'✅', danger:'❌', warn:'⚠️', info:'ℹ️' }[t] ?? 'ℹ️'; }
}
