import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  UserRequest, UserResponse,
  Farmer, FarmerDocument,
  CropListing, Order,
  SubsidyProgram, Disbursement,
  Audit, Compliance, AuditLog,
  Report, ReportDTO
} from '../models/models';

const BASE = environment.apiUrl;

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private h: HttpClient) {}
  getAll(): Observable<UserResponse[]>          { return this.h.get<UserResponse[]>(`${BASE}/users`); }
  getById(id: number): Observable<UserResponse> { return this.h.get<UserResponse>(`${BASE}/users/${id}`); }
  update(id: number, d: UserRequest): Observable<UserResponse> { return this.h.put<UserResponse>(`${BASE}/users/${id}`, d); }
  deactivate(id: number): Observable<string>    { return this.h.delete(`${BASE}/users/${id}`, { responseType: 'text' }); }
}

@Injectable({ providedIn: 'root' })
export class FarmerService {
  constructor(private h: HttpClient) {}
  getAll(): Observable<Farmer[]>                          { return this.h.get<Farmer[]>(`${BASE}/farmers`); }
  getById(id: number): Observable<Farmer>                 { return this.h.get<Farmer>(`${BASE}/farmers/${id}`); }
  create(f: Farmer): Observable<Farmer>                   { return this.h.post<Farmer>(`${BASE}/farmers`, f); }
  update(id: number, f: Farmer): Observable<Farmer>      { return this.h.put<Farmer>(`${BASE}/farmers/${id}`, f); }
  delete(id: number): Observable<void>                    { return this.h.delete<void>(`${BASE}/farmers/${id}`); }
  getDocs(farmerId: number): Observable<FarmerDocument[]> { return this.h.get<FarmerDocument[]>(`${BASE}/documents/farmer/${farmerId}`); }
  uploadDoc(d: FarmerDocument): Observable<FarmerDocument>{ return this.h.post<FarmerDocument>(`${BASE}/documents`, d); }
  verifyDoc(id: number, status: string): Observable<FarmerDocument> {
    return this.h.put<FarmerDocument>(`${BASE}/documents/${id}/verify`, { status });
  }
}

@Injectable({ providedIn: 'root' })
export class MarketService {
  constructor(private h: HttpClient) {}
  getListings(): Observable<CropListing[]>           { return this.h.get<CropListing[]>(`${BASE}/market/listings`); }
  createListing(d: CropListing): Observable<CropListing> { return this.h.post<CropListing>(`${BASE}/market/createlisting`, d); }
  validateListing(id: number): Observable<CropListing>   { return this.h.put<CropListing>(`${BASE}/market/listings/validate/${id}`, {}); }
  getOrders(): Observable<Order[]>                   { return this.h.get<Order[]>(`${BASE}/market/orders`); }
  placeOrder(d: Order): Observable<Order>            { return this.h.post<Order>(`${BASE}/market/placeorder`, d); }
  updateOrderStatus(id: number, status: string): Observable<Order> {
    return this.h.put<Order>(`${BASE}/market/orders/${id}/status`, null,
      { params: new HttpParams().set('status', status) });
  }
}

@Injectable({ providedIn: 'root' })
export class SubsidyService {
  constructor(private h: HttpClient) {}
  getPrograms(): Observable<SubsidyProgram[]>              { return this.h.get<SubsidyProgram[]>(`${BASE}/subsidy-programs`); }
  createProgram(p: SubsidyProgram): Observable<SubsidyProgram>   { return this.h.post<SubsidyProgram>(`${BASE}/subsidy-programs`, p); }
  updateProgram(id: number, p: SubsidyProgram): Observable<SubsidyProgram> { return this.h.put<SubsidyProgram>(`${BASE}/subsidy-programs/${id}`, p); }
  deleteProgram(id: number): Observable<string>            { return this.h.delete(`${BASE}/subsidy-programs/${id}`, { responseType: 'text' }); }
  getDisbursements(): Observable<Disbursement[]>           { return this.h.get<Disbursement[]>(`${BASE}/disbursements`); }
  apply(d: Disbursement): Observable<Disbursement>         { return this.h.post<Disbursement>(`${BASE}/disbursements`, d); }
  review(id: number, status: string): Observable<Disbursement> {
    return this.h.patch<Disbursement>(`${BASE}/disbursements/${id}/review`, null,
      { params: new HttpParams().set('status', status) });
  }
}

@Injectable({ providedIn: 'root' })
export class AuditService {
  constructor(private h: HttpClient) {}
  getAudits(): Observable<Audit[]>                         { return this.h.get<Audit[]>(`${BASE}/api/audits/all`); }
  createAudit(a: Audit): Observable<Audit>                 { return this.h.post<Audit>(`${BASE}/api/audits/create`, a); }
  updateAudit(id: number, a: Audit): Observable<Audit>     { return this.h.put<Audit>(`${BASE}/api/audits/${id}`, a); }
  deleteAudit(id: number): Observable<void>                { return this.h.delete<void>(`${BASE}/api/audits/${id}`); }
  getCompliances(): Observable<Compliance[]>               { return this.h.get<Compliance[]>(`${BASE}/api/compliances/all`); }
  createCompliance(auditId: number, c: Compliance): Observable<Compliance> { return this.h.post<Compliance>(`${BASE}/api/compliances/create/${auditId}`, c); }
  updateCompliance(id: number, c: Compliance): Observable<Compliance> { return this.h.put<Compliance>(`${BASE}/api/compliances/update/${id}`, c); }
  deleteCompliance(id: number): Observable<void>           { return this.h.delete<void>(`${BASE}/api/compliances/delete/${id}`); }
  getLogs(): Observable<AuditLog[]>                        { return this.h.get<AuditLog[]>(`${BASE}/api/auditlogs/all`); }
}

@Injectable({ providedIn: 'root' })
export class ReportService {
  constructor(private h: HttpClient) {}
  getAll(): Observable<Report[]>                           { return this.h.get<Report[]>(`${BASE}/api/report/all`); }
  generate(d: ReportDTO): Observable<Report>               { return this.h.post<Report>(`${BASE}/api/report/generate`, d); }
  update(id: number, d: ReportDTO): Observable<Report>     { return this.h.put<Report>(`${BASE}/api/report/update/${id}`, d); }
  delete(id: number): Observable<string>                   { return this.h.delete(`${BASE}/api/report/delete/${id}`, { responseType: 'text' }); }
  txnReport(status: string): Observable<Report>            { return this.h.get<Report>(`${BASE}/api/report/transactionsreport/${status}`); }
}
