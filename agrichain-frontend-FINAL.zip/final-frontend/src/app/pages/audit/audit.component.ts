// ── audit.component.ts ───────────────────────────────────────────────────────
import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { AuditService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { Audit, Compliance } from '../../models/models';


@Component({
  selector: 'app-audit', standalone: true, imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Audit & Compliance" subtitle="Track audits and compliance checks" />
    <div class="page-content">
      <div class="tab-bar">
        <button class="tab-btn" [class.active]="tab()==='audits'"     (click)="tab.set('audits')">📋 Audits</button>
        <button class="tab-btn" [class.active]="tab()==='compliance'" (click)="tab.set('compliance')">✅ Compliance</button>
      </div>

      @if (tab()==='audits') {
        <div class="page-header">
          <div><h2 class="page-title">Audits</h2><p class="page-sub">{{audits().length}} total</p></div>
          <button class="btn btn-primary" (click)="openAudit()">＋ Create Audit</button>
        </div>
        <div class="flex gap-2 mb-4" style="flex-wrap:wrap">
          <select class="form-control" style="width:155px" [(ngModel)]="asf" (ngModelChange)="filterA()">
            <option value="">All Scopes</option><option>FINANCIAL</option><option>OPERATIONAL</option><option>COMPLIANCE</option><option>ENVIRONMENTAL</option>
          </select>
          <select class="form-control" style="width:155px" [(ngModel)]="astf" (ngModelChange)="filterA()">
            <option value="">All Status</option><option>SCHEDULED</option><option>IN_PROGRESS</option><option>COMPLETED</option><option>CANCELLED</option>
          </select>
        </div>
        <div class="card">
          @if (la()) { <div class="loading"><span class="spinner"></span></div> }
          @else if (!fa().length) { <div class="empty"><div class="empty-icon">📋</div><h3>No audits</h3></div> }
          @else {
            <div class="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Title</th><th>Scope</th><th>Status</th><th>Officer</th><th>Scheduled</th><th>Actions</th></tr></thead>
                <tbody>
                  @for (a of fa(); track a.auditId) {
                    <tr>
                      <td class="text-muted">{{a.auditId}}</td>
                      <td class="font-semibold">{{a.title}}</td>
                      <td><span class="badge badge-info">{{a.scope}}</span></td>
                      <td><span class="badge" [class]="asb(a.status)">{{a.status}}</span></td>
                      <td>{{a.officerId||'—'}}</td><td>{{a.scheduledDate||'—'}}</td>
                      <td>
                        <div class="flex gap-2">
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="openAudit(a)">✏️</button>
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="loadC2(a.auditId!)">📋</button>
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="delAudit(a.auditId!)">🗑️</button>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }

      @if (tab()==='compliance') {
        <div class="page-header">
          <div><h2 class="page-title">Compliance Records</h2><p class="page-sub">{{compliances().length}} records</p></div>
          <button class="btn btn-primary" (click)="openComp()">＋ Add Compliance</button>
        </div>
        <div class="card">
          @if (lc()) { <div class="loading"><span class="spinner"></span></div> }
          @else if (!compliances().length) { <div class="empty"><div class="empty-icon">✅</div><h3>No records</h3></div> }
          @else {
            <div class="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Audit</th><th>Type</th><th>Result</th><th>Description</th><th>Due</th><th>Actions</th></tr></thead>
                <tbody>
                  @for (c of compliances(); track c.complianceId) {
                    <tr>
                      <td class="text-muted">{{c.complianceId}}</td><td>{{c.auditId}}</td>
                      <td><span class="badge badge-primary">{{c.complianceType}}</span></td>
                      <td><span class="badge" [class]="crb(c.result)">{{c.result}}</span></td>
                      <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{c.description||'—'}}</td>
                      <td>{{c.dueDate||'—'}}</td>
                      <td>
                        <div class="flex gap-2">
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="openComp(c)">✏️</button>
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="delComp(c.complianceId!)">🗑️</button>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }
    </div>

    @if (showAM()) {
      <div class="overlay" (click)="showAM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>{{editA?'Edit':'Create'}} Audit</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showAM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (aerr()) { <div class="alert alert-danger">{{aerr()}}</div> }
            <div class="form-group"><label class="form-label">Title *</label><input class="form-control" [(ngModel)]="ad.title" /></div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Scope *</label>
                <select class="form-control" [(ngModel)]="ad.scope"><option value="">—</option><option>FINANCIAL</option><option>OPERATIONAL</option><option>COMPLIANCE</option><option>ENVIRONMENTAL</option></select>
              </div>
              <div class="form-group"><label class="form-label">Status *</label>
                <select class="form-control" [(ngModel)]="ad.status"><option value="">—</option><option>SCHEDULED</option><option>IN_PROGRESS</option><option>COMPLETED</option><option>CANCELLED</option></select>
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Officer ID</label><input class="form-control" type="number" [(ngModel)]="ad.officerId" /></div>
              <div class="form-group"><label class="form-label">Scheduled Date</label><input class="form-control" type="date" [(ngModel)]="ad.scheduledDate" /></div>
            </div>
            <div class="form-group mt-3"><label class="form-label">Findings</label><input class="form-control" [(ngModel)]="ad.findings" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showAM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveAudit()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} Save</button>
          </div>
        </div>
      </div>
    }

    @if (showCM()) {
      <div class="overlay" (click)="showCM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>{{editC?'Edit':'Add'}} Compliance</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showCM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (cerr()) { <div class="alert alert-danger">{{cerr()}}</div> }
            <div class="form-group"><label class="form-label">Audit ID *</label><input class="form-control" type="number" [(ngModel)]="cd.auditId" /></div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Type *</label>
                <select class="form-control" [(ngModel)]="cd.complianceType"><option value="">—</option><option>REGULATORY</option><option>INTERNAL</option><option>EXTERNAL</option><option>STATUTORY</option></select>
              </div>
              <div class="form-group"><label class="form-label">Result *</label>
                <select class="form-control" [(ngModel)]="cd.result"><option value="">—</option><option>COMPLIANT</option><option>NON_COMPLIANT</option><option>PARTIAL</option><option>PENDING</option></select>
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Due Date</label><input class="form-control" type="date" [(ngModel)]="cd.dueDate" /></div>
              <div class="form-group"><label class="form-label">Closed Date</label><input class="form-control" type="date" [(ngModel)]="cd.closedDate" /></div>
            </div>
            <div class="form-group mt-3"><label class="form-label">Description</label><input class="form-control" [(ngModel)]="cd.description" /></div>
            <div class="form-group mt-3"><label class="form-label">Remarks</label><input class="form-control" [(ngModel)]="cd.remarks" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showCM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveComp()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} Save</button>
          </div>
        </div>
      </div>
    }`
})
export class AuditComponent implements OnInit {
  tab=signal<'audits'|'compliance'>('audits');
  audits=signal<Audit[]>([]); fa=signal<Audit[]>([]); compliances=signal<Compliance[]>([]);
  la=signal(true); lc=signal(true); sv=signal(false);
  showAM=signal(false); showCM=signal(false);
  editA:Audit|null=null; editC:Compliance|null=null;
  ad:Partial<Audit>={}; cd:Partial<Compliance>={}; aerr=signal(''); cerr=signal('');
  asf=''; astf='';
  constructor(private svc:AuditService, private toast:ToastService){}
  ngOnInit(){ this.loadA(); this.loadC(); }
  loadA(){ this.svc.getAudits().subscribe({next:d=>{this.audits.set(d);this.filterA();this.la.set(false);},error:()=>this.la.set(false)}); }
  loadC(){ this.svc.getCompliances().subscribe({next:d=>{this.compliances.set(d);this.lc.set(false);},error:()=>this.lc.set(false)}); }
  filterA(){ let r=this.audits(); if(this.asf)r=r.filter(a=>a.scope===this.asf); if(this.astf)r=r.filter(a=>a.status===this.astf); this.fa.set(r); }
  openAudit(a?:Audit){ this.ad=a?{...a}:{}; this.editA=a??null; this.aerr.set(''); this.showAM.set(true); }
  saveAudit(){
    if(!this.ad.title||!this.ad.scope||!this.ad.status){this.aerr.set('Fill required fields.');return;}
    this.sv.set(true);
    const obs=this.editA?this.svc.updateAudit(this.editA.auditId!,this.ad as Audit):this.svc.createAudit(this.ad as Audit);
    obs.subscribe({next:()=>{this.sv.set(false);this.showAM.set(false);this.loadA();this.toast.success('Saved.');},error:()=>{this.aerr.set('Failed.');this.sv.set(false);}});
  }
  delAudit(id:number){ if(!confirm('Delete?'))return; this.svc.deleteAudit(id).subscribe({next:()=>{this.loadA();this.toast.success('Deleted.');},error:()=>this.toast.error('Failed.')}); }
  loadC2(auditId:number){ this.tab.set('compliance'); this.svc.getCompliances().subscribe({next:d=>{this.compliances.set(d.filter(c=>c.auditId===auditId));this.lc.set(false);},error:()=>this.lc.set(false)}); }
  openComp(c?:Compliance){ this.cd=c?{...c}:{}; this.editC=c??null; this.cerr.set(''); this.showCM.set(true); }
  saveComp(){
    if(!this.cd.auditId||!this.cd.complianceType||!this.cd.result){this.cerr.set('Fill required fields.');return;}
    this.sv.set(true);
    const obs=this.editC?this.svc.updateCompliance(this.editC.complianceId!,this.cd as Compliance):this.svc.createCompliance(this.cd.auditId!,this.cd as Compliance);
    obs.subscribe({next:()=>{this.sv.set(false);this.showCM.set(false);this.loadC();this.toast.success('Saved.');},error:()=>{this.cerr.set('Failed.');this.sv.set(false);}});
  }
  delComp(id:number){ if(!confirm('Delete?'))return; this.svc.deleteCompliance(id).subscribe({next:()=>{this.loadC();this.toast.success('Deleted.');},error:()=>this.toast.error('Failed.')}); }
  asb(s?:string){return s==='COMPLETED'?'badge badge-success':s==='CANCELLED'?'badge badge-danger':s==='IN_PROGRESS'?'badge badge-warn':'badge badge-info';}
  crb(r?:string){return r==='COMPLIANT'?'badge badge-success':r==='NON_COMPLIANT'?'badge badge-danger':r==='PARTIAL'?'badge badge-warn':'badge badge-neutral';}
}
