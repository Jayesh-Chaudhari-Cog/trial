import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { ReportService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { Report, ReportDTO } from '../../models/models';

@Component({
  selector: 'app-reports', standalone: true, imports: [CommonModule, FormsModule, TopbarComponent],
  styles: [`
    .rg{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:1.25rem;}
    .rc{background:#fff;border:1px solid #e2ddd5;border-radius:16px;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);display:flex;flex-direction:column;gap:.625rem;transition:box-shadow .2s;}
    .rc:hover{box-shadow:0 4px 12px rgba(0,0,0,.08);}
    .rc-top{display:flex;justify-content:space-between;align-items:center;}
    .rc-id{font-weight:700;font-size:.9375rem;color:#6b6b6b;}
    .rc-lbl{font-size:.7rem;text-transform:uppercase;letter-spacing:.06em;font-weight:600;color:#9ca3af;}
    .rc-val{font-size:.9375rem;margin-top:.2rem;}
    .rc-date{font-size:.8125rem;color:#9ca3af;}
  `],
  template: `
    <app-topbar title="Reports" subtitle="Generate and manage analytical reports" />
    <div class="page-content">
      <div class="page-header">
        <div><h2 class="page-title">Reports</h2><p class="page-sub">{{reports().length}} generated</p></div>
        <div class="flex gap-2">
          <button class="btn btn-outline" (click)="showTxn.set(true)">📊 Transaction Report</button>
          <button class="btn btn-primary" (click)="openGen()">＋ Generate Report</button>
        </div>
      </div>
      @if (loading()) { <div class="loading"><span class="spinner"></span></div> }
      @else if (!reports().length) { <div class="empty"><div class="empty-icon">📊</div><h3>No reports yet</h3><p>Generate your first report above.</p></div> }
      @else {
        <div class="rg">
          @for (r of reports(); track r.reportId) {
            <div class="rc">
              <div class="rc-top">
                <div class="rc-id">Report #{{r.reportId}}</div>
                <div class="flex gap-2">
                  <button class="btn btn-ghost btn-sm btn-icon" (click)="openEdit(r)">✏️</button>
                  <button class="btn btn-ghost btn-sm btn-icon" (click)="del(r.reportId!)">🗑️</button>
                </div>
              </div>
              <span class="badge badge-primary">{{r.scope}}</span>
              <div><div class="rc-lbl">Metrics</div><div class="rc-val">{{r.metrics}}</div></div>
              <div class="rc-date">📅 {{r.generatedDate||'Today'}}</div>
            </div>
          }
        </div>
      }
    </div>

    @if (showM()) {
      <div class="overlay" (click)="showM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>{{editing?'Edit':'Generate'}} Report</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (err()) { <div class="alert alert-danger">{{err()}}</div> }
            <div class="form-group"><label class="form-label">Scope *</label><input class="form-control" [(ngModel)]="dto.scope" placeholder="QUARTERLY, ANNUAL…" /></div>
            <div class="form-group mt-3"><label class="form-label">Metrics *</label><input class="form-control" [(ngModel)]="dto.metrics" placeholder="Total Sales, Farmer Count…" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="save()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} {{editing?'Save':'Generate'}}</button>
          </div>
        </div>
      </div>
    }

    @if (showTxn()) {
      <div class="overlay" (click)="showTxn.set(false)">
        <div class="modal" style="max-width:420px" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>Transaction Report</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showTxn.set(false)">✕</button></div>
          <div class="modal-body">
            <div class="form-group"><label class="form-label">Transaction Status *</label>
              <select class="form-control" [(ngModel)]="txnStatus"><option value="">Select…</option><option>SUCCESS</option><option>PENDING</option><option>FAILED</option></select>
            </div>
            @if (txnResult()) { <div class="alert alert-success mt-3">✅ Report #{{txnResult()!.reportId}} generated!</div> }
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showTxn.set(false)">Close</button>
            <button class="btn btn-primary" (click)="genTxn()" [disabled]="sv()||!txnStatus">@if(sv()){<span class="spinner"></span>} Generate</button>
          </div>
        </div>
      </div>
    }`
})
export class ReportsComponent implements OnInit {
  reports=signal<Report[]>([]); loading=signal(true); sv=signal(false);
  showM=signal(false); showTxn=signal(false); editing:Report|null=null;
  dto:Partial<ReportDTO>={}; err=signal(''); txnStatus=''; txnResult=signal<Report|null>(null);
  constructor(private svc:ReportService, private toast:ToastService){}
  ngOnInit(){ this.load(); }
  load(){ this.svc.getAll().subscribe({next:d=>{this.reports.set(d);this.loading.set(false);},error:()=>this.loading.set(false)}); }
  openGen(){ this.dto={}; this.editing=null; this.err.set(''); this.showM.set(true); }
  openEdit(r:Report){ this.dto={scope:r.scope,metrics:r.metrics}; this.editing=r; this.err.set(''); this.showM.set(true); }
  save(){
    if(!this.dto.scope||!this.dto.metrics){this.err.set('Scope and metrics required.');return;}
    this.sv.set(true);
    const obs=this.editing?this.svc.update(this.editing.reportId!,this.dto as ReportDTO):this.svc.generate(this.dto as ReportDTO);
    obs.subscribe({next:()=>{this.sv.set(false);this.showM.set(false);this.load();this.toast.success('Done.');},error:()=>{this.err.set('Failed.');this.sv.set(false);}});
  }
  del(id:number){ if(!confirm('Delete?'))return; this.svc.delete(id).subscribe({next:()=>{this.load();this.toast.success('Deleted.');},error:()=>this.toast.error('Failed.')}); }
  genTxn(){
    this.sv.set(true);
    this.svc.txnReport(this.txnStatus).subscribe({next:r=>{this.txnResult.set(r);this.sv.set(false);this.load();},error:()=>{this.toast.error('Failed.');this.sv.set(false);}});
  }
}
