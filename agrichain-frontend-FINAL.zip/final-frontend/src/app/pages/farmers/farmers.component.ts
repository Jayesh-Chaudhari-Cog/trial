import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { FarmerService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { Farmer, FarmerDocument, DocType } from '../../models/models';

@Component({
  selector: 'app-farmers',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  styles: [`
    .sel-row { background: rgba(26,77,46,.04) !important; }
    .docs-panel { padding:1.25rem; background:#f7f6f1; border-top:2px solid #1a4d2e; }
    .docs-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:.875rem; margin-top:.875rem; }
    .doc-card { background:#fff; border:1px solid #e2ddd5; border-radius:10px; padding:1rem; display:flex; flex-direction:column; gap:.4rem; }
    .doc-icon { font-size:1.75rem; }
    .doc-url  { font-size:.8125rem; color:#1a4d2e; text-decoration:underline; }
    .doc-acts { display:flex; gap:.4rem; margin-top:.25rem; }
  `],
  template: `
    <app-topbar title="Farmers" subtitle="Register and manage farmer profiles" />
    <div class="page-content">
      <div class="page-header">
        <div><h1 class="page-title">Farmers</h1><p class="page-sub">{{filtered().length}} records</p></div>
        <button class="btn btn-primary" (click)="openCreate()">＋ Register Farmer</button>
      </div>
      <div class="card">
        <div class="card-header">
          <div class="search-bar"><span>🔍</span><input type="text" placeholder="Search…" [(ngModel)]="q" (ngModelChange)="filter()" /></div>
          <select class="form-control" style="width:150px" [(ngModel)]="statusF" (ngModelChange)="filter()">
            <option value="">All Status</option>
            <option value="PENDING">PENDING</option><option value="APPROVED">APPROVED</option><option value="REJECTED">REJECTED</option>
          </select>
        </div>
        @if (loading()) { <div class="loading"><span class="spinner"></span> Loading…</div> }
        @else if (!filtered().length) { <div class="empty"><div class="empty-icon">🧑‍🌾</div><h3>No farmers found</h3></div> }
        @else {
          <div class="table-wrap">
            <table>
              <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>State</th><th>Land(ac)</th><th>Status</th><th>Verified</th><th>Actions</th></tr></thead>
              <tbody>
                @for (f of filtered(); track f.farmerId) {
                  <tr [class.sel-row]="docsFor()===f.farmerId">
                    <td class="text-muted">{{f.farmerId}}</td>
                    <td class="font-semibold">{{f.fullName}}</td>
                    <td>{{f.email}}</td><td>{{f.phone}}</td>
                    <td>{{f.state||'—'}}</td><td>{{f.landHoldingAcres??'—'}}</td>
                    <td><span class="badge" [class]="sb(f.status)">{{f.status}}</span></td>
                    <td><span class="badge" [class]="vb(f.verificationStatus)">{{f.verificationStatus}}</span></td>
                    <td>
                      <div class="flex gap-2">
                        <button class="btn btn-ghost btn-sm btn-icon" title="Edit" (click)="openEdit(f)">✏️</button>
                        <button class="btn btn-ghost btn-sm btn-icon" title="Documents" (click)="toggleDocs(f.farmerId!)">📄</button>
                        <button class="btn btn-ghost btn-sm btn-icon" title="Delete" (click)="del(f.farmerId!)">🗑️</button>
                      </div>
                    </td>
                  </tr>
                  @if (docsFor()===f.farmerId) {
                    <tr><td colspan="9" style="padding:0">
                      <div class="docs-panel">
                        <div class="flex justify-between items-center">
                          <strong>Documents for {{f.fullName}}</strong>
                          <button class="btn btn-primary btn-sm" (click)="openUpload(f.farmerId!)">＋ Upload</button>
                        </div>
                        @if (loadingDocs()) { <div class="loading" style="padding:1rem"><span class="spinner"></span></div> }
                        @else if (!docs().length) { <p class="text-muted text-sm mt-2">No documents uploaded yet.</p> }
                        @else {
                          <div class="docs-grid">
                            @for (d of docs(); track d.documentId) {
                              <div class="doc-card">
                                <div class="doc-icon">{{dicon(d.docType)}}</div>
                                <div class="font-semibold text-sm">{{d.docType}}</div>
                                <a class="doc-url" [href]="d.documentUrl" target="_blank">View ↗</a>
                                <span class="badge mt-2" [class]="vb(d.verificationStatus)">{{d.verificationStatus}}</span>
                                @if (d.verificationStatus==='UNVERIFIED') {
                                  <div class="doc-acts">
                                    <button class="btn btn-sm" style="background:#dcfce7;color:#15803d;border:none" (click)="verify(d.documentId!,'VERIFIED')">✅ Verify</button>
                                    <button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;border:none" (click)="verify(d.documentId!,'REJECTED')">❌</button>
                                  </div>
                                }
                              </div>
                            }
                          </div>
                        }
                      </div>
                    </td></tr>
                  }
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>

    @if (showModal()) {
      <div class="overlay" (click)="showModal.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>{{editId?'Edit':'Register'}} Farmer</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showModal.set(false)">✕</button></div>
          <div class="modal-body">
            @if (merr()) { <div class="alert alert-danger">{{merr()}}</div> }
            <div class="grid-2">
              <div class="form-group"><label class="form-label">Full Name *</label><input class="form-control" [(ngModel)]="dto.fullName" /></div>
              <div class="form-group"><label class="form-label">Gender</label>
                <select class="form-control" [(ngModel)]="dto.gender"><option value="">—</option><option>MALE</option><option>FEMALE</option><option>OTHER</option></select>
              </div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Email *</label><input class="form-control" type="email" [(ngModel)]="dto.email" /></div>
              <div class="form-group"><label class="form-label">Phone *</label><input class="form-control" [(ngModel)]="dto.phone" /></div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">State</label><input class="form-control" [(ngModel)]="dto.state" /></div>
              <div class="form-group"><label class="form-label">Land (Acres)</label><input class="form-control" type="number" [(ngModel)]="dto.landHoldingAcres" /></div>
            </div>
            <div class="form-group mt-3"><label class="form-label">Address</label><input class="form-control" [(ngModel)]="dto.address" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="save()" [disabled]="saving()">@if(saving()){<span class="spinner"></span>} {{editId?'Save':'Register'}}</button>
          </div>
        </div>
      </div>
    }

    @if (showUploadModal()) {
      <div class="overlay" (click)="showUploadModal.set(false)">
        <div class="modal" style="max-width:420px" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>Upload Document</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showUploadModal.set(false)">✕</button></div>
          <div class="modal-body">
            <div class="form-group"><label class="form-label">Document Type *</label>
              <select class="form-control" [(ngModel)]="udto.docType">
                <option value="">Select…</option>
                @for (t of docTypes; track t) { <option [value]="t">{{t}}</option> }
              </select>
            </div>
            <div class="form-group mt-3"><label class="form-label">Document URL *</label><input class="form-control" type="url" [(ngModel)]="udto.documentUrl" placeholder="https://…" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showUploadModal.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitUpload()" [disabled]="saving()">@if(saving()){<span class="spinner"></span>} Upload</button>
          </div>
        </div>
      </div>
    }`
})
export class FarmersComponent implements OnInit {
  farmers = signal<Farmer[]>([]); filtered = signal<Farmer[]>([]);
  docs = signal<FarmerDocument[]>([]); loading = signal(true); loadingDocs = signal(false);
  showModal = signal(false); showUploadModal = signal(false); saving = signal(false);
  docsFor = signal<number|null>(null); editId: number|null = null;
  dto: Partial<Farmer> = {}; udto: Partial<FarmerDocument> = {};
  merr = signal(''); q = ''; statusF = '';
  docTypes: DocType[] = ['AADHAR','PAN','LAND_RECORD','BANK_PASSBOOK','OTHER'];

  constructor(private svc: FarmerService, private toast: ToastService) {}
  ngOnInit() { this.load(); }
  load() {
    this.loading.set(true);
    this.svc.getAll().subscribe({ next: d => { this.farmers.set(d); this.filter(); this.loading.set(false); }, error: () => this.loading.set(false) });
  }
  filter() {
    let r = this.farmers();
    if (this.q) { const lq=this.q.toLowerCase(); r=r.filter(f=>f.fullName?.toLowerCase().includes(lq)||f.email?.toLowerCase().includes(lq)); }
    if (this.statusF) r=r.filter(f=>f.status===this.statusF);
    this.filtered.set(r);
  }
  toggleDocs(id: number) {
    if (this.docsFor()===id) { this.docsFor.set(null); return; }
    this.docsFor.set(id); this.loadingDocs.set(true);
    this.svc.getDocs(id).subscribe({ next: d => { this.docs.set(d); this.loadingDocs.set(false); }, error: () => this.loadingDocs.set(false) });
  }
  openCreate() { this.dto={}; this.editId=null; this.merr.set(''); this.showModal.set(true); }
  openEdit(f: Farmer) { this.dto={...f}; this.editId=f.farmerId??null; this.merr.set(''); this.showModal.set(true); }
  save() {
    if (!this.dto.fullName||!this.dto.email||!this.dto.phone) { this.merr.set('Name, email and phone are required.'); return; }
    this.saving.set(true);
    const obs = this.editId ? this.svc.update(this.editId, this.dto as Farmer) : this.svc.create(this.dto as Farmer);
    obs.subscribe({ next: () => { this.saving.set(false); this.showModal.set(false); this.load(); this.toast.success(this.editId?'Farmer updated.':'Farmer registered.'); }, error: () => { this.merr.set('Operation failed.'); this.saving.set(false); } });
  }
  del(id: number) {
    if (!confirm('Delete farmer?')) return;
    this.svc.delete(id).subscribe({ next: () => { this.load(); this.toast.success('Deleted.'); }, error: () => this.toast.error('Delete failed.') });
  }
  openUpload(farmerId: number) { this.udto={ farmerId, verificationStatus:'UNVERIFIED' }; this.showUploadModal.set(true); }
  submitUpload() {
    if (!this.udto.docType||!this.udto.documentUrl) { this.toast.warn('Fill all fields.'); return; }
    this.saving.set(true);
    this.svc.uploadDoc(this.udto as FarmerDocument).subscribe({
      next: () => { this.saving.set(false); this.showUploadModal.set(false); const id=this.docsFor(); if(id) this.toggleDocs(id); this.toast.success('Uploaded.'); },
      error: () => { this.saving.set(false); this.toast.error('Upload failed.'); }
    });
  }
  verify(id: number, status: string) {
    this.svc.verifyDoc(id, status).subscribe({ next: () => { const f=this.docsFor(); if(f){this.docsFor.set(null);setTimeout(()=>this.toggleDocs(f),100);} this.toast.success(`Document ${status}.`); }, error: () => this.toast.error('Failed.') });
  }
  sb(s?: string) { return s==='APPROVED'?'badge badge-success':s==='REJECTED'?'badge badge-danger':'badge badge-warn'; }
  vb(v?: string) { return v==='VERIFIED'?'badge badge-success':v==='REJECTED'?'badge badge-danger':'badge badge-neutral'; }
  dicon(t?: string) { return ({AADHAR:'🪪',PAN:'💳',LAND_RECORD:'🏡',BANK_PASSBOOK:'🏦',OTHER:'📄'} as any)[t??'']??'📄'; }
}
