import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TopbarComponent } from '../../shared/components/layout.component';
import { AuthService } from '../../core/auth.service';
import { UserService, FarmerService, MarketService, SubsidyService } from '../../services/api.services';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent],
  styles: [`
    .quick { display:flex; flex-direction:column; gap:.5rem; }
    .qa { display:flex; align-items:center; gap:1rem; padding:.875rem; border-radius:10px; border:1px solid #e2ddd5; text-decoration:none; color:#1a1a1a; transition:all .15s; }
    .qa:hover { border-color:#1a4d2e; background:rgba(26,77,46,.04); }
    .qa-icon { font-size:1.5rem; line-height:1; }
    .qa-label { font-size:.9375rem; font-weight:600; }
    .qa-desc  { font-size:.8125rem; color:#6b6b6b; }
    .sys-rows { display:flex; flex-direction:column; gap:.875rem; }
    .sys-row  { display:flex; align-items:center; justify-content:space-between; font-size:.9375rem; color:#6b6b6b; padding:.375rem 0; border-bottom:1px solid #f0ede6; }
    .sys-row:last-child { border:none; }
    .sys-val  { font-weight:500; color:#1a1a1a; }
  `],
  template: `
    <app-topbar title="Dashboard" [subtitle]="greeting()" />
    <div class="page-content">
      <div class="grid-4 mb-4">
        @for (s of stats(); track s.label) {
          <div class="stat-card">
            <div class="stat-icon" [style.background]="s.bg">{{s.icon}}</div>
            <div class="stat-value">{{s.value ?? '—'}}</div>
            <div class="stat-label">{{s.label}}</div>
          </div>
        }
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-header"><h3>Quick Actions</h3></div>
          <div class="card-body">
            <div class="quick">
              @for (q of quick(); track q.label) {
                <a class="qa" [routerLink]="q.route">
                  <span class="qa-icon">{{q.icon}}</span>
                  <div><div class="qa-label">{{q.label}}</div><div class="qa-desc">{{q.desc}}</div></div>
                </a>
              }
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><h3>Session Info</h3></div>
          <div class="card-body">
            <div class="sys-rows">
              <div class="sys-row"><span>🔒 Logged in as</span><span class="sys-val">{{auth.email()}}</span></div>
              <div class="sys-row"><span>🎭 Role</span><span class="badge badge-primary">{{auth.role()}}</span></div>
              <div class="sys-row"><span>🌐 API Gateway</span><span class="badge badge-success">localhost:8090</span></div>
              <div class="sys-row"><span>📅 Today</span><span class="sys-val">{{today}}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>`
})
export class DashboardComponent implements OnInit {
  today = new Date().toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
  greeting = computed(() => {
    const h = new Date().getHours();
    const g = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
    return `${g}, ${this.auth.email().split('@')[0]}`;
  });
  stats = signal([
    { label:'Total Users',      value: null as number|null, icon:'👥', bg:'rgba(37,99,235,.12)' },
    { label:'Farmers',          value: null as number|null, icon:'🧑‍🌾', bg:'rgba(26,77,46,.12)' },
    { label:'Crop Listings',    value: null as number|null, icon:'🌽', bg:'rgba(245,158,11,.12)' },
    { label:'Subsidy Programs', value: null as number|null, icon:'💰', bg:'rgba(22,163,74,.12)' },
  ]);
  quick = computed(() => {
    const r = this.auth.role();
    return [
      { icon:'🌽', label:'Crop Market',        desc:'View listings & place orders',   route:'/market' },
      { icon:'🧑‍🌾', label:'Manage Farmers',     desc:'Register and verify farmers',    route:'/farmers' },
      { icon:'💰', label:'Subsidy Programs',   desc:'Apply or manage disbursements',  route:'/subsidy' },
      ...(['ADMIN','MANAGER','AUDITOR','COMPLIANCE','OFFICER'].includes(r)
        ? [{ icon:'📋', label:'Audit & Compliance', desc:'Track audits and compliance', route:'/audit' }] : []),
      ...(['ADMIN','MANAGER','AUDITOR','OFFICER'].includes(r)
        ? [{ icon:'📊', label:'Reports',          desc:'Generate analytical reports',   route:'/reports' }] : []),
    ];
  });
  constructor(public auth: AuthService, private us: UserService, private fs: FarmerService,
              private ms: MarketService, private ss: SubsidyService) {}
  ngOnInit() {
    const upd = (i: number, v: number) => this.stats.update(s => s.map((x,j) => j===i ? {...x, value:v} : x));
    if (this.auth.hasRole('ADMIN','MANAGER','OFFICER','AUDITOR'))
      this.us.getAll().subscribe({ next: r => upd(0, r.length), error: ()=>{} });
    this.fs.getAll().subscribe({ next: r => upd(1, r.length), error: ()=>{} });
    this.ms.getListings().subscribe({ next: r => upd(2, r.length), error: ()=>{} });
    this.ss.getPrograms().subscribe({ next: r => upd(3, r.length), error: ()=>{} });
  }
}
