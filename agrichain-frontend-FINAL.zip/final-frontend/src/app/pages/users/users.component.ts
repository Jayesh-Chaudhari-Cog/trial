import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { UserService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { UserResponse, UserRequest, UserRole } from '../../models/models';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="User Management" subtitle="Manage platform users" />
    <div class="page-content">
      <div class="page-header">
        <div><h1 class="page-title">Users</h1><p class="page-sub">{{filtered().length}} of {{users().length}} users</p></div>
      </div>
      <div class="card">
        <div class="card-header">
          <div class="search-bar">
            <span>🔍</span>
            <input type="text" placeholder="Search name or email…" [(ngModel)]="q" (ngModelChange)="filter()" />
          </div>
          <select class="form-control" style="width:150px" [(ngModel)]="roleF" (ngModelChange)="filter()">
            <option value="">All Roles</option>
            @for (r of roles; track r) { <option [value]="r">{{r}}</option> }
          </select>
        </div>
        @if (loading()) { <div class="loading"><span class="spinner"></span> Loading…</div> }
        @else if (filtered().length === 0) {
          <div class="empty"><div class="empty-icon">👤</div><h3>No users found</h3></div>
        } @else {
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                @for (u of filtered(); track u.userId) {
                  <tr>
                    <td class="text-muted">{{u.userId}}</td>
                    <td class="font-semibold">{{u.name}}</td>
                    <td>{{u.email}}</td><td>{{u.phone}}</td>
                    <td><span class="badge badge-primary">{{u.role}}</span></td>
                    <td><span class="badge" [class]="sb(u.status)">{{u.status}}</span></td>
                    <td>
                      <div class="flex gap-2">
                        <button class="btn btn-ghost btn-sm btn-icon" (click)="edit(u)">✏️</button>
                        <button class="btn btn-ghost btn-sm btn-icon" (click)="deactivate(u.userId)">🚫</button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>

    @if (editing()) {
      <div class="overlay" (click)="editing.set(null)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>Edit User #{{editing()!.userId}}</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="editing.set(null)">✕</button></div>
          <div class="modal-body">
            <div class="form-group"><label class="form-label">Name</label><input class="form-control" [(ngModel)]="dto.name" /></div>
            <div class="form-group mt-3"><label class="form-label">Email</label><input class="form-control" type="email" [(ngModel)]="dto.email" /></div>
            <div class="form-group mt-3"><label class="form-label">Phone</label><input class="form-control" [(ngModel)]="dto.phone" /></div>
            <div class="form-group mt-3"><label class="form-label">Role</label>
              <select class="form-control" [(ngModel)]="dto.role">
                @for (r of roles; track r) { <option [value]="r">{{r}}</option> }
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="editing.set(null)">Cancel</button>
            <button class="btn btn-primary" (click)="save()" [disabled]="saving()">@if(saving()){<span class="spinner"></span>} Save</button>
          </div>
        </div>
      </div>
    }`
})
export class UsersComponent implements OnInit {
  users = signal<UserResponse[]>([]); filtered = signal<UserResponse[]>([]);
  loading = signal(true); saving = signal(false); editing = signal<UserResponse|null>(null);
  dto: Partial<UserRequest> = {}; q = ''; roleF = '';
  roles: UserRole[] = ['FARMER','TRADER','OFFICER','MANAGER','ADMIN','COMPLIANCE','AUDITOR'];

  constructor(private svc: UserService, private toast: ToastService) {}
  ngOnInit() {
    this.svc.getAll().subscribe({
      next: d => { this.users.set(d); this.filtered.set(d); this.loading.set(false); },
      error: () => { this.toast.error('Failed to load users.'); this.loading.set(false); }
    });
  }
  filter() {
    let r = this.users();
    if (this.q) { const lq = this.q.toLowerCase(); r = r.filter(u => u.name.toLowerCase().includes(lq) || u.email.toLowerCase().includes(lq)); }
    if (this.roleF) r = r.filter(u => u.role === this.roleF);
    this.filtered.set(r);
  }
  edit(u: UserResponse) { this.editing.set(u); this.dto = { name:u.name, email:u.email, phone:u.phone, role:u.role }; }
  save() {
    const u = this.editing(); if (!u) return;
    this.saving.set(true);
    this.svc.update(u.userId, this.dto as UserRequest).subscribe({
      next: updated => {
        this.users.update(l => l.map(x => x.userId===updated.userId ? updated : x));
        this.filter(); this.editing.set(null); this.saving.set(false);
        this.toast.success('User updated.');
      },
      error: () => { this.toast.error('Update failed.'); this.saving.set(false); }
    });
  }
  deactivate(id: number) {
    if (!confirm('Deactivate this user?')) return;
    this.svc.deactivate(id).subscribe({
      next: () => { this.users.update(l => l.filter(u => u.userId!==id)); this.filter(); this.toast.success('User deactivated.'); },
      error: () => this.toast.error('Failed.')
    });
  }
  sb(s: string) { return s==='ACTIVE'?'badge badge-success':s==='INACTIVE'?'badge badge-neutral':'badge badge-danger'; }
}
