import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  styles: [`
    .shell{display:flex;min-height:100vh;}
    .left{flex:1;background:#0f2e1a;padding:3rem;display:flex;flex-direction:column;justify-content:center;}
    .hero-h1{font-family:'Playfair Display',serif;font-size:3rem;color:#fff;line-height:1.1;margin-bottom:.75rem;}
    .hero-icon{font-size:3rem;margin-bottom:1rem;}
    .hero-p{font-size:1.0625rem;color:rgba(255,255,255,.5);max-width:320px;line-height:1.6;}
    .right{width:520px;display:flex;align-items:center;justify-content:center;padding:2rem;background:#f7f6f1;}
    .card{width:100%;max-width:420px;}
    .card h2{font-size:1.625rem;font-weight:700;margin-bottom:.25rem;}
    .card p{font-size:.9375rem;color:#6b6b6b;margin-bottom:2rem;}
    .switch{margin-top:1.5rem;text-align:center;font-size:.9375rem;color:#6b6b6b;}
    .switch a{color:#1a4d2e;font-weight:600;}
    @media(max-width:768px){.shell{flex-direction:column;}.right{width:100%;}}
  `],
  template: `
    <div class="shell">
      <div class="left">
        <div class="hero-icon">🌾</div>
        <h1 class="hero-h1">Join AgriChain</h1>
        <p class="hero-p">Create your account to access the agricultural supply chain platform.</p>
      </div>
      <div class="right">
        <div class="card">
          <h2>Create Account</h2>
          <p>Fill in your details to get started</p>
          @if (ok()) { <div class="alert alert-success">✅ {{ok()}}</div> }
          @if (err()) { <div class="alert alert-danger">⚠️ {{err()}}</div> }
          <form (ngSubmit)="submit()">
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input class="form-control" [(ngModel)]="f.name" name="name" placeholder="Jane Doe" required />
              </div>
              <div class="form-group">
                <label class="form-label">Role *</label>
                <select class="form-control" [(ngModel)]="f.role" name="role" required>
                  <option value="">Select…</option>
                  @for (r of roles; track r) { <option [value]="r">{{r}}</option> }
                </select>
              </div>
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Email *</label>
              <input class="form-control" type="email" [(ngModel)]="f.email" name="email" required />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Phone *</label>
              <input class="form-control" type="tel" [(ngModel)]="f.phone" name="phone" required />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Password *</label>
              <input class="form-control" type="password" [(ngModel)]="f.password" name="pw" required />
            </div>
            <button class="btn btn-primary btn-lg w-full mt-4" type="submit" [disabled]="loading()">
              @if(loading()){<span class="spinner"></span>} {{loading()?'Creating…':'Create Account'}}
            </button>
          </form>
          <p class="switch">Already have an account? <a routerLink="/login">Sign in →</a></p>
        </div>
      </div>
    </div>`
})
export class RegisterComponent {
  f: any = { name:'', email:'', phone:'', password:'', role:'' };
  loading = signal(false); err = signal(''); ok = signal('');
  roles = ['FARMER','TRADER','OFFICER','MANAGER','ADMIN','COMPLIANCE','AUDITOR'];
  constructor(private auth: AuthService, private router: Router) {}
  submit() {
    this.err.set(''); this.loading.set(true);
    this.auth.register({ ...this.f, status: 'ACTIVE' }).subscribe({
      next: () => { this.ok.set('Account created! Redirecting…'); setTimeout(() => this.router.navigate(['/login']), 1500); },
      error: e  => { this.err.set(e?.error || 'Registration failed.'); this.loading.set(false); }
    });
  }
}
