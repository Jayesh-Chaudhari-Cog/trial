import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  styles: [`
    .shell { display:flex; min-height:100vh; }
    .left  { flex:1; background:#0f2e1a; padding:3rem; display:flex; flex-direction:column; justify-content:center; position:relative; overflow:hidden; }
    .left::before { content:''; position:absolute; width:400px; height:400px; background:radial-gradient(circle,rgba(245,158,11,.15) 0%,transparent 70%); top:-100px; right:-100px; border-radius:50%; }
    .hero-icon { font-size:3rem; margin-bottom:1rem; }
    .hero-h1   { font-family:'Playfair Display',serif; font-size:3rem; color:#fff; line-height:1.1; margin-bottom:.75rem; }
    .hero-p    { font-size:1.0625rem; color:rgba(255,255,255,.5); max-width:320px; line-height:1.6; }
    .features  { margin-top:2.5rem; display:flex; flex-direction:column; gap:.875rem; }
    .feat      { display:flex; align-items:center; gap:.875rem; color:rgba(255,255,255,.65); font-size:.9375rem; }
    .feat-icon { width:36px; height:36px; background:rgba(255,255,255,.08); border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .right     { width:480px; display:flex; align-items:center; justify-content:center; padding:2rem; background:#f7f6f1; }
    .card      { width:100%; max-width:400px; }
    .card h2   { font-size:1.625rem; font-weight:700; margin-bottom:.25rem; }
    .card p    { font-size:.9375rem; color:#6b6b6b; margin-bottom:2rem; }
    .pw-wrap   { position:relative; }
    .pw-eye    { position:absolute; right:.75rem; top:50%; transform:translateY(-50%); background:none; border:none; cursor:pointer; font-size:1rem; }
    .switch    { margin-top:1.5rem; text-align:center; font-size:.9375rem; color:#6b6b6b; }
    .switch a  { color:#1a4d2e; font-weight:600; }
    @media(max-width:768px){ .shell{flex-direction:column;} .right{width:100%;} }
  `],
  template: `
    <div class="shell">
      <div class="left">
        <div class="hero-icon">🌾</div>
        <h1 class="hero-h1">AgriChain</h1>
        <p class="hero-p">Agricultural Supply Chain Management Platform</p>
        <div class="features">
          @for (f of features; track f.text) {
            <div class="feat"><div class="feat-icon">{{f.icon}}</div><span>{{f.text}}</span></div>
          }
        </div>
      </div>
      <div class="right">
        <div class="card">
          <h2>Welcome back</h2>
          <p>Sign in to your account</p>
          @if (err()) { <div class="alert alert-danger">⚠️ {{err()}}</div> }
          <form (ngSubmit)="submit()">
            <div class="form-group">
              <label class="form-label">Email</label>
              <input class="form-control" type="email" [(ngModel)]="email" name="email" placeholder="you@example.com" required />
            </div>
            <div class="form-group mt-3">
              <label class="form-label">Password</label>
              <div class="pw-wrap">
                <input class="form-control" [type]="show()?'text':'password'" [(ngModel)]="password" name="pw" placeholder="••••••••" required />
                <button type="button" class="pw-eye" (click)="show.set(!show())">{{show()?'🙈':'👁️'}}</button>
              </div>
            </div>
            <button class="btn btn-primary btn-lg w-full mt-4" type="submit" [disabled]="loading()">
              @if (loading()) { <span class="spinner"></span> } {{loading()?'Signing in…':'Sign In'}}
            </button>
          </form>
          <p class="switch">Don't have an account? <a routerLink="/register">Create one →</a></p>
        </div>
      </div>
    </div>`
})
export class LoginComponent {
  email = ''; password = '';
  loading = signal(false); err = signal(''); show = signal(false);
  features = [
    { icon:'🌽', text:'Crop listing and order management' },
    { icon:'💰', text:'Government subsidy tracking' },
    { icon:'📋', text:'Compliance and audit workflows' },
    { icon:'📊', text:'Real-time analytics reports' },
  ];
  constructor(private auth: AuthService, private router: Router) {}
  submit() {
    if (!this.email || !this.password) { this.err.set('Enter email and password.'); return; }
    this.loading.set(true); this.err.set('');
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: e  => { this.err.set(e?.error || 'Invalid credentials.'); this.loading.set(false); }
    });
  }
}
