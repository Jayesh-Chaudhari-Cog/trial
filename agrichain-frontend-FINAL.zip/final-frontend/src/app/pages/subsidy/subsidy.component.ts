import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { SubsidyService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { AuthService } from '../../core/auth.service';
import { SubsidyProgram, Disbursement } from '../../models/models';

@Component({
  selector: 'app-subsidy',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  styles: [`
    .prog-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:1.25rem;}
    .prog-card{background:#fff;border:1px solid #e2ddd5;border-radius:16px;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);transition:box-shadow .2s;}
    .prog-card:hover{box-shadow:0 4px 12px rgba(0,0,0,.08);}
    .pc-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.5rem;}
    .pc-title{font-size:1rem;font-weight:700;}
    .pc-desc{font-size:.875rem;color:#6b6b6b;margin-bottom:.75rem;line-height:1.5;}
    .pc-budget{background:#f0ede6;border-radius:10px;padding:.75rem;margin-bottom:.75rem;font-size:.875rem;}
    .brow{display:flex;justify-content:space-between;}
    .brow strong{color:#1a1a1a;}
    .pc-dates{font-size:.8125rem;color:#9ca3af;margin-bottom:.75rem;}
  `],
  template: `
    <app-topbar title="Subsidy" subtitle="Programs and disbursements" />
    <div class="page-content">
      <div class="tab-bar">
        <button class="tab-btn" [class.active]="tab()==='programs'"       (click)="switchTab('programs')">💰 Programs</button>
        <button class="tab-btn" [class.active]="tab()==='disbursements'"  (click)="switchTab('disbursements')">📤 Disbursements</button>
      </div>

      @if (tab()==='programs') {
        <div class="page-header">
          <div><h2 class="page-title">Subsidy Programs</h2><p class="page-sub">{{programs().length}} programs</p></div>
          @if (canManage()) { <button class="btn btn-primary" (click)="openProg()">＋ New Program</button> }
        </div>
        @if (lp()) { <div class="loading"><span class="spinner"></span></div> }
        @else if (!programs().length) { <div class="empty"><div class="empty-icon">💰</div><h3>No programs</h3></div> }
        @else {
          <div class="prog-grid">
            @for (p of programs(); track p.programId) {
              <div class="prog-card">
                <div class="pc-top">
                  <div class="pc-title">{{p.title}}</div>
                  @if (canManage()) {
                    <div class="flex gap-2">
                      <button class="btn btn-ghost btn-sm btn-icon" (click)="editProg(p)">✏️</button>
                      <button class="btn btn-ghost btn-sm btn-icon" (click)="deleteProg(p.programId!)">🗑️</button>
                    </div>
                  }
                </div>
                <p class="pc-desc">{{p.description||'No description.'}}</p>
                <div class="pc-budget">
                  <div class="brow"><span>Allotted Budget</span><strong>₹{{p.allottedBudget|number}}</strong></div>
                  @if (p.disbursedAmount) { <div class="brow mt-2"><span>Disbursed</span><strong>₹{{p.disbursedAmount|number}}</strong></div> }
                </div>
                @if (p.startDate||p.endDate) { <p class="pc-dates">📅 {{p.startDate||'?'}} → {{p.endDate||'ongoing'}}</p> }
                <button class="btn btn-outline btn-sm w-full" (click)="openApply(p)">Apply for Disbursement</button>
              </div>
            }
          </div>
        }
      }

      @if (tab()==='disbursements') {
        <div class="page-header"><div><h2 class="page-title">Disbursements</h2><p class="page-sub">{{disbursements().length}} applications</p></div></div>
        @if (ld()) { <div class="loading"><span class="spinner"></span></div> }
        @else if (!disbursements().length) { <div class="empty"><div class="empty-icon">📤</div><h3>No disbursements</h3></div> }
        @else {
          <div class="card">
            <div class="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Farmer</th><th>Program</th><th>Requested</th><th>Approved</th><th>Status</th><th>Remarks</th>@if(canManage()){<th>Review</th>}</tr></thead>
                <tbody>
                  @for (d of disbursements(); track d.disbursementId) {
                    <tr>
                      <td class="text-muted">{{d.disbursementId}}</td><td>{{d.farmerId}}</td><td>{{d.programId}}</td>
                      <td>₹{{d.requestedAmount|number}}</td><td>{{d.approvedAmount?'₹'+(d.approvedAmount|number):'—'}}</td>
                      <td><span class="badge" [class]="db(d.status)">{{d.status}}</span></td>
                      <td>{{d.remarks||'—'}}</td>
                      @if (canManage()) {
                        <td>
                          @if (d.status==='PENDING') {
                            <div class="flex gap-2">
                              <button class="btn btn-sm" style="background:#dcfce7;color:#15803d;border:none" (click)="review(d.disbursementId!,'APPROVED')">✅ Approve</button>
                              <button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;border:none" (click)="review(d.disbursementId!,'REJECTED')">❌ Reject</button>
                            </div>
                          } @else { <span class="text-muted text-sm">—</span> }
                        </td>
                      }
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }
      }
    </div>

    @if (showPM()) {
      <div class="overlay" (click)="showPM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>{{editingProg?'Edit':'New'}} Program</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showPM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (perr()) { <div class="alert alert-danger">{{perr()}}</div> }
            <div class="form-group"><label class="form-label">Title *</label><input class="form-control" [(ngModel)]="pd.title" /></div>
            <div class="form-group mt-3"><label class="form-label">Description</label><input class="form-control" [(ngModel)]="pd.description" /></div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Budget (₹) *</label><input class="form-control" type="number" [(ngModel)]="pd.allottedBudget" /></div>
              <div class="form-group"><label class="form-label">Eligibility</label><input class="form-control" [(ngModel)]="pd.eligibilityCriteria" /></div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Start Date</label><input class="form-control" type="date" [(ngModel)]="pd.startDate" /></div>
              <div class="form-group"><label class="form-label">End Date</label><input class="form-control" type="date" [(ngModel)]="pd.endDate" /></div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showPM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="saveProg()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} Save</button>
          </div>
        </div>
      </div>
    }

    @if (showAM()) {
      <div class="overlay" (click)="showAM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>Apply — {{selectedProg()?.title}}</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showAM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (aerr()) { <div class="alert alert-danger">{{aerr()}}</div> }
            <div class="form-group"><label class="form-label">Farmer ID *</label><input class="form-control" type="number" [(ngModel)]="ad.farmerId" /></div>
            <div class="form-group mt-3"><label class="form-label">Requested Amount (₹) *</label><input class="form-control" type="number" [(ngModel)]="ad.requestedAmount" /></div>
            <div class="form-group mt-3"><label class="form-label">Remarks</label><input class="form-control" [(ngModel)]="ad.remarks" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showAM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitApply()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} Submit</button>
          </div>
        </div>
      </div>
    }`
})
export class SubsidyComponent implements OnInit {
  tab=signal<'programs'|'disbursements'>('programs');
  programs=signal<SubsidyProgram[]>([]); disbursements=signal<Disbursement[]>([]);
  lp=signal(true); ld=signal(true); sv=signal(false);
  showPM=signal(false); showAM=signal(false);
  editingProg:SubsidyProgram|null=null; selectedProg=signal<SubsidyProgram|null>(null);
  pd:Partial<SubsidyProgram>={}; ad:any={}; perr=signal(''); aerr=signal('');
  constructor(private svc:SubsidyService, private toast:ToastService, private auth:AuthService){}
  ngOnInit(){ this.loadP(); this.loadD(); }
  loadP(){ this.svc.getPrograms().subscribe({next:d=>{this.programs.set(d);this.lp.set(false);},error:()=>this.lp.set(false)}); }
  loadD(){ this.svc.getDisbursements().subscribe({next:d=>{this.disbursements.set(d);this.ld.set(false);},error:()=>this.ld.set(false)}); }
  switchTab(t:'programs'|'disbursements'){ this.tab.set(t); if(t==='disbursements')this.loadD(); }
  canManage(){ return this.auth.hasRole('ADMIN','MANAGER','OFFICER'); }
  openProg(){ this.pd={}; this.editingProg=null; this.perr.set(''); this.showPM.set(true); }
  editProg(p:SubsidyProgram){ this.pd={...p}; this.editingProg=p; this.perr.set(''); this.showPM.set(true); }
  saveProg(){
    if(!this.pd.title||!this.pd.allottedBudget){this.perr.set('Title and budget required.');return;}
    this.sv.set(true);
    const obs=this.editingProg?this.svc.updateProgram(this.editingProg.programId!,this.pd as SubsidyProgram):this.svc.createProgram(this.pd as SubsidyProgram);
    obs.subscribe({next:()=>{this.sv.set(false);this.showPM.set(false);this.loadP();this.toast.success('Saved.');},error:()=>{this.perr.set('Failed.');this.sv.set(false);}});
  }
  deleteProg(id:number){ if(!confirm('Delete?'))return; this.svc.deleteProgram(id).subscribe({next:()=>{this.loadP();this.toast.success('Deleted.');},error:()=>this.toast.error('Failed.')}); }
  openApply(p:SubsidyProgram){ this.selectedProg.set(p); this.ad={farmerId:undefined,requestedAmount:undefined}; this.aerr.set(''); this.showAM.set(true); }
  submitApply(){
    if(!this.ad.farmerId||!this.ad.requestedAmount){this.aerr.set('Fill required fields.');return;}
    this.sv.set(true);
    this.svc.apply({farmerId:this.ad.farmerId,programId:this.selectedProg()!.programId!,requestedAmount:this.ad.requestedAmount,remarks:this.ad.remarks} as Disbursement).subscribe({
      next:()=>{this.sv.set(false);this.showAM.set(false);this.loadD();this.tab.set('disbursements');this.toast.success('Application submitted.');},
      error:()=>{this.aerr.set('Failed.');this.sv.set(false);}
    });
  }
  review(id:number,status:string){ this.svc.review(id,status).subscribe({next:()=>{this.loadD();this.toast.success(`${status}.`);},error:()=>this.toast.error('Failed.')}); }
  db(s?:string){return s==='APPROVED'||s==='DISBURSED'?'badge badge-success':s==='REJECTED'?'badge badge-danger':'badge badge-warn';}
}
