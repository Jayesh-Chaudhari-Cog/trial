// ── market.component.ts ──────────────────────────────────────────────────────
import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { MarketService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { AuthService } from '../../core/auth.service';
import { CropListing, Order } from '../../models/models';


@Component({
  selector: 'app-market', standalone: true, imports: [CommonModule, FormsModule, TopbarComponent],
  template: `
    <app-topbar title="Crop Market" subtitle="Listings and order management" />
    <div class="page-content">
      <div class="tab-bar">
        <button class="tab-btn" [class.active]="tab()==='listings'" (click)="tab.set('listings')">🌽 Listings</button>
        <button class="tab-btn" [class.active]="tab()==='orders'"   (click)="tab.set('orders')">📦 Orders</button>
      </div>

      @if (tab()==='listings') {
        <div class="page-header">
          <div><h2 class="page-title">Crop Listings</h2><p class="page-sub">{{listings().length}} total</p></div>
          <button class="btn btn-primary" (click)="openListing()">＋ New Listing</button>
        </div>
        <div class="card">
          <div class="card-header">
            <div class="search-bar"><span>🔍</span><input [(ngModel)]="lq" (ngModelChange)="filterL()" placeholder="Search crop…" /></div>
            <select class="form-control" style="width:150px" [(ngModel)]="lstatus" (ngModelChange)="filterL()">
              <option value="">All Status</option><option>PENDING</option><option>APPROVED</option><option>REJECTED</option><option>SOLD</option>
            </select>
          </div>
          @if (ll()) { <div class="loading"><span class="spinner"></span></div> }
          @else if (!fl().length) { <div class="empty"><div class="empty-icon">🌽</div><h3>No listings</h3></div> }
          @else {
            <div class="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Farmer</th><th>Crop</th><th>Qty(kg)</th><th>₹/kg</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                  @for (l of fl(); track l.listingId) {
                    <tr>
                      <td class="text-muted">{{l.listingId}}</td><td>{{l.farmerId}}</td>
                      <td class="font-semibold">{{l.cropName}}</td><td>{{l.quantityKg}}</td>
                      <td>₹{{l.pricePerKg}}</td><td>{{l.location||'—'}}</td>
                      <td><span class="badge" [class]="lb(l.status)">{{l.status}}</span></td>
                      <td>
                        <div class="flex gap-2">
                          @if (l.status==='PENDING' && canValidate()) {
                            <button class="btn btn-sm btn-outline" (click)="validate(l.listingId!)">✅ Validate</button>
                          }
                          <button class="btn btn-ghost btn-sm btn-icon" (click)="openOrder(l)">📦</button>
                        </div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }

      @if (tab()==='orders') {
        <div class="page-header">
          <div><h2 class="page-title">Orders</h2><p class="page-sub">{{orders().length}} total</p></div>
          <button class="btn btn-primary" (click)="openOrder(null)">＋ Place Order</button>
        </div>
        <div class="card">
          @if (ol()) { <div class="loading"><span class="spinner"></span></div> }
          @else if (!orders().length) { <div class="empty"><div class="empty-icon">📦</div><h3>No orders</h3></div> }
          @else {
            <div class="table-wrap">
              <table>
                <thead><tr><th>Order ID</th><th>Listing</th><th>Trader</th><th>Qty</th><th>Total</th><th>Status</th><th>Update</th></tr></thead>
                <tbody>
                  @for (o of orders(); track o.orderId) {
                    <tr>
                      <td class="text-muted">{{o.orderId}}</td><td>{{o.listingId}}</td><td>{{o.traderId}}</td>
                      <td>{{o.quantityOrdered}}</td><td>{{o.totalPrice?'₹'+o.totalPrice:'—'}}</td>
                      <td><span class="badge" [class]="ob(o.status)">{{o.status}}</span></td>
                      <td>
                        <select class="form-control" style="width:130px;font-size:.8125rem" [ngModel]="o.status" (ngModelChange)="updateStatus(o.orderId!,$event)">
                          <option>PLACED</option><option>CONFIRMED</option><option>SHIPPED</option><option>DELIVERED</option><option>CANCELLED</option>
                        </select>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      }
    </div>

    @if (showLM()) {
      <div class="overlay" (click)="showLM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>New Crop Listing</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showLM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (lerr()) { <div class="alert alert-danger">{{lerr()}}</div> }
            <div class="grid-2">
              <div class="form-group"><label class="form-label">Farmer ID *</label><input class="form-control" type="number" [(ngModel)]="ld.farmerId" /></div>
              <div class="form-group"><label class="form-label">Crop Name *</label><input class="form-control" [(ngModel)]="ld.cropName" /></div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Quantity (kg) *</label><input class="form-control" type="number" [(ngModel)]="ld.quantityKg" /></div>
              <div class="form-group"><label class="form-label">Price/kg (₹) *</label><input class="form-control" type="number" [(ngModel)]="ld.pricePerKg" /></div>
            </div>
            <div class="grid-2 mt-3">
              <div class="form-group"><label class="form-label">Variety</label><input class="form-control" [(ngModel)]="ld.variety" /></div>
              <div class="form-group"><label class="form-label">Location</label><input class="form-control" [(ngModel)]="ld.location" /></div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showLM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitListing()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} Create</button>
          </div>
        </div>
      </div>
    }

    @if (showOM()) {
      <div class="overlay" (click)="showOM.set(false)">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header"><h3>Place Order</h3><button class="btn btn-ghost btn-sm btn-icon" (click)="showOM.set(false)">✕</button></div>
          <div class="modal-body">
            @if (oerr()) { <div class="alert alert-danger">{{oerr()}}</div> }
            <div class="grid-2">
              <div class="form-group"><label class="form-label">Listing ID *</label><input class="form-control" type="number" [(ngModel)]="od.listingId" /></div>
              <div class="form-group"><label class="form-label">Trader ID *</label><input class="form-control" type="number" [(ngModel)]="od.traderId" /></div>
            </div>
            <div class="form-group mt-3"><label class="form-label">Quantity (kg) *</label><input class="form-control" type="number" [(ngModel)]="od.quantityOrdered" /></div>
            <div class="form-group mt-3"><label class="form-label">Delivery Address</label><input class="form-control" [(ngModel)]="od.deliveryAddress" /></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" (click)="showOM.set(false)">Cancel</button>
            <button class="btn btn-primary" (click)="submitOrder()" [disabled]="sv()">@if(sv()){<span class="spinner"></span>} Place Order</button>
          </div>
        </div>
      </div>
    }`
})
export class MarketComponent implements OnInit {
  tab=signal<'listings'|'orders'>('listings'); listings=signal<CropListing[]>([]); fl=signal<CropListing[]>([]);
  orders=signal<Order[]>([]); ll=signal(true); ol=signal(true); sv=signal(false);
  showLM=signal(false); showOM=signal(false); lerr=signal(''); oerr=signal('');
  ld:Partial<CropListing>={}; od:Partial<Order>={}; lq=''; lstatus='';
  constructor(private svc:MarketService, private toast:ToastService, private auth:AuthService){}
  ngOnInit(){ this.loadL(); this.loadO(); }
  loadL(){ this.svc.getListings().subscribe({next:d=>{this.listings.set(d);this.filterL();this.ll.set(false);},error:()=>this.ll.set(false)}); }
  loadO(){ this.svc.getOrders().subscribe({next:d=>{this.orders.set(d);this.ol.set(false);},error:()=>this.ol.set(false)}); }
  filterL(){ let r=this.listings(); if(this.lq){const lq=this.lq.toLowerCase();r=r.filter(l=>l.cropName?.toLowerCase().includes(lq));} if(this.lstatus)r=r.filter(l=>l.status===this.lstatus); this.fl.set(r); }
  canValidate(){ return this.auth.hasRole('ADMIN','MANAGER','OFFICER'); }
  validate(id:number){ this.svc.validateListing(id).subscribe({next:()=>{this.loadL();this.toast.success('Listing validated.');},error:()=>this.toast.error('Failed.')}); }
  openListing(){ this.ld={}; this.lerr.set(''); this.showLM.set(true); }
  openOrder(l:CropListing|null){ this.od=l?{listingId:l.listingId}:{}; this.oerr.set(''); this.showOM.set(true); }
  submitListing(){
    if(!this.ld.farmerId||!this.ld.cropName||!this.ld.quantityKg||!this.ld.pricePerKg){this.lerr.set('Fill required fields.');return;}
    this.sv.set(true);
    this.svc.createListing(this.ld as CropListing).subscribe({next:()=>{this.sv.set(false);this.showLM.set(false);this.loadL();this.toast.success('Listing created.');},error:()=>{this.lerr.set('Failed.');this.sv.set(false);}});
  }
  submitOrder(){
    if(!this.od.listingId||!this.od.traderId||!this.od.quantityOrdered){this.oerr.set('Fill required fields.');return;}
    this.sv.set(true);
    this.svc.placeOrder(this.od as Order).subscribe({next:()=>{this.sv.set(false);this.showOM.set(false);this.loadO();this.tab.set('orders');this.toast.success('Order placed.');},error:()=>{this.oerr.set('Failed.');this.sv.set(false);}});
  }
  updateStatus(id:number,status:string){ this.svc.updateOrderStatus(id,status).subscribe({next:()=>{this.loadO();this.toast.success('Status updated.');},error:()=>this.toast.error('Failed.')}); }
  lb(s?:string){return s==='APPROVED'?'badge badge-success':s==='REJECTED'?'badge badge-danger':s==='SOLD'?'badge badge-info':'badge badge-warn';}
  ob(s?:string){return s==='DELIVERED'?'badge badge-success':s==='CANCELLED'?'badge badge-danger':s==='PLACED'?'badge badge-warn':'badge badge-info';}
}
