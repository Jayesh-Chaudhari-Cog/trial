// ── audit-logs.component.ts ───────────────────────────────────────────────────
import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { AuditService } from '../../services/api.services';
import { AuditLog } from '../../models/models';


@Component({
  selector: 'app-audit-logs', standalone: true, imports: [CommonModule, FormsModule, TopbarComponent],
  styles: [`
    .chip{display:inline-flex;padding:.2rem .55rem;border-radius:4px;font-size:.7rem;font-weight:700;font-family:'Courier New',monospace;text-transform:uppercase;}
    .chip-c{background:rgba(22,163,74,.12);color:#15803d;}
    .chip-u{background:rgba(37,99,235,.12);color:#1d4ed8;}
    .chip-d{background:rgba(220,38,38,.12);color:#b91c1c;}
    .chip-l{background:rgba(245,158,11,.12);color:#b45309;}
    .chip-x{background:#f0ede6;color:#6b6b6b;}
  `],
  template: `
    <app-topbar title="Audit Logs" subtitle="System-wide activity trail" />
    <div class="page-content">
      <div class="page-header"><div><h2 class="page-title">System Logs</h2><p class="page-sub">{{filtered().length}} of {{logs().length}} entries</p></div></div>
      <div class="card">
        <div class="card-header">
          <div class="search-bar"><span>🔍</span><input [(ngModel)]="q" (ngModelChange)="filter()" placeholder="Search action, user, role…" /></div>
          <select class="form-control" style="width:150px" [(ngModel)]="rf" (ngModelChange)="filter()">
            <option value="">All Roles</option>
            @for (r of roles; track r) { <option [value]="r">{{r}}</option> }
          </select>
        </div>
        @if (loading()) { <div class="loading"><span class="spinner"></span></div> }
        @else if (!filtered().length) { <div class="empty"><div class="empty-icon">🗒️</div><h3>No logs found</h3></div> }
        @else {
          <div class="table-wrap">
            <table>
              <thead><tr><th>Log ID</th><th>Performed By</th><th>Action</th><th>Role</th><th>Details</th><th>Timestamp</th></tr></thead>
              <tbody>
                @for (l of filtered(); track l.logId) {
                  <tr>
                    <td class="text-muted">{{l.logId}}</td>
                    <td class="font-semibold">{{l.performedBy}}</td>
                    <td><span class="chip" [class]="ac(l.action)">{{l.action}}</span></td>
                    <td><span class="badge badge-primary">{{l.role}}</span></td>
                    <td style="max-width:260px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{l.details||'—'}}</td>
                    <td class="text-muted text-sm">{{fmt(l.timestamp)}}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>`
})
export class AuditLogsComponent implements OnInit {
  logs=signal<AuditLog[]>([]); filtered=signal<AuditLog[]>([]);
  loading=signal(true); q=''; rf='';
  roles=['ADMIN','MANAGER','FARMER','TRADER','OFFICER','AUDITOR','COMPLIANCE','USER','SYSTEM'];
  constructor(private svc:AuditService){}
  ngOnInit(){ this.svc.getLogs().subscribe({next:d=>{this.logs.set(d);this.filtered.set(d);this.loading.set(false);},error:()=>this.loading.set(false)}); }
  filter(){
    let r=this.logs();
    if(this.q){const lq=this.q.toLowerCase();r=r.filter(l=>l.action?.toLowerCase().includes(lq)||l.performedBy?.toLowerCase().includes(lq)||l.role?.toLowerCase().includes(lq));}
    if(this.rf)r=r.filter(l=>l.role===this.rf);
    this.filtered.set(r);
  }
  ac(a?:string){const u=(a??'').toUpperCase();return u.includes('CREATE')||u.includes('REGISTER')?'chip chip-c':u.includes('UPDATE')||u.includes('EDIT')?'chip chip-u':u.includes('DELETE')||u.includes('DEACTIVATE')?'chip chip-d':u.includes('LOGIN')||u.includes('AUTH')?'chip chip-l':'chip chip-x';}
  fmt(ts?:string){if(!ts)return'—';try{return new Date(ts).toLocaleString('en-IN',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});}catch{return ts;}}
}
