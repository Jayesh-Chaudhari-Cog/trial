import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TopbarComponent } from '../../shared/components/layout.component';
import { AuthService } from '../../core/auth.service';
import { UserService } from '../../services/api.services';
import { ToastService } from '../../core/toast.service';
import { UserResponse, UserRequest } from '../../models/models';

@Component({
  selector: 'app-profile', standalone: true, imports: [CommonModule, FormsModule, TopbarComponent],
  styles: [`
    .shell{display:grid;grid-template-columns:280px 1fr;gap:1.5rem;align-items:start;}
    @media(max-width:900px){.shell{grid-template-columns:1fr;}}
    .avatar-big{width:80px;height:80px;background:#1a4d2e;border:4px solid #f59e0b;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.75rem;font-weight:700;color:#fff;margin:0 auto;}
    .meta-row{display:flex;align-items:center;justify-content:space-between;font-size:.875rem;color:#6b6b6b;padding:.375rem 0;border-bottom:1px solid #f0ede6;}
    .meta-row:last-child{border:none;}
  `],
  template: `
    <app-topbar title="My Profile" subtitle="View and update your account" />
    <div class="page-content">
      <div class="shell">
        <div>
          <div class="card">
            <div class="card-body" style="text-align:center;padding:2rem">
              <div class="avatar-big">{{initials()}}</div>
              <h2 style="font-size:1.25rem;font-weight:700;margin-top:1rem">{{user()?.name}}</h2>
              <p class="text-muted text-sm">{{user()?.email}}</p>
              <span class="badge badge-primary mt-2">{{user()?.role}}</span>
              <div style="margin-top:1.25rem">
                <div class="meta-row"><span>📞 Phone</span><span>{{user()?.phone||'—'}}</span></div>
                <div class="meta-row"><span>🔒 Status</span><span class="badge" [class]="user()?.status==='ACTIVE'?'badge-success':'badge-danger'">{{user()?.status}}</span></div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <div class="card">
            <div class="card-header"><h3>Edit Profile</h3></div>
            <div class="card-body">
              @if (loading()) { <div class="loading"><span class="spinner"></span></div> }
              @else {
                <div class="grid-2">
                  <div class="form-group"><label class="form-label">Full Name</label><input class="form-control" [(ngModel)]="dto.name" /></div>
                  <div class="form-group"><label class="form-label">Phone</label><input class="form-control" [(ngModel)]="dto.phone" /></div>
                </div>
                <div class="form-group mt-3"><label class="form-label">Email</label><input class="form-control" type="email" [(ngModel)]="dto.email" /></div>
                <div class="form-group mt-3">
                  <label class="form-label">New Password <span class="text-muted text-sm">(leave blank to keep current)</span></label>
                  <input class="form-control" type="password" [(ngModel)]="newPw" placeholder="••••••••" />
                </div>
                <div class="flex justify-between items-center mt-4" style="flex-wrap:wrap;gap:.75rem">
                  <button class="btn btn-ghost" (click)="reset()">↩ Reset</button>
                  <button class="btn btn-primary" (click)="save()" [disabled]="saving()">@if(saving()){<span class="spinner"></span>} Save Changes</button>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>`
})
export class ProfileComponent implements OnInit {
  user=signal<UserResponse|null>(null); loading=signal(true); saving=signal(false);
  dto:Partial<UserRequest>={}; newPw=''; private uid:number|null=null;
  initials=computed(()=>{ const n=this.user()?.name; return n?n.split(' ').map((w:string)=>w[0]).join('').substring(0,2).toUpperCase():this.auth.email().substring(0,2).toUpperCase(); });
  constructor(private auth:AuthService, private us:UserService, private toast:ToastService){}
  ngOnInit(){
    const email=this.auth.email();
    this.us.getAll().subscribe({
      next:users=>{
        const me=users.find(u=>u.email===email);
        if(me){this.user.set(me);this.uid=me.userId;this.reset();}
        this.loading.set(false);
      },
      error:()=>this.loading.set(false)
    });
  }
  reset(){ const u=this.user(); if(u)this.dto={name:u.name,email:u.email,phone:u.phone,role:u.role}; this.newPw=''; }
  save(){
    if(!this.uid){this.toast.warn('Cannot resolve user.');return;}
    this.saving.set(true);
    const payload:UserRequest={name:this.dto.name!,email:this.dto.email!,phone:this.dto.phone!,role:this.dto.role!,...(this.newPw?{password:this.newPw}:{})};
    this.us.update(this.uid,payload).subscribe({
      next:u=>{this.user.set(u);this.saving.set(false);this.toast.success('Profile updated.');},
      error:()=>{this.saving.set(false);this.toast.error('Update failed.');}
    });
  }
}
