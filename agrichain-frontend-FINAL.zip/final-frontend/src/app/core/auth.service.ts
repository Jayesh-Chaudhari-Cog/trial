import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { LoginRequest, UserRequest, JwtPayload } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly KEY = 'agrichain_jwt';
  private _token  = signal<string | null>(localStorage.getItem(this.KEY));
  private _payload = computed<JwtPayload | null>(() => this.decode(this._token()));

  readonly isLoggedIn = computed(() => {
    const p = this._payload();
    return !!p && p.exp * 1000 > Date.now();
  });
  readonly role  = computed(() => this._payload()?.role?.replace('ROLE_', '') ?? '');
  readonly email = computed(() => this._payload()?.sub ?? '');

  constructor(private http: HttpClient, private router: Router) {}

  login(dto: LoginRequest): Observable<string> {
    return this.http.post(`${environment.apiUrl}/users/login`, dto, { responseType: 'text' })
      .pipe(tap(token => { localStorage.setItem(this.KEY, token); this._token.set(token); }));
  }

  register(dto: UserRequest): Observable<string> {
    return this.http.post(`${environment.apiUrl}/users/register`, dto, { responseType: 'text' });
  }

  logout(): void {
    localStorage.removeItem(this.KEY);
    this._token.set(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null { return this._token(); }
  hasRole(...roles: string[]): boolean { return roles.includes(this.role()); }

  private decode(token: string | null): JwtPayload | null {
    if (!token) return null;
    try { return JSON.parse(atob(token.split('.')[1])); }
    catch { return null; }
  }
}
