import { Injectable, signal } from '@angular/core';

export type ToastType = 'success'|'danger'|'warn'|'info';
export interface Toast { id: number; msg: string; type: ToastType; }

@Injectable({ providedIn: 'root' })
export class ToastService {
  private n = 0;
  readonly list = signal<Toast[]>([]);

  show(msg: string, type: ToastType = 'info', ms = 3500) {
    const id = ++this.n;
    this.list.update(l => [...l, { id, msg, type }]);
    setTimeout(() => this.remove(id), ms);
  }
  success(m: string) { this.show(m, 'success'); }
  error(m: string)   { this.show(m, 'danger', 5000); }
  warn(m: string)    { this.show(m, 'warn'); }
  info(m: string)    { this.show(m, 'info'); }
  remove(id: number) { this.list.update(l => l.filter(t => t.id !== id)); }
}
