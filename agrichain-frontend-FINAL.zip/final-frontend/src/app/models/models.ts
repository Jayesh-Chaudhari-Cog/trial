export type UserRole = 'FARMER'|'TRADER'|'OFFICER'|'MANAGER'|'ADMIN'|'COMPLIANCE'|'AUDITOR';
export type UserStatus = 'ACTIVE'|'INACTIVE'|'SUSPENDED';
export interface LoginRequest   { email: string; password: string; }
export interface UserRequest    { name: string; email: string; phone: string; password?: string; role: UserRole; status?: UserStatus; }
export interface UserResponse   { userId: number; name: string; email: string; phone: string; role: UserRole; status: UserStatus; }

export type FarmerStatus = 'PENDING'|'APPROVED'|'REJECTED';
export type VerificationStatus = 'UNVERIFIED'|'VERIFIED'|'REJECTED';
export type DocType = 'AADHAR'|'PAN'|'LAND_RECORD'|'BANK_PASSBOOK'|'OTHER';
export interface Farmer         { farmerId?: number; fullName: string; email: string; phone: string; gender?: string; dateOfBirth?: string; address?: string; state?: string; pinCode?: string; landHoldingAcres?: number; status?: FarmerStatus; verificationStatus?: VerificationStatus; }
export interface FarmerDocument { documentId?: number; farmerId: number; docType: DocType; documentUrl: string; verificationStatus?: VerificationStatus; }

export type CropListingStatus = 'PENDING'|'APPROVED'|'REJECTED'|'SOLD';
export type OrderStatus = 'PLACED'|'CONFIRMED'|'SHIPPED'|'DELIVERED'|'CANCELLED';
export interface CropListing    { listingId?: number; farmerId: number; cropName: string; variety?: string; quantityKg: number; pricePerKg: number; harvestDate?: string; availableFrom?: string; location?: string; description?: string; status?: CropListingStatus; }
export interface Order          { orderId?: number; listingId: number; traderId: number; quantityOrdered: number; totalPrice?: number; deliveryAddress?: string; status?: OrderStatus; }

export type DisbursementStatus = 'PENDING'|'APPROVED'|'REJECTED'|'DISBURSED';
export interface SubsidyProgram { programId?: number; title: string; description?: string; allottedBudget: number; disbursedAmount?: number; startDate?: string; endDate?: string; eligibilityCriteria?: string; }
export interface Disbursement   { disbursementId?: number; farmerId: number; programId: number; requestedAmount: number; approvedAmount?: number; status?: DisbursementStatus; remarks?: string; }

export type AuditScope  = 'FINANCIAL'|'OPERATIONAL'|'COMPLIANCE'|'ENVIRONMENTAL';
export type AuditStatus = 'SCHEDULED'|'IN_PROGRESS'|'COMPLETED'|'CANCELLED';
export type ComplianceType   = 'REGULATORY'|'INTERNAL'|'EXTERNAL'|'STATUTORY';
export type ComplianceResult = 'COMPLIANT'|'NON_COMPLIANT'|'PARTIAL'|'PENDING';
export interface Audit      { auditId?: number; title: string; scope: AuditScope; status: AuditStatus; officerId?: number; scheduledDate?: string; completedDate?: string; findings?: string; }
export interface Compliance { complianceId?: number; auditId?: number; complianceType: ComplianceType; result: ComplianceResult; description?: string; dueDate?: string; remarks?: string; }
export interface AuditLog   { logId?: number; performedBy: string; action: string; role: string; details?: string; timestamp?: string; }

export interface Report    { reportId?: number; scope: string; metrics: string; generatedDate?: string; }
export interface ReportDTO { scope: string; metrics: string; }
export interface JwtPayload { sub: string; role: string; exp: number; }
