import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'login',    loadComponent: () => import('./pages/auth/login.component').then(m => m.LoginComponent) },
  { path: 'register', loadComponent: () => import('./pages/auth/register.component').then(m => m.RegisterComponent) },
  {
    path: '',
    loadComponent: () => import('./shared/components/layout.component').then(m => m.LayoutComponent),
    canActivate: [authGuard],
    children: [
      { path: 'dashboard',  loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'users',      loadComponent: () => import('./pages/users/users.component').then(m => m.UsersComponent) },
      { path: 'farmers',    loadComponent: () => import('./pages/farmers/farmers.component').then(m => m.FarmersComponent) },
      { path: 'market',     loadComponent: () => import('./pages/market/market.component').then(m => m.MarketComponent) },
      { path: 'subsidy',    loadComponent: () => import('./pages/subsidy/subsidy.component').then(m => m.SubsidyComponent) },
      { path: 'audit',      loadComponent: () => import('./pages/audit/audit.component').then(m => m.AuditComponent) },
      { path: 'reports',    loadComponent: () => import('./pages/reports/reports.component').then(m => m.ReportsComponent) },
      { path: 'audit-logs', loadComponent: () => import('./pages/audit-logs/audit-logs.component').then(m => m.AuditLogsComponent) },
      { path: 'profile',    loadComponent: () => import('./pages/profile/profile.component').then(m => m.ProfileComponent) },
    ]
  },
  { path: '**', redirectTo: '/dashboard' }
];
