package com.cts.transaction_payment.service;

import com.cts.transaction_payment.client.MarketClient;
import com.cts.transaction_payment.dao.TransactionRepo;
import com.cts.transaction_payment.dto.OrderDTO;
import com.cts.transaction_payment.entity.Transaction;
import com.cts.transaction_payment.enums.TransactionStatus;
import com.cts.transaction_payment.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepo transactionRepo;

    @Autowired
    private MarketClient marketClient;

    /**
     * Retrieves transactions based on their status.
     */
    public List<Transaction> getTransactionsByStatus(TransactionStatus status) {
        try {
            return transactionRepo.findByTransactionStatus(status);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid transaction status: " + status);
        }
    }

    /**
     * Calculates the final amount including a 2% platform fee.
     */
    public Double calculateFinalAmount(Long transactionId) {
        Transaction tx = transactionRepo.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with ID: " + transactionId));
        return tx.getTransactionAmount() * 1.02;
    }

    /**
     * Initiates a new transaction after verifying the Order exists in the Market service.
     *
     * FIX 7: Added guard — if a PENDING transaction already exists for this orderId,
     * return it instead of creating a duplicate. This prevents two Transaction rows
     * for the same Order if the frontend calls /initiate more than once.
     */
    @Transactional
    public Transaction createTransaction(Transaction transaction) {
        // Check if a transaction already exists for this orderId
        List<Transaction> existing = transactionRepo.findByOrderId(transaction.getOrderId());
        if (!existing.isEmpty()) {
            // Return the most recent existing transaction instead of duplicating
            System.out.println(">>> Transaction already exists for order " + transaction.getOrderId() + ". Returning existing.");
            return existing.get(existing.size() - 1);
        }

        // Verify the order exists in the Market Microservice
        Object order = marketClient.getOrderById(transaction.getOrderId());
        if (order == null) {
            throw new ResourceNotFoundException("Order not found with ID: " + transaction.getOrderId());
        }

        transaction.setTransactionStatus(TransactionStatus.PENDING);
        transaction.setTransactionDate(LocalDate.now());

        return transactionRepo.save(transaction);
    }

    /**
     * Finalizes the transaction upon successful payment.
     * Reduces crop inventory and marks Order as COMPLETED in the Market service.
     *
     * FIX 8: Wrapped each remote Feign call individually so a failure in
     * updateOrderStatus does not hide a successful reduceQuantity.
     * Previously the entire catch block re-threw a vague RuntimeException,
     * masking the real cause (e.g. Feign 404, network timeout).
     */
    @Transactional
    public Transaction finalizeTransaction(Long transactionId) {
        Transaction tx = transactionRepo.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with ID: " + transactionId));

        // Idempotent guard — safe to call multiple times
        if (tx.getTransactionStatus() == TransactionStatus.COMPLETED) {
            System.out.println(">>> Transaction " + transactionId + " already COMPLETED. Skipping.");
            return tx;
        }

        // Fetch Order details from Market service
        OrderDTO order = marketClient.getOrderById(tx.getOrderId());
        if (order == null) {
            throw new ResourceNotFoundException("Order not found for transaction " + transactionId);
        }

        System.out.println(">>> STARTING FINALIZATION FOR ORDER: " + order.getOrderId());

        // Step 1: Reduce crop quantity in the Market service
        try {
            System.out.println("DEBUG: Reducing inventory for listing " + order.getListingId());
            marketClient.reduceQuantity(order.getListingId(), order.getQuantity());
        } catch (Exception e) {
            // FIX 8a: Log exact Feign error, don't swallow it
            System.err.println("ERROR: reduceQuantity failed for listing " + order.getListingId() + ": " + e.getMessage());
            throw new RuntimeException("Finalization failed at inventory reduction: " + e.getMessage(), e);
        }

        // Step 2: Update Order status to COMPLETED in the Market service
        try {
            System.out.println("DEBUG: Updating Order " + tx.getOrderId() + " status to COMPLETED");
            marketClient.updateOrderStatus(tx.getOrderId(), "COMPLETED");
        } catch (Exception e) {
            // FIX 8b: Log exact Feign error separately from step 1
            System.err.println("ERROR: updateOrderStatus failed for order " + tx.getOrderId() + ": " + e.getMessage());
            throw new RuntimeException("Finalization failed at order status update: " + e.getMessage(), e);
        }

        // Step 3: Mark local Transaction as COMPLETED
        tx.setTransactionStatus(TransactionStatus.COMPLETED);
        Transaction updatedTx = transactionRepo.save(tx);

        System.out.println(">>> SUCCESS: Transaction " + transactionId + " finalized.");
        return updatedTx;
    }

    /**
     * Cancels a transaction and notifies the Market service.
     *
     * FIX 9: Added guard — do not cancel an already COMPLETED transaction.
     * Previously, a FAILED payment callback could cancel a transaction that
     * had already been finalized by a prior PAID callback.
     */
    @Transactional
    public void cancelTransaction(Long transactionId) {
        Transaction tx = transactionRepo.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with ID: " + transactionId));

        // FIX 9: Guard — never cancel a completed transaction
        if (tx.getTransactionStatus() == TransactionStatus.COMPLETED) {
            System.out.println(">>> Transaction " + transactionId + " is COMPLETED. Cancellation blocked.");
            return;
        }

        if (tx.getTransactionStatus() == TransactionStatus.CANCELLED) {
            System.out.println(">>> Transaction " + transactionId + " is already CANCELLED.");
            return;
        }

        tx.setTransactionStatus(TransactionStatus.CANCELLED);

        try {
            marketClient.updateOrderStatus(tx.getOrderId(), "CANCELLED");
        } catch (Exception e) {
            System.err.println("WARNING: Could not update Order status to CANCELLED in Market service: " + e.getMessage());
            // Still save the local cancellation even if remote call fails
        }

        transactionRepo.save(tx);
        System.out.println(">>> Transaction " + transactionId + " cancelled.");
    }

    /**
     * Filters transactions by status and date range.
     */
    public List<Transaction> getTransactionsByFilter(String status, LocalDate start, LocalDate end) {
        TransactionStatus transactionStatus = TransactionStatus.valueOf(status.toUpperCase());
        if (start.isAfter(end)) {
            throw new IllegalArgumentException("Start date must be before end date");
        }
        return transactionRepo.findByTransactionStatusAndTransactionDateBetween(transactionStatus, start, end);
    }

    /**
     * Updates the status of a specific transaction manually (officer use).
     */
    @Transactional
    public Transaction updateTransactionStatus(Long id, String status) {
        Transaction tx = transactionRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + id));

        try {
            TransactionStatus newStatus = TransactionStatus.valueOf(status.toUpperCase());
            tx.setTransactionStatus(newStatus);
            return transactionRepo.save(tx);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid status: " + status +
                    ". Valid values: PENDING, PROCESSING, COMPLETED, FAILED, CANCELLED, REFUNDED");
        }
    }
}
