package com.cts.transaction_payment.service;

import com.cts.transaction_payment.dao.PaymentRepo;
import com.cts.transaction_payment.dao.TransactionRepo;
import com.cts.transaction_payment.entity.Payment;
import com.cts.transaction_payment.entity.Transaction;
import com.cts.transaction_payment.enums.PaymentStatus;
import com.cts.transaction_payment.enums.TransactionStatus;
import com.cts.transaction_payment.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepo paymentRepo;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private TransactionRepo transactionRepo;

    @Transactional
    public Payment recordPayment(Payment payment) {
        // 1. Fetch the full Transaction entity
        Transaction tx = transactionRepo.findById(payment.getTransaction().getTransactionId())
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));

        // FIX 4: Guard against double-payment.
        // Before the fix, clicking "Buy Now" twice on the same listing caused:
        //   - placeOrder() → new Order
        //   - initiateTransaction() → new Transaction (PENDING)
        //   - recordPayment() → second Payment row against same transaction_id
        //   → DataIntegrityViolationException (UNIQUE constraint from @OneToOne)
        // Now with @ManyToOne the constraint is gone, but we still block illogical re-payments.
        boolean alreadyPaid = paymentRepo.findByTransaction(tx)
                .stream()
                .anyMatch(p -> p.getPaymentStatus() == PaymentStatus.PAID);

        if (alreadyPaid) {
            throw new RuntimeException(
                "Transaction " + tx.getTransactionId() + " has already been paid successfully."
            );
        }

        // FIX 5: Guard against paying a transaction that is already COMPLETED or CANCELLED.
        if (tx.getTransactionStatus() == TransactionStatus.COMPLETED) {
            throw new RuntimeException(
                "Transaction " + tx.getTransactionId() + " is already completed."
            );
        }
        if (tx.getTransactionStatus() == TransactionStatus.CANCELLED) {
            throw new RuntimeException(
                "Transaction " + tx.getTransactionId() + " has been cancelled and cannot be paid."
            );
        }

        // 2. Set payment fields
        payment.setTransaction(tx);
        payment.setPaymentDate(LocalDate.now());
        payment.setPaymentStatus(PaymentStatus.PAID);

        // 3. Save the payment first
        Payment savedPayment = paymentRepo.save(payment);

        // 4. Trigger finalization (reduces crop quantity + marks Order COMPLETED)
        System.out.println(">>> Payment recorded. Triggering finalization for TX: " + tx.getTransactionId());
        transactionService.finalizeTransaction(tx.getTransactionId());

        return savedPayment;
    }

    @Transactional
    public Payment processPaymentCallback(Long paymentId, PaymentStatus newStatus) {
        Payment payment = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment record not found with ID: " + paymentId));

        // FIX 6: Guard against re-processing an already PAID payment via callback.
        if (payment.getPaymentStatus() == PaymentStatus.PAID && newStatus == PaymentStatus.PAID) {
            return payment; // Idempotent — just return current state, no duplicate finalization
        }

        payment.setPaymentStatus(newStatus);

        if (newStatus == PaymentStatus.PAID) {
            transactionService.finalizeTransaction(payment.getTransaction().getTransactionId());
        } else if (newStatus == PaymentStatus.FAILED) {
            transactionService.cancelTransaction(payment.getTransaction().getTransactionId());
        }

        return paymentRepo.save(payment);
    }

    public String generatePaymentReference(int transactionId) {
        return "AGRI-" + System.currentTimeMillis() + "-" + transactionId;
    }

    public boolean verifyWithGateway(String gatewayId) {
        return gatewayId != null && !gatewayId.isEmpty();
    }

    public List<Payment> getPaymentsByStatus(String status) {
        return paymentRepo.findByPaymentStatus(PaymentStatus.valueOf(status.toUpperCase()));
    }
}
