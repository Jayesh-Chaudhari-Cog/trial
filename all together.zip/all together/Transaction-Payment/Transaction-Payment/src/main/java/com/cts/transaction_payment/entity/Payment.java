package com.cts.transaction_payment.entity;

import com.cts.transaction_payment.enums.PaymentStatus;
import com.cts.transaction_payment.enums.PaymentType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payment_seq")
    @SequenceGenerator(name = "payment_seq", sequenceName = "payment_sequence", allocationSize = 1)
    private Long paymentId;

    // FIX 1: Changed @OneToOne → @ManyToOne
    // @OneToOne puts a UNIQUE constraint on transaction_id in the DB, which means
    // only one payment row can ever reference a given transaction.
    // @ManyToOne allows multiple payment attempts against one transaction (retries, etc.)
    // and removes the constraint that caused: DataIntegrityViolationException
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false)
    private Transaction transaction;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PaymentType method;

    @Column(nullable = false)
    private LocalDate paymentDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private PaymentStatus paymentStatus;
}
