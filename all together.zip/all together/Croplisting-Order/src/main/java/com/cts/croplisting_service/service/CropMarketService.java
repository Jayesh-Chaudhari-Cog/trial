package com.cts.croplisting_service.service;

import com.cts.croplisting_service.client.FarmerClient;
import com.cts.croplisting_service.dao.CropListingRepo;
import com.cts.croplisting_service.dao.OrderRepo;
import com.cts.croplisting_service.dto.CropListingDTO;
import com.cts.croplisting_service.dto.FarmerDTO;
import com.cts.croplisting_service.dto.OrderDTO;
import com.cts.croplisting_service.entity.CropListing;
import com.cts.croplisting_service.entity.Order;
import com.cts.croplisting_service.enums.CropListingStatus;
import com.cts.croplisting_service.enums.OrderStatus;
import com.cts.croplisting_service.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CropMarketService {

    @Autowired
    private CropListingRepo cropListingRepo;

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private FarmerClient farmerClient; // For Microservice Communication

    // 1. Create a new crop listing
    public CropListingDTO createListing(CropListingDTO dto) {
        // Validation: Ensure Farmer exists in the Farmer Microservice
        try {
            farmerClient.getFarmerDetails(dto.getFarmerId());
        } catch (Exception e) {
            // PRINT THE ERROR TO YOUR CONSOLE
            System.err.println("Feign Call Failed! Reason: " + e.getMessage());
            e.printStackTrace();

            throw new ResourceNotFoundException("Farmer with ID " + dto.getFarmerId() + " not found in Farmer Service");
        }

        CropListing listing = new CropListing();
        listing.setFarmerId(dto.getFarmerId());
        listing.setCropType(dto.getCropType());
        listing.setQuantity(dto.getQuantity());
        listing.setPrice(dto.getPrice());
        listing.setLocation(dto.getLocation());
        listing.setStatus(CropListingStatus.PENDING);

        CropListing saved = cropListingRepo.save(listing);
        return toListingDTO(saved);
    }

    // 2. Validate a crop listing (Officer Action)
    public CropListingDTO validateListing(Long listingId) {
        CropListing listing = cropListingRepo.findById(listingId)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with ID: " + listingId));
        listing.setStatus(CropListingStatus.VALIDATED);
        return toListingDTO(cropListingRepo.save(listing));
    }

    // 3. Place a new order
    public OrderDTO placeOrder(OrderDTO dto) {
        CropListing listing = cropListingRepo.findById(dto.getListingId())
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found"));

        if (listing.getQuantity() < dto.getQuantity()) {
            throw new RuntimeException("Not enough stock available for this listing");
        }

        // Logic for Inventory deduction can be added here or in Transaction Service

        Order order = new Order();
        order.setCropListing(listing);
        order.setTraderId(dto.getTraderId());
        order.setQuantity(dto.getQuantity());
        order.setOrderDate(dto.getOrderDate());
        order.setOrderStatus(OrderStatus.PENDING);

        Order saved = orderRepo.save(order);
        return toOrderDTO(saved);
    }

    public OrderDTO getOrderById(Long id) {
        Order order = orderRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
        return toOrderDTO(order);
    }

    // 4. Update order status
    @Transactional
    public OrderDTO updateOrderStatus(Long orderId, String status) {
        System.out.println(">>> RECEIVED REQUEST TO UPDATE STATUS FOR ORDER: " + orderId);

        // Perform update via query to avoid "dirty" entity overwrite
        int updated = orderRepo.updateStatusOnly(orderId, OrderStatus.valueOf(status.toUpperCase()));

        if (updated == 0) throw new ResourceNotFoundException("Order not found");

        // Return the updated DTO
        Order order = orderRepo.findById(orderId).get();
        return toOrderDTO(order);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void reduceQuantity(Long listingId, int quantityToReduce) {
        System.out.println(">>> ATTEMPTING ATOMIC REDUCTION for Listing: " + listingId);

        int rowsUpdated = cropListingRepo.decrementQuantity(listingId, quantityToReduce);

        if (rowsUpdated == 0) {
            throw new RuntimeException("Failed to reduce quantity. Either listing not found or insufficient stock.");
        }

        System.out.println(">>> ATOMIC REDUCTION SUCCESSFUL");
    }

    // --- Query Methods ---

    public List<CropListingDTO> getListingsByStatus(CropListingStatus status) {
        return cropListingRepo.findByStatus(status)
                .stream().map(this::toListingDTO).collect(Collectors.toList());
    }

    public List<OrderDTO> getOrdersByTrader(Long traderId) {
        return orderRepo.findByTraderId(traderId)
                .stream().map(this::toOrderDTO).collect(Collectors.toList());
    }

    public List<CropListingDTO> getAllListings() {
        return cropListingRepo.findAll()
                .stream().map(this::toListingDTO).collect(Collectors.toList());
    }

    public List<OrderDTO> getAllOrders() {
        return orderRepo.findAll()
                .stream().map(this::toOrderDTO).collect(Collectors.toList());
    }

    // --- Mapping Helpers (Corrected for Microservice Logic) ---

    private CropListingDTO toListingDTO(CropListing listing) {
        CropListingDTO dto = new CropListingDTO();
        dto.setListingId(listing.getListingId());
        dto.setFarmerId(listing.getFarmerId()); // Using ID directly
        dto.setCropType(listing.getCropType());
        dto.setQuantity(listing.getQuantity());
        dto.setPrice(listing.getPrice());
        dto.setLocation(listing.getLocation());
        dto.setStatus(listing.getStatus().name());
        return dto;
    }

    private OrderDTO toOrderDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setOrderId(order.getOrderId());
        dto.setListingId(order.getCropListing().getListingId());
        dto.setTraderId(order.getTraderId());
        dto.setQuantity(order.getQuantity());
        dto.setOrderDate(order.getOrderDate());
        dto.setOrderStatus(order.getOrderStatus().name());
        return dto;
    }
}