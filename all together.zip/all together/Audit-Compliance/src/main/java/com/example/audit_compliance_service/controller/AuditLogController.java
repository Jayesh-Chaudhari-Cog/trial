package com.example.audit_compliance_service.controller;

import com.example.audit_compliance_service.entity.AuditLog;
import com.example.audit_compliance_service.service.AuditLogService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auditlogs")
public class AuditLogController {

    private final AuditLogService auditLogService;

    public AuditLogController(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    // ✅ Log an action (performedBy comes from request or JWT claim)
    @PostMapping
    public AuditLog logAction(
            @RequestParam String performedBy,
            @RequestParam String action,
            @RequestParam String resource
    ) {
        return auditLogService.logAction(performedBy, action, resource);
    }

    // ✅ Get all logs
    @GetMapping("/all")
    public List<AuditLog> getAllLogs() {
        return auditLogService.getAllLogs();
    }

    // ✅ Get logs by actor
    @GetMapping("/by-user")
    public List<AuditLog> getLogsByUser(@RequestParam String performedBy) {
        return auditLogService.getLogsByUser(performedBy);
    }

    // ✅ Get logs by action
    @GetMapping("/by-action")
    public List<AuditLog> getLogsByAction(@RequestParam String action) {
        return auditLogService.getLogsByAction(action);
    }

    // ✅ Get logs by resource
    @GetMapping("/by-resource")
    public List<AuditLog> getLogsByResource(@RequestParam String resource) {
        return auditLogService.getLogsByResource(resource);
    }
}
