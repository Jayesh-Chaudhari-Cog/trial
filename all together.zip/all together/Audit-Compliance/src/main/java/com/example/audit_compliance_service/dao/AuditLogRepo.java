package com.example.audit_compliance_service.dao;

import com.example.audit_compliance_service.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditLogRepo extends JpaRepository<AuditLog, Long> {

    // Find logs by user identifier (assuming you store performedBy or userId in the entity)
    List<AuditLog> findByPerformedBy(String performedBy);

    // Find logs by action
    List<AuditLog> findByAction(String action);

    // Find logs by resource
    List<AuditLog> findByResource(String resource);
}
