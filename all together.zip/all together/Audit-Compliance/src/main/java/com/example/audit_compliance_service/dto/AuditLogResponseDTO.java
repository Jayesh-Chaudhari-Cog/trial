package com.cts.agrichain.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuditLogResponseDTO {

    private Long auditId;       // Unique ID of the audit log
    private String action;      // Action performed (CREATE, UPDATE, DELETE, etc.)
    private String resource;    // Resource/entity affected
    private LocalDateTime timestamp; // When the action occurred
    private String performedBy; // Username or identifier of the actor
}
