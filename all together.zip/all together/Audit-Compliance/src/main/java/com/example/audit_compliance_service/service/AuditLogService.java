package com.example.audit_compliance_service.service;

import com.example.audit_compliance_service.dao.AuditLogRepo;
import com.example.audit_compliance_service.entity.AuditLog;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditLogService {

    private final AuditLogRepo auditLogRepo;

    public AuditLogService(AuditLogRepo auditLogRepo) {
        this.auditLogRepo = auditLogRepo;
    }

    // ✅ Log an action (performedBy comes from request or JWT claims)
    public AuditLog logAction(String performedBy, String action, String resource) {
        AuditLog log = AuditLog.builder()
                .performedBy(performedBy)
                .action(action)
                .resource(resource)
                .timestamp(LocalDateTime.now())
                .build();
        return auditLogRepo.save(log);
    }

    // ✅ Get all logs
    public List<AuditLog> getAllLogs() {
        return auditLogRepo.findAll();
    }

    // ✅ Get logs by actor
    public List<AuditLog> getLogsByUser(String performedBy) {
        return auditLogRepo.findByPerformedBy(performedBy);
    }

    // ✅ Get logs by action
    public List<AuditLog> getLogsByAction(String action) {
        return auditLogRepo.findByAction(action);
    }

    // ✅ Get logs by resource
    public List<AuditLog> getLogsByResource(String resource) {
        return auditLogRepo.findByResource(resource);
    }
}
