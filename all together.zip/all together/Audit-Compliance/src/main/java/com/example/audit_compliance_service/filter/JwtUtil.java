//package com.example.audit_compliance_service.filter;
//
//import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.Jwts;
//import io.jsonwebtoken.SignatureAlgorithm;
//import io.jsonwebtoken.io.Decoders;
//import io.jsonwebtoken.security.Keys;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Service;
//
//import java.security.Key;
//import java.util.Date;
//import java.util.List;
//
//@Component
//public class JwtUtil {
//
//    // This must match the signing key used by your central Auth service
//    private final String secretKey = "your_secret_key_here";
//
//    // Extract username (subject) from token
//    public String extractUsername(String token) {
//        return extractClaims(token).getSubject();
//    }
//
//    // Extract roles from token claims
//    public List<String> extractRoles(String token) {
//        return extractClaims(token).get("roles", List.class);
//    }
//
//    // Validate token (check expiration)
//    public boolean validateToken(String token) {
//        return !isTokenExpired(token);
//    }
//
//    private boolean isTokenExpired(String token) {
//        return extractClaims(token).getExpiration().before(new Date());
//    }
//    private Key getSignInKey() {
//        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
//        return Keys.hmacShaKeyFor(keyBytes);
//    }
//
//    private Claims extractClaims(String token) {
//        return Jwts.parser() // Changed from parserBuilder()
//                .verifyWith((javax.crypto.SecretKey) getSignInKey()) // Use verifyWith for modern versions
//                .build()
//                .parseSignedClaims(token) // Changed from parseClaimsJws
//                .getPayload(); // Changed from getBody
//    }
//}
