package com.example.audit_compliance_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // What action was performed (e.g. CREATE, UPDATE, DELETE)
    private String action;

    // Which resource/entity was affected
    private String resource;

    // When the action happened
    private LocalDateTime timestamp;

    // Who performed the action (username or userId)
    private String performedBy;
}
