import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { subsidyAPI } from '../services/api';

export default function SubsidyProgramsPage() {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [form, setForm] = useState({
    title: '', description: '', allottedBudget: '', subsidyStatus: 'ACTIVE',
    startDate: '', endDate: '', eligibilityCriteria: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await subsidyAPI.getAllPrograms();
      setPrograms(Array.isArray(res.data) ? res.data : []);
    } catch { setPrograms([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditItem(null);
    setForm({ title: '', description: '', allottedBudget: '', subsidyStatus: 'ACTIVE', startDate: '', endDate: '', eligibilityCriteria: '' });
    setModal(true);
    setError('');
  };

  const openEdit = (p) => {
    setEditItem(p);
    setForm({
      title: p.title || '',
      description: p.description || '',
      allottedBudget: p.allottedBudget || '',
      subsidyStatus: p.subsidyStatus || 'ACTIVE',
      startDate: p.startDate || '',
      endDate: p.endDate || '',
      eligibilityCriteria: p.eligibilityCriteria || '',
    });
    setModal(true);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const payload = { ...form, allottedBudget: Number(form.allottedBudget) };
      if (editItem) {
        await subsidyAPI.updateProgram(editItem.subsidyId || editItem.id, payload);
        setSuccess('Program updated!');
      } else {
        await subsidyAPI.createProgram(payload);
        setSuccess('Subsidy program created!');
      }
      setModal(false);
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed');
    }
    setSubmitting(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this subsidy program?')) return;
    try {
      await subsidyAPI.deleteProgram(id);
      setSuccess('Program deleted');
      load();
    } catch { setError('Failed to delete'); }
  };

  const statusColor = (s) => {
    const map = { ACTIVE: 'badge-green', INACTIVE: 'badge-gray', EXPIRED: 'badge-red', PENDING: 'badge-yellow' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Subsidy Programs" subtitle="Government subsidy program management">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Subsidy Programs</div>
            <div className="page-subtitle">{programs.length} programs available</div>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>+ Create Program</button>
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : programs.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🏦</div>
            <h3>No subsidy programs</h3>
            <p>Create the first government subsidy program</p>
          </div>
        ) : (
          <div className="grid-3">
            {programs.map(p => (
              <div key={p.subsidyId || p.id} className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div style={{ fontSize: 28 }}>🏦</div>
                  <span className={`badge ${statusColor(p.subsidyStatus)}`}>{p.subsidyStatus}</span>
                </div>
                <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>{p.title}</div>
                <div style={{ fontSize: 13, color: 'var(--text3)', marginBottom: 12, minHeight: 40 }}>{p.description || '—'}</div>
                <div style={{ background: 'var(--bg3)', borderRadius: 8, padding: 12, marginBottom: 12 }}>
                  <div style={{ fontSize: 11, color: 'var(--text3)', fontFamily: 'var(--mono)' }}>BUDGET</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--accent)', fontFamily: 'var(--mono)' }}>
                    ₹{(p.allottedBudget || 0).toLocaleString()}
                  </div>
                </div>
                {p.eligibilityCriteria && (
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 12 }}>
                    <span style={{ fontWeight: 600 }}>Eligibility:</span> {p.eligibilityCriteria}
                  </div>
                )}
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-outline btn-sm" onClick={() => openEdit(p)} style={{ flex: 1 }}>✏ Edit</button>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p.subsidyId || p.id)}>🗑</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <span className="modal-title">{editItem ? 'Edit Program' : 'Create Subsidy Program'}</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Program Title</label>
                <input className="form-input" placeholder="e.g. Kisan Credit Card Scheme" value={form.title}
                  onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea className="form-textarea" placeholder="Program details..." value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Budget (₹)</label>
                  <input className="form-input" type="number" placeholder="500000" value={form.allottedBudget}
                    onChange={e => setForm(f => ({ ...f, allottedBudget: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={form.subsidyStatus}
                    onChange={e => setForm(f => ({ ...f, subsidyStatus: e.target.value }))}>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                    <option value="PENDING">Pending</option>
                    <option value="EXPIRED">Expired</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Start Date</label>
                  <input className="form-input" type="date" value={form.startDate}
                    onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} />
                </div>
                <div className="form-group">
                  <label className="form-label">End Date</label>
                  <input className="form-input" type="date" value={form.endDate}
                    onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Eligibility Criteria</label>
                <input className="form-input" placeholder="e.g. Small farmers with < 2 hectares" value={form.eligibilityCriteria}
                  onChange={e => setForm(f => ({ ...f, eligibilityCriteria: e.target.value }))} />
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving...' : editItem ? 'Update Program' : 'Create Program'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
