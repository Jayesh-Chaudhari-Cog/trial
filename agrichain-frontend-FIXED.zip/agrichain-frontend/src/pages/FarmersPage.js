import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { farmersAPI } from '../services/api';

export default function FarmersPage() {
  const [farmers, setFarmers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  // Backend Farmer entity expects: users.id (userId), name, email, contactInfo, address, landDetails, gender (enum), status
  const [form, setForm] = useState({
    userId: '',         // users.id - required to link to a User account
    name: '',
    email: '',
    contactInfo: '',    // was 'phone' in frontend
    address: '',
    landDetails: '',    // was 'landArea' in frontend
    gender: 'MALE',
    status: 'ACTIVE',
  });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await farmersAPI.getAll();
      setFarmers(Array.isArray(res.data) ? res.data : []);
    } catch { setFarmers([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      // Backend FarmerController accepts raw Farmer entity with nested users.id
      // FarmerService validates that the userId exists via UserClient
      const payload = {
        name: form.name,
        email: form.email,
        contactInfo: form.contactInfo,
        address: form.address,
        landDetails: form.landDetails,
        gender: form.gender,
        status: form.status,
        users: { id: Number(form.userId) },  // required: link to existing user
        documents: [],  // FarmerService requires ID_PROOF + LAND_RECORD docs to register
      };
      await farmersAPI.register(payload);
      setSuccess('Farmer registered!');
      setModal(false);
      setForm({ userId: '', name: '', email: '', contactInfo: '', address: '', landDetails: '', gender: 'MALE', status: 'ACTIVE' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed. Make sure User ID exists and documents include ID_PROOF + LAND_RECORD.');
    }
    setSubmitting(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this farmer?')) return;
    try {
      await farmersAPI.delete(id);
      setSuccess('Farmer deleted');
      load();
    } catch { setError('Failed to delete'); }
  };

  const statusColor = (s) => {
    const map = { ACTIVE: 'badge-green', VERIFIED: 'badge-green', PENDING_VERIFICATION: 'badge-yellow', INACTIVE: 'badge-gray', REJECTED: 'badge-red', SUSPENDED: 'badge-gray' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Farmers" subtitle="Registered farmer profiles">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Farmer Management</div>
            <div className="page-subtitle">{farmers.length} registered farmers</div>
          </div>
          <button className="btn btn-primary" onClick={() => { setModal(true); setError(''); }}>+ Register Farmer</button>
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : farmers.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🧑‍🌾</div>
            <h3>No farmers registered</h3>
            <p>Register the first farmer to start</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Land Details</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {farmers.map(f => (
                  <tr key={f.farmerId || f.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{f.farmerId || f.id}</td>
                    <td style={{ fontWeight: 600, color: 'var(--text)' }}>{f.name || '—'}</td>
                    <td>{f.email || '—'}</td>
                    <td>{f.contactInfo || f.phone || '—'}</td>
                    <td>{f.landDetails || f.landArea || '—'}</td>
                    <td><span className={`badge ${statusColor(f.status || f.farmerStatus)}`}>{f.status || f.farmerStatus || 'ACTIVE'}</span></td>
                    <td>
                      <button className="btn btn-danger btn-sm" onClick={() => handleDelete(f.farmerId || f.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <span className="modal-title">Register Farmer</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <div className="alert" style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px', fontSize: 12, color: 'var(--text3)', marginBottom: 4 }}>
              ℹ Farmer must already be registered as a User. The User ID links this farmer to an account.
            </div>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">User Account ID (required)</label>
                <input className="form-input" type="number" placeholder="Existing User ID to link" value={form.userId}
                  onChange={e => setForm(f => ({ ...f, userId: e.target.value }))} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Name</label>
                  <input className="form-input" placeholder="Full name" value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <input className="form-input" type="email" placeholder="farmer@example.com" value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Contact Info</label>
                  <input className="form-input" placeholder="+91..." value={form.contactInfo}
                    onChange={e => setForm(f => ({ ...f, contactInfo: e.target.value }))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Land Details</label>
                  <input className="form-input" placeholder="e.g. 5 acres, Village X" value={form.landDetails}
                    onChange={e => setForm(f => ({ ...f, landDetails: e.target.value }))} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Address</label>
                <input className="form-input" placeholder="Village, District, State" value={form.address}
                  onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Gender</label>
                  <select className="form-select" value={form.gender}
                    onChange={e => setForm(f => ({ ...f, gender: e.target.value }))}>
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={form.status}
                    onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Registering...' : 'Register Farmer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
