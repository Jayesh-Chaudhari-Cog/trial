import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { transactionAPI } from '../services/api';

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [txModal, setTxModal] = useState(false);
  const [payModal, setPayModal] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [filter, setFilter] = useState('PENDING');
  const [txForm, setTxForm] = useState({ orderId: '', amount: '' });
  const [payForm, setPayForm] = useState({ method: 'UPI' });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await transactionAPI.getByStatus(filter);
      setTransactions(Array.isArray(res.data) ? res.data : []);
    } catch { setTransactions([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, [filter]);

  const handleInitiate = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await transactionAPI.initiateTransaction({ orderId: Number(txForm.orderId), amount: Number(txForm.amount) });
      setSuccess('Transaction initiated!');
      setTxModal(false);
      setTxForm({ orderId: '', amount: '' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to initiate');
    }
    setSubmitting(false);
  };

  const handleRecordPayment = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await transactionAPI.recordPayment({ transactionId: payModal, method: payForm.method });
      setSuccess('Payment recorded!');
      setPayModal(null);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to record payment');
    }
    setSubmitting(false);
  };

  const handleFinalize = async (id) => {
    try {
      await transactionAPI.finalizeTransaction(id);
      setSuccess('Transaction finalized!');
      load();
    } catch (err) {
      setError('Failed to finalize');
    }
  };

  const statusColor = (s) => {
    const map = { COMPLETED: 'badge-green', PENDING: 'badge-yellow', FAILED: 'badge-red', PROCESSING: 'badge-blue', CANCELLED: 'badge-gray' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Transactions" subtitle="Payment & transaction management">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Transactions & Payments</div>
            <div className="page-subtitle">{transactions.length} {filter.toLowerCase()} transactions</div>
          </div>
          <button className="btn btn-primary" onClick={() => setTxModal(true)}>+ Initiate Transaction</button>
        </div>

        {/* Status Filter */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED'].map(s => (
            <button key={s} className={`btn btn-sm ${filter === s ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setFilter(s)}>{s}</button>
          ))}
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : transactions.length === 0 ? (
          <div className="empty-state">
            <div className="icon">💸</div>
            <h3>No {filter.toLowerCase()} transactions</h3>
            <p>Initiate a transaction from a placed order</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>TXN ID</th><th>Order ID</th><th>Amount</th><th>Date</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map(t => (
                  <tr key={t.transactionId || t.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{t.transactionId || t.id}</td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{t.orderId}</td>
                    <td style={{ color: 'var(--accent)', fontFamily: 'var(--mono)', fontWeight: 700 }}>
                      ₹{t.transactionAmount || t.amount}
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text3)' }}>{t.transactionDate || '—'}</td>
                    <td><span className={`badge ${statusColor(t.transactionStatus || t.status)}`}>{t.transactionStatus || t.status}</span></td>
                    <td>
                      <div className="flex gap-2">
                        {(t.transactionStatus === 'PENDING' || t.status === 'PENDING') && (
                          <button className="btn btn-outline btn-sm" onClick={() => setPayModal(t.transactionId || t.id)}>
                            💳 Pay
                          </button>
                        )}
                        {(t.transactionStatus === 'PROCESSING' || t.status === 'PROCESSING') && (
                          <button className="btn btn-outline btn-sm" onClick={() => handleFinalize(t.transactionId || t.id)}>
                            ✓ Finalize
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Initiate Transaction Modal */}
      {txModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setTxModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Initiate Transaction</span>
              <button className="modal-close" onClick={() => setTxModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleInitiate} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Order ID</label>
                <input className="form-input" type="number" placeholder="Order ID to pay for" value={txForm.orderId}
                  onChange={e => setTxForm(f => ({ ...f, orderId: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Amount (₹)</label>
                <input className="form-input" type="number" step="0.01" placeholder="1500.00" value={txForm.amount}
                  onChange={e => setTxForm(f => ({ ...f, amount: e.target.value }))} required />
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setTxModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Initiating...' : 'Initiate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {payModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setPayModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Record Payment — TXN #{payModal}</span>
              <button className="modal-close" onClick={() => setPayModal(null)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleRecordPayment} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Payment Method</label>
                <select className="form-select" value={payForm.method}
                  onChange={e => setPayForm(f => ({ ...f, method: e.target.value }))}>
                  <option value="UPI">UPI</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="CASH">Cash</option>
                  <option value="CHEQUE">Cheque</option>
                  <option value="CARD">Card</option>
                </select>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setPayModal(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Recording...' : 'Record Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
