import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { authAPI } from '../services/api';

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  // Backend UserRequestDTO: name, email, password, phone (10 digits), role (UserRole enum)
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', role: 'FARMER' });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await authAPI.getAllUsers();
      setUsers(Array.isArray(res.data) ? res.data : []);
    } catch { setUsers([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!/^[0-9]{10}$/.test(form.phone)) {
      setError('Phone must be exactly 10 digits');
      return;
    }
    if (!/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!]).{6,}$/.test(form.password)) {
      setError('Password must be 6+ chars with uppercase, lowercase, number & symbol (@#$%^&+=!)');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      // Send `role` (not `userRole`) to match UserRequestDTO
      await authAPI.register(form);
      setSuccess('User registered successfully!');
      setModal(false);
      setForm({ name: '', email: '', password: '', phone: '', role: 'FARMER' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to register user');
    }
    setSubmitting(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deactivate this user?')) return;
    try {
      await authAPI.deleteUser(id);
      setSuccess('User deactivated');
      load();
    } catch (err) {
      setError(err.response?.data || 'Failed to deactivate');
    }
  };

  const roleColor = (role) => {
    const map = { ADMIN: 'badge-red', MANAGER: 'badge-yellow', FARMER: 'badge-green', TRADER: 'badge-blue', OFFICER: 'badge-blue', AUDITOR: 'badge-gray' };
    return map[role] || 'badge-gray';
  };

  return (
    <Layout title="Users" subtitle="Registered platform users & roles">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">User Management</div>
            <div className="page-subtitle">Total: {users.length} registered users</div>
          </div>
          <button className="btn btn-primary" onClick={() => { setModal(true); setError(''); }}>+ Add User</button>
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : users.length === 0 ? (
          <div className="empty-state">
            <div className="icon">👤</div>
            <h3>No users found</h3>
            <p>Register the first user to get started</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id || u.userId}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{u.id || u.userId}</td>
                    <td style={{ fontWeight: 600, color: 'var(--text)' }}>{u.name || '—'}</td>
                    <td>{u.email}</td>
                    <td><span className={`badge ${roleColor(u.role || u.userRole)}`}>{u.role || u.userRole}</span></td>
                    <td>
                      <span className={`badge ${(u.status === 'ACTIVE' || u.userStatus === 'ACTIVE') ? 'badge-green' : 'badge-gray'}`}>
                        {u.status || u.userStatus || 'ACTIVE'}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-danger btn-sm" onClick={() => handleDelete(u.id || u.userId)}>Deactivate</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Register New User</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Full Name</label>
                  <input className="form-input" placeholder="Full name (letters only)" value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Phone (10 digits)</label>
                  <input className="form-input" placeholder="9876543210" maxLength={10} value={form.phone}
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value.replace(/\D/g, '') }))} required />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input className="form-input" type="email" placeholder="email@example.com" value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Password</label>
                <input className="form-input" type="password" placeholder="Aa1@xxxx" value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>
                  Must have uppercase, lowercase, number &amp; symbol (e.g. Admin@123)
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Role</label>
                <select className="form-select" value={form.role}
                  onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                  {['FARMER', 'TRADER', 'OFFICER', 'ADMIN', 'AUDITOR', 'MANAGER'].map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Registering...' : 'Register User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
