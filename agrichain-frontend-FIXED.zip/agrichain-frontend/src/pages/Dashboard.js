import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { marketAPI, transactionAPI, subsidyAPI, auditAPI } from '../services/api';

const services = [
  { name: 'Eureka Server', port: 8761, path: '/eureka' },
  { name: 'API Gateway', port: 8090, path: '/' },
  { name: 'Registration', port: 8091, path: '/users' },
  { name: 'Crop Listing', port: 8081, path: '/market' },
  { name: 'Transaction', port: 8093, path: '/transactions' },
  { name: 'Subsidy', port: 9091, path: '/subsidy-programs' },
  { name: 'Audit', port: 8094, path: '/api/audits' },
  { name: 'Report', port: 8095, path: '/api/report' },
];

export default function Dashboard() {
  const [stats, setStats] = useState({ listings: 0, orders: 0, subsidies: 0, audits: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      const results = await Promise.allSettled([
        marketAPI.getAllListings(),
        marketAPI.getAllOrders(),
        subsidyAPI.getAllPrograms(),
        auditAPI.getAllAudits(),
      ]);

      setStats({
        listings: results[0].status === 'fulfilled' ? (results[0].value.data?.length || 0) : 0,
        orders: results[1].status === 'fulfilled' ? (results[1].value.data?.length || 0) : 0,
        subsidies: results[2].status === 'fulfilled' ? (results[2].value.data?.length || 0) : 0,
        audits: results[3].status === 'fulfilled' ? (results[3].value.data?.length || 0) : 0,
      });
      setLoading(false);
    };
    loadStats();
  }, []);

  return (
    <Layout title="Dashboard" subtitle="Platform overview & real-time metrics">
      <div className="fade-in">
        {/* Stats */}
        <div className="grid-4 mb-6">
          {[
            { label: 'Crop Listings', value: stats.listings, icon: '🌽', change: 'Active market items' },
            { label: 'Orders', value: stats.orders, icon: '📦', change: 'Total placed orders' },
            { label: 'Subsidy Programs', value: stats.subsidies, icon: '🏦', change: 'Available programs' },
            { label: 'Audits', value: stats.audits, icon: '🔍', change: 'Compliance records' },
          ].map(s => (
            <div key={s.label} className="stat-card">
              <span className="stat-icon">{s.icon}</span>
              <span className="stat-label">{s.label}</span>
              <span className="stat-value">{loading ? '—' : s.value}</span>
              <span className="stat-change">{s.change}</span>
            </div>
          ))}
        </div>

        <div className="grid-2">
          {/* Service Architecture */}
          <div className="card">
            <div className="section-title">🏗 Microservice Architecture</div>
            <div className="health-grid">
              {services.map(svc => (
                <div key={svc.port} className="health-item">
                  <div>
                    <div className="health-service">{svc.name}</div>
                    <div className="health-port">:{svc.port}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="status-dot status-dot-green"></span>
                    <span style={{ fontSize: 11, color: 'var(--accent)', fontFamily: 'var(--mono)' }}>RUNNING</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="card">
            <div className="section-title">⚡ Quick Actions</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { label: '+ New Crop Listing', path: '/market/listings', icon: '🌽', color: 'btn-primary' },
                { label: '+ Place Order', path: '/market/orders', icon: '📦', color: 'btn-outline' },
                { label: '+ Initiate Transaction', path: '/transactions', icon: '💸', color: 'btn-outline' },
                { label: '+ Create Subsidy Program', path: '/subsidy/programs', icon: '🏦', color: 'btn-outline' },
                { label: '+ Create Audit', path: '/audits', icon: '🔍', color: 'btn-outline' },
                { label: '+ Generate Report', path: '/reports', icon: '📊', color: 'btn-outline' },
              ].map(action => (
                <a key={action.label} href={action.path} className={`btn ${action.color}`} style={{ justifyContent: 'flex-start' }}>
                  <span>{action.icon}</span> {action.label}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* System Info */}
        <div className="card mt-6">
          <div className="section-title">📡 System Configuration</div>
          <div className="grid-3" style={{ marginTop: 16 }}>
            {[
              { key: 'Gateway URL', val: 'http://localhost:8090' },
              { key: 'Eureka Dashboard', val: 'http://localhost:8761' },
              { key: 'JWT Secret', val: 'BYDBCQAg*** (shared)' },
              { key: 'Auth Method', val: 'Bearer JWT Token' },
              { key: 'Service Mesh', val: 'Spring Cloud Netflix Eureka' },
              { key: 'Database', val: 'MySQL (localhost:3306)' },
            ].map(item => (
              <div key={item.key} style={{ padding: '12px 16px', background: 'var(--bg3)', borderRadius: 8, border: '1px solid var(--border)' }}>
                <div style={{ fontSize: 11, color: 'var(--text3)', fontFamily: 'var(--mono)', marginBottom: 4 }}>{item.key}</div>
                <div style={{ fontSize: 13, color: 'var(--accent3)', fontFamily: 'var(--mono)' }}>{item.val}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
