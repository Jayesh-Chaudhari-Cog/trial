import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { reportAPI } from '../services/api';

export default function ReportsPage() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [txReportModal, setTxReportModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [form, setForm] = useState({ scope: '', metrics: '' });
  const [txForm, setTxForm] = useState({ status: 'COMPLETED' });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await reportAPI.getAllReports();
      setReports(Array.isArray(res.data) ? res.data : []);
    } catch { setReports([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleGenerate = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await reportAPI.generateReport(form);
      setSuccess('Report generated!');
      setModal(false);
      setForm({ scope: '', metrics: '' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to generate report');
    }
    setSubmitting(false);
  };

  const handleTxReport = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await reportAPI.generateTransactionReport(txForm.status);
      setSuccess('Transaction report generated!');
      setTxReportModal(false);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to generate transaction report');
    }
    setSubmitting(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this report?')) return;
    try {
      await reportAPI.deleteReport(id);
      setSuccess('Report deleted');
      load();
    } catch { setError('Failed to delete'); }
  };

  return (
    <Layout title="Reports" subtitle="Analytics & report generation">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Report Center</div>
            <div className="page-subtitle">{reports.length} generated reports</div>
          </div>
          <div className="flex gap-3">
            <button className="btn btn-outline" onClick={() => setTxReportModal(true)}>📊 Transaction Report</button>
            <button className="btn btn-primary" onClick={() => setModal(true)}>+ Generate Report</button>
          </div>
        </div>

        {/* Report type cards */}
        <div className="grid-3 mb-6">
          {[
            { title: 'Farm Reports', icon: '🌾', desc: 'Yield, compliance, and quality reports for registered farms', scope: 'FARM' },
            { title: 'Transaction Reports', icon: '💸', desc: 'Payment flow, status tracking, and financial summaries', scope: 'TRANSACTION' },
            { title: 'Subsidy Reports', icon: '🏦', desc: 'Disbursement tracking and program utilization analysis', scope: 'SUBSIDY' },
          ].map(rt => (
            <div key={rt.scope} className="card" style={{ cursor: 'pointer' }}
              onClick={() => { setForm({ scope: rt.scope, metrics: `${rt.scope} metrics report` }); setModal(true); }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>{rt.icon}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>{rt.title}</div>
              <div style={{ fontSize: 13, color: 'var(--text3)' }}>{rt.desc}</div>
              <div style={{ marginTop: 16 }}>
                <span className="btn btn-outline btn-sm">Generate →</span>
              </div>
            </div>
          ))}
        </div>

        {/* Reports table */}
        <div className="section-title">📋 Generated Reports</div>
        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : reports.length === 0 ? (
          <div className="empty-state">
            <div className="icon">📊</div>
            <h3>No reports generated yet</h3>
            <p>Generate your first report using the options above</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Scope</th><th>Metrics</th><th>Generated Date</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map(r => (
                  <tr key={r.reportId || r.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{r.reportId || r.id}</td>
                    <td>
                      <span className="badge badge-blue">{r.scope || '—'}</span>
                    </td>
                    <td style={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 13, color: 'var(--text3)' }}>
                      {r.metrics || '—'}
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text3)', fontFamily: 'var(--mono)' }}>
                      {r.generatedDate || '—'}
                    </td>
                    <td>
                      <button className="btn btn-danger btn-sm" onClick={() => handleDelete(r.reportId || r.id)}>🗑</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Generate Report Modal */}
      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Generate Report</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleGenerate} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Report Scope</label>
                <select className="form-select" value={form.scope}
                  onChange={e => setForm(f => ({ ...f, scope: e.target.value }))} required>
                  <option value="">Select scope...</option>
                  {['FARM', 'TRANSACTION', 'SUBSIDY', 'MARKET', 'COMPLIANCE', 'AUDIT'].map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Metrics / Notes</label>
                <textarea className="form-textarea" placeholder="Describe what metrics to include..." value={form.metrics}
                  onChange={e => setForm(f => ({ ...f, metrics: e.target.value }))} required />
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Generating...' : 'Generate Report'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Transaction Report Modal */}
      {txReportModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setTxReportModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Generate Transaction Report</span>
              <button className="modal-close" onClick={() => setTxReportModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleTxReport} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Transaction Status</label>
                <select className="form-select" value={txForm.status}
                  onChange={e => setTxForm(f => ({ ...f, status: e.target.value }))}>
                  {['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED'].map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div className="alert alert-info">
                ℹ This will generate a report for all transactions with the selected status and save it.
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setTxReportModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Generating...' : 'Generate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
