import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { marketAPI } from '../services/api';

export default function CropListingsPage() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [filter, setFilter] = useState('ALL');
  // Backend CropListingDTO: farmerId, cropType, quantity (int), price (double), location
  const [form, setForm] = useState({
    farmerId: '', cropType: '', quantity: '', price: '', location: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = filter === 'ALL'
        ? await marketAPI.getAllListings()
        : await marketAPI.getListingsByStatus(filter);
      setListings(Array.isArray(res.data) ? res.data : []);
    } catch { setListings([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, [filter]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      // Map frontend fields to backend CropListingDTO fields exactly
      await marketAPI.createListing({
        farmerId: Number(form.farmerId),
        cropType: form.cropType,
        quantity: Number(form.quantity),
        price: Number(form.price),       // backend field is `price` not `pricePerUnit`
        location: form.location,         // required by backend @NotBlank
      });
      setSuccess('Crop listing created!');
      setModal(false);
      setForm({ farmerId: '', cropType: '', quantity: '', price: '', location: '' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to create listing');
    }
    setSubmitting(false);
  };

  const handleValidate = async (id) => {
    try {
      await marketAPI.validateListing(id);
      setSuccess('Listing validated!');
      load();
    } catch { setError('Failed to validate listing'); }
  };

  const statusColor = (s) => {
    const map = { ACTIVE: 'badge-green', PENDING: 'badge-yellow', SOLD: 'badge-blue', EXPIRED: 'badge-gray', REJECTED: 'badge-red' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Crop Listings" subtitle="Manage crop marketplace listings">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Crop Marketplace</div>
            <div className="page-subtitle">{listings.length} listings</div>
          </div>
          <button className="btn btn-primary" onClick={() => { setModal(true); setError(''); }}>+ Create Listing</button>
        </div>

        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {['ALL', 'PENDING', 'ACTIVE', 'SOLD', 'EXPIRED'].map(s => (
            <button key={s} className={`btn btn-sm ${filter === s ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setFilter(s)}>{s}</button>
          ))}
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : listings.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🌽</div>
            <h3>No listings found</h3>
            <p>Create the first crop listing to start trading</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Crop Type</th><th>Qty</th><th>Price/Unit</th><th>Location</th><th>Farmer ID</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {listings.map(l => (
                  <tr key={l.listingId || l.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{l.listingId || l.id}</td>
                    <td style={{ fontWeight: 600, color: 'var(--text)' }}>{l.cropType}</td>
                    <td>{l.quantity}</td>
                    <td style={{ color: 'var(--accent)', fontFamily: 'var(--mono)' }}>₹{l.price}</td>
                    <td>{l.location || '—'}</td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{l.farmerId}</td>
                    <td><span className={`badge ${statusColor(l.status || l.cropListingStatus)}`}>{l.status || l.cropListingStatus}</span></td>
                    <td>
                      {(l.status === 'PENDING' || l.cropListingStatus === 'PENDING') && (
                        <button className="btn btn-outline btn-sm" onClick={() => handleValidate(l.listingId || l.id)}>✓ Validate</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <span className="modal-title">Create Crop Listing</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Crop Type</label>
                  <input className="form-input" placeholder="e.g. RICE, WHEAT, COTTON" value={form.cropType}
                    onChange={e => setForm(f => ({ ...f, cropType: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Farmer ID</label>
                  <input className="form-input" type="number" placeholder="Your farmer ID" value={form.farmerId}
                    onChange={e => setForm(f => ({ ...f, farmerId: e.target.value }))} required />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Quantity (units)</label>
                  <input className="form-input" type="number" placeholder="100" value={form.quantity}
                    onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Price per Unit (₹)</label>
                  <input className="form-input" type="number" step="0.01" placeholder="25.00" value={form.price}
                    onChange={e => setForm(f => ({ ...f, price: e.target.value }))} required />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Location</label>
                <input className="form-input" placeholder="e.g. Coimbatore, Tamil Nadu" value={form.location}
                  onChange={e => setForm(f => ({ ...f, location: e.target.value }))} required />
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Creating...' : 'Create Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
