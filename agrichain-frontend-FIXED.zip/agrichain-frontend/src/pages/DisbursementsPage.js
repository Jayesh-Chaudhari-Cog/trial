import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { subsidyAPI } from '../services/api';

export default function DisbursementsPage() {
  const [disbursements, setDisbursements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [form, setForm] = useState({
    subsidyProgramId: '', farmerId: '', amount: '', disbursementStatus: 'PENDING', remarks: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await subsidyAPI.getDisbursements();
      setDisbursements(Array.isArray(res.data) ? res.data : []);
    } catch { setDisbursements([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await subsidyAPI.createDisbursement({
        ...form,
        subsidyProgramId: Number(form.subsidyProgramId),
        farmerId: Number(form.farmerId),
        amount: Number(form.amount),
      });
      setSuccess('Disbursement created!');
      setModal(false);
      setForm({ subsidyProgramId: '', farmerId: '', amount: '', disbursementStatus: 'PENDING', remarks: '' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to create disbursement');
    }
    setSubmitting(false);
  };

  const statusColor = (s) => {
    const map = { DISBURSED: 'badge-green', PENDING: 'badge-yellow', FAILED: 'badge-red', PROCESSING: 'badge-blue' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Disbursements" subtitle="Subsidy disbursement tracking">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Disbursements</div>
            <div className="page-subtitle">{disbursements.length} disbursement records</div>
          </div>
          <button className="btn btn-primary" onClick={() => setModal(true)}>+ Create Disbursement</button>
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : disbursements.length === 0 ? (
          <div className="empty-state">
            <div className="icon">💰</div>
            <h3>No disbursements</h3>
            <p>Create a disbursement from an active subsidy program</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Program ID</th><th>Farmer ID</th><th>Amount</th><th>Date</th><th>Status</th><th>Remarks</th>
                </tr>
              </thead>
              <tbody>
                {disbursements.map(d => (
                  <tr key={d.disbursementId || d.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{d.disbursementId || d.id}</td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{d.subsidyProgramId}</td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{d.farmerId}</td>
                    <td style={{ color: 'var(--accent)', fontFamily: 'var(--mono)', fontWeight: 700 }}>
                      ₹{(d.amount || 0).toLocaleString()}
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text3)' }}>{d.disbursementDate || '—'}</td>
                    <td>
                      <span className={`badge ${statusColor(d.disbursementStatus)}`}>{d.disbursementStatus}</span>
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text3)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {d.remarks || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Create Disbursement</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Subsidy Program ID</label>
                  <input className="form-input" type="number" placeholder="Program ID" value={form.subsidyProgramId}
                    onChange={e => setForm(f => ({ ...f, subsidyProgramId: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Farmer ID</label>
                  <input className="form-input" type="number" placeholder="Farmer ID" value={form.farmerId}
                    onChange={e => setForm(f => ({ ...f, farmerId: e.target.value }))} required />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Amount (₹)</label>
                  <input className="form-input" type="number" placeholder="25000" value={form.amount}
                    onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={form.disbursementStatus}
                    onChange={e => setForm(f => ({ ...f, disbursementStatus: e.target.value }))}>
                    <option value="PENDING">Pending</option>
                    <option value="PROCESSING">Processing</option>
                    <option value="DISBURSED">Disbursed</option>
                    <option value="FAILED">Failed</option>
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Remarks</label>
                <textarea className="form-textarea" placeholder="Additional notes..." value={form.remarks}
                  onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} style={{ minHeight: 70 }} />
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Creating...' : 'Create Disbursement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
