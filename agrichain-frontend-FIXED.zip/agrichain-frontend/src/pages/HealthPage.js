import React, { useState, useEffect, useCallback } from 'react';
import Layout from '../components/Layout';
import api from '../services/api';

const services = [
  { name: 'Eureka Server', port: 8761, url: 'http://localhost:8761/actuator/health', label: 'Service Registry', icon: '🗂' },
  { name: 'API Gateway', port: 8090, url: 'http://localhost:8090/actuator/health', label: 'Gateway', icon: '🔀' },
  { name: 'Registration Service', port: 8091, url: '/actuator/health', label: 'IAM + Farmer Registration', icon: '👤', proxy: true },
  { name: 'Crop Listing Service', port: 8081, url: 'http://localhost:8081/actuator/health', label: 'Market & Orders', icon: '🌽' },
  { name: 'Transaction Service', port: 8093, url: 'http://localhost:8093/actuator/health', label: 'Payments', icon: '💸' },
  { name: 'Subsidy Service', port: 9091, url: 'http://localhost:9091/actuator/health', label: 'Subsidies', icon: '🏦' },
  { name: 'Audit Service', port: 8094, url: 'http://localhost:8094/actuator/health', label: 'Compliance', icon: '🔍' },
  { name: 'Report Service', port: 8095, url: 'http://localhost:8095/actuator/health', label: 'Analytics', icon: '📊' },
];

export default function HealthPage() {
  const [statuses, setStatuses] = useState({});
  const [checking, setChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState(null);

  const checkHealth = useCallback(async () => {
    setChecking(true);
    const results = {};

    await Promise.allSettled(
      services.map(async (svc) => {
        const start = Date.now();
        try {
          // Use our proxy (gateway) to check registration health
          const res = svc.proxy
            ? await api.get(svc.url)
            : await fetch(svc.url, { signal: AbortSignal.timeout(3000) }).then(r => r.json());

          const elapsed = Date.now() - start;
          const status = svc.proxy
            ? (res.data?.status || 'UP')
            : (res?.status || 'UP');

          results[svc.port] = { status: status === 'UP' ? 'UP' : 'DOWN', latency: elapsed };
        } catch (e) {
          results[svc.port] = { status: 'DOWN', latency: null, error: e.message };
        }
      })
    );

    setStatuses(results);
    setLastChecked(new Date());
    setChecking(false);
  }, []);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 30000); // auto-refresh every 30s
    return () => clearInterval(interval);
  }, [checkHealth]);

  const upCount = Object.values(statuses).filter(s => s.status === 'UP').length;
  const downCount = Object.values(statuses).filter(s => s.status === 'DOWN').length;
  const allChecked = Object.keys(statuses).length > 0;

  return (
    <Layout title="System Health" subtitle="Real-time microservice status monitoring">
      <div className="fade-in">
        {/* Summary */}
        <div className="grid-4 mb-6">
          <div className="stat-card">
            <span className="stat-icon">🟢</span>
            <span className="stat-label">Services Up</span>
            <span className="stat-value" style={{ color: 'var(--accent)' }}>{upCount}</span>
          </div>
          <div className="stat-card">
            <span className="stat-icon">🔴</span>
            <span className="stat-label">Services Down</span>
            <span className="stat-value" style={{ color: downCount > 0 ? 'var(--danger)' : 'var(--text)' }}>{downCount}</span>
          </div>
          <div className="stat-card">
            <span className="stat-icon">⚡</span>
            <span className="stat-label">Total Services</span>
            <span className="stat-value">{services.length}</span>
          </div>
          <div className="stat-card">
            <span className="stat-icon">🔄</span>
            <span className="stat-label">Auto-Refresh</span>
            <span className="stat-value" style={{ fontSize: 18 }}>30s</span>
          </div>
        </div>

        <div className="page-header">
          <div>
            <div className="page-title">Service Status</div>
            <div className="page-subtitle">
              {lastChecked ? `Last checked: ${lastChecked.toLocaleTimeString()}` : 'Checking...'}
            </div>
          </div>
          <button className="btn btn-outline" onClick={checkHealth} disabled={checking}>
            {checking ? '⏳ Checking...' : '↻ Check Now'}
          </button>
        </div>

        <div className="health-grid" style={{ gap: 12 }}>
          {services.map(svc => {
            const s = statuses[svc.port];
            const isUp = s?.status === 'UP';
            const isDown = s?.status === 'DOWN';
            const isPending = !s;
            return (
              <div key={svc.port} className="card" style={{
                borderColor: isUp ? 'var(--accent)' : isDown ? 'var(--danger)' : 'var(--border)',
                background: isUp ? 'linear-gradient(135deg, var(--surface), rgba(74,222,128,0.04))' :
                            isDown ? 'linear-gradient(135deg, var(--surface), rgba(248,113,113,0.04))' : 'var(--surface)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                  <div style={{ fontSize: 28 }}>{svc.icon}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                      <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>{svc.name}</span>
                      <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text3)', background: 'var(--bg3)', padding: '2px 8px', borderRadius: 4 }}>
                        :{svc.port}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text3)' }}>{svc.label}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    {isPending || checking ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text3)' }}>
                        <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--text3)', animation: 'pulse 1s infinite' }} />
                        <span style={{ fontSize: 12, fontFamily: 'var(--mono)' }}>CHECKING</span>
                      </div>
                    ) : isUp ? (
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-end' }}>
                          <span className="status-dot status-dot-green" />
                          <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', fontFamily: 'var(--mono)' }}>UP</span>
                        </div>
                        {s.latency != null && (
                          <div style={{ fontSize: 11, color: 'var(--text3)', fontFamily: 'var(--mono)', marginTop: 2 }}>{s.latency}ms</div>
                        )}
                      </div>
                    ) : (
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-end' }}>
                          <span className="status-dot status-dot-red" />
                          <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--danger)', fontFamily: 'var(--mono)' }}>DOWN</span>
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--danger)', opacity: 0.7, marginTop: 2, maxWidth: 160, textAlign: 'right' }}>
                          {s.error?.slice(0, 30) || 'Unreachable'}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Startup order guide */}
        <div className="card mt-6">
          <div className="section-title">🚀 Recommended Startup Order</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
            {[
              { step: 1, name: 'Eureka Server', port: 8761, note: 'Start first — all others register here' },
              { step: 2, name: 'Registration Service', port: 8091, note: 'Required for auth/JWT before gateway' },
              { step: 3, name: 'API Gateway', port: 8090, note: 'Route traffic only after services are up' },
              { step: 4, name: 'Crop Listing Service', port: 8081, note: 'Market + Orders module' },
              { step: 5, name: 'Transaction Service', port: 8093, note: 'Depends on Crop Listing for orders' },
              { step: 6, name: 'Subsidy Service', port: 9091, note: 'Independent — can start anytime' },
              { step: 7, name: 'Audit Service', port: 8094, note: 'Independent — can start anytime' },
              { step: 8, name: 'Report Service', port: 8095, note: 'Depends on Transaction + Audit services' },
            ].map(item => (
              <div key={item.step} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 12px', background: 'var(--bg3)', borderRadius: 8 }}>
                <span style={{ width: 24, height: 24, background: 'var(--surface2)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: 'var(--accent)', flexShrink: 0 }}>
                  {item.step}
                </span>
                <span style={{ fontWeight: 600, color: 'var(--text)', minWidth: 200, fontFamily: 'var(--mono)', fontSize: 13 }}>{item.name}</span>
                <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text3)', background: 'var(--surface2)', padding: '2px 8px', borderRadius: 4 }}>:{item.port}</span>
                <span style={{ fontSize: 12, color: 'var(--text3)' }}>{item.note}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
