import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';

function decodeJwtPayload(token) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64).split('').map(c =>
        '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
      ).join('')
    );
    return JSON.parse(jsonPayload);
  } catch { return null; }
}

export default function LoginPage() {
  const [tab, setTab] = useState('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  // Backend UserRequestDTO: name, email, password, phone (10 digits), role (enum)
  const [registerForm, setRegisterForm] = useState({
    name: '', email: '', password: '', phone: '', role: 'FARMER',
  });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await authAPI.login(loginForm);
      const token = typeof res.data === 'string' ? res.data : res.data?.token;
      if (token) {
        const claims = decodeJwtPayload(token);
        const userData = {
          email: claims?.sub || loginForm.email,
          role: claims?.role || claims?.userRole || 'USER',
          name: claims?.name || loginForm.email,
        };
        login(token, userData);
        navigate('/dashboard');
      } else {
        setError('Login failed: no token received');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Login failed. Check credentials.');
    }
    setLoading(false);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    // Validate phone: exactly 10 digits
    if (!/^[0-9]{10}$/.test(registerForm.phone)) {
      setError('Phone must be exactly 10 digits (no spaces or dashes)');
      return;
    }
    // Validate password: 6+ chars, uppercase, lowercase, digit, symbol
    if (!/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!]).{6,}$/.test(registerForm.password)) {
      setError('Password must be 6+ chars with uppercase, lowercase, number, and symbol (e.g. @#$%^&+=!)');
      return;
    }
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      // Send `role` field (not `userRole`) to match UserRequestDTO
      await authAPI.register(registerForm);
      setSuccess('Account created! Please sign in.');
      setTab('login');
      setLoginForm({ email: registerForm.email, password: '' });
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Registration failed.');
    }
    setLoading(false);
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">
          <h1>🌿 AgriChain</h1>
          <p>Agricultural Blockchain Platform</p>
        </div>

        <div className="tab-group">
          <button className={`tab-btn ${tab === 'login' ? 'active' : ''}`} onClick={() => { setTab('login'); setError(''); }}>
            Sign In
          </button>
          <button className={`tab-btn ${tab === 'register' ? 'active' : ''}`} onClick={() => { setTab('register'); setError(''); }}>
            Register
          </button>
        </div>

        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        {tab === 'login' ? (
          <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input className="form-input" type="email" placeholder="you@agrichain.com"
                value={loginForm.email} onChange={e => setLoginForm(f => ({ ...f, email: e.target.value }))} required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-input" type="password" placeholder="••••••••"
                value={loginForm.password} onChange={e => setLoginForm(f => ({ ...f, password: e.target.value }))} required />
            </div>
            <button className="btn btn-primary btn-lg w-full" type="submit" disabled={loading}>
              {loading ? '⏳ Signing in...' : '→ Sign In'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input className="form-input" placeholder="Your full name (letters only)" value={registerForm.name}
                onChange={e => setRegisterForm(f => ({ ...f, name: e.target.value }))} required />
            </div>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input className="form-input" type="email" placeholder="you@agrichain.com" value={registerForm.email}
                onChange={e => setRegisterForm(f => ({ ...f, email: e.target.value }))} required />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Password</label>
                <input className="form-input" type="password" placeholder="Aa1@xxxx" value={registerForm.password}
                  onChange={e => setRegisterForm(f => ({ ...f, password: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Phone (10 digits)</label>
                <input className="form-input" placeholder="9876543210" maxLength={10} value={registerForm.phone}
                  onChange={e => setRegisterForm(f => ({ ...f, phone: e.target.value.replace(/\D/g, '') }))} required />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="form-select" value={registerForm.role}
                onChange={e => setRegisterForm(f => ({ ...f, role: e.target.value }))}>
                <option value="FARMER">Farmer</option>
                <option value="TRADER">Trader</option>
                <option value="OFFICER">Officer</option>
                <option value="ADMIN">Admin</option>
                <option value="AUDITOR">Auditor</option>
                <option value="MANAGER">Manager</option>
              </select>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text3)', padding: '8px 12px', background: 'var(--bg3)', borderRadius: 6 }}>
              💡 Password: 6+ chars with uppercase, lowercase, number &amp; symbol (e.g. <code>Admin@123</code>)
            </div>
            <button className="btn btn-primary btn-lg w-full" type="submit" disabled={loading}>
              {loading ? '⏳ Creating...' : '→ Create Account'}
            </button>
          </form>
        )}

        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--text3)', marginTop: 24, fontFamily: 'var(--mono)' }}>
          Backend: API Gateway → localhost:8090
        </p>
      </div>
    </div>
  );
}
