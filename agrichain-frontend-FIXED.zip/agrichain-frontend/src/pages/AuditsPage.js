import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { auditAPI } from '../services/api';

export default function AuditsPage() {
  const [audits, setAudits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [filter, setFilter] = useState('ALL');
  const [form, setForm] = useState({
    title: '', description: '', auditScope: 'FARM', auditStatus: 'PENDING',
    officerId: '', targetEntityId: '', scheduledDate: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = filter === 'ALL'
        ? await auditAPI.getAllAudits()
        : await auditAPI.getAuditsByStatus(filter);
      setAudits(Array.isArray(res.data) ? res.data : []);
    } catch { setAudits([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, [filter]);

  const openCreate = () => {
    setEditItem(null);
    setForm({ title: '', description: '', auditScope: 'FARM', auditStatus: 'PENDING', officerId: '', targetEntityId: '', scheduledDate: '' });
    setModal(true);
    setError('');
  };

  const openEdit = (a) => {
    setEditItem(a);
    setForm({
      title: a.title || '',
      description: a.description || '',
      auditScope: a.auditScope || 'FARM',
      auditStatus: a.auditStatus || 'PENDING',
      officerId: a.officerId || '',
      targetEntityId: a.targetEntityId || '',
      scheduledDate: a.scheduledDate || '',
    });
    setModal(true);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const payload = { ...form, officerId: Number(form.officerId), targetEntityId: Number(form.targetEntityId) };
      if (editItem) {
        await auditAPI.updateAudit(editItem.auditId || editItem.id, payload);
        setSuccess('Audit updated!');
      } else {
        await auditAPI.createAudit(payload);
        setSuccess('Audit created!');
      }
      setModal(false);
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed');
    }
    setSubmitting(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this audit?')) return;
    try {
      await auditAPI.deleteAudit(id);
      setSuccess('Audit deleted');
      load();
    } catch { setError('Failed to delete'); }
  };

  const statusColor = (s) => {
    const map = { COMPLETED: 'badge-green', PENDING: 'badge-yellow', IN_PROGRESS: 'badge-blue', CANCELLED: 'badge-gray', FAILED: 'badge-red' };
    return map[s] || 'badge-gray';
  };

  const scopeIcon = (s) => {
    const map = { FARM: '🌾', TRANSACTION: '💸', SUBSIDY: '🏦', COMPLIANCE: '📋', MARKET: '🏪' };
    return map[s] || '🔍';
  };

  return (
    <Layout title="Audits" subtitle="Compliance audit management">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Audit Management</div>
            <div className="page-subtitle">{audits.length} audit records</div>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>+ Create Audit</button>
        </div>

        {/* Filter */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {['ALL', 'PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'].map(s => (
            <button key={s} className={`btn btn-sm ${filter === s ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setFilter(s)}>{s}</button>
          ))}
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : audits.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🔍</div>
            <h3>No audits found</h3>
            <p>Create the first audit record</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Title</th><th>Scope</th><th>Officer ID</th><th>Scheduled</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {audits.map(a => (
                  <tr key={a.auditId || a.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{a.auditId || a.id}</td>
                    <td style={{ fontWeight: 600, color: 'var(--text)' }}>{a.title || '—'}</td>
                    <td>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        {scopeIcon(a.auditScope)} {a.auditScope}
                      </span>
                    </td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{a.officerId || '—'}</td>
                    <td style={{ fontSize: 12, color: 'var(--text3)' }}>{a.scheduledDate || '—'}</td>
                    <td><span className={`badge ${statusColor(a.auditStatus)}`}>{a.auditStatus}</span></td>
                    <td>
                      <div className="flex gap-2">
                        <button className="btn btn-outline btn-sm" onClick={() => openEdit(a)}>✏</button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(a.auditId || a.id)}>🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <span className="modal-title">{editItem ? 'Edit Audit' : 'Create Audit'}</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Audit Title</label>
                <input className="form-input" placeholder="e.g. Q1 Farm Compliance Audit" value={form.title}
                  onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea className="form-textarea" placeholder="Audit objectives..." value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Scope</label>
                  <select className="form-select" value={form.auditScope}
                    onChange={e => setForm(f => ({ ...f, auditScope: e.target.value }))}>
                    {['FARM', 'TRANSACTION', 'SUBSIDY', 'COMPLIANCE', 'MARKET'].map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={form.auditStatus}
                    onChange={e => setForm(f => ({ ...f, auditStatus: e.target.value }))}>
                    {['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'].map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Officer ID</label>
                  <input className="form-input" type="number" placeholder="Auditing officer ID" value={form.officerId}
                    onChange={e => setForm(f => ({ ...f, officerId: e.target.value }))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Target Entity ID</label>
                  <input className="form-input" type="number" placeholder="Farmer/Trader ID" value={form.targetEntityId}
                    onChange={e => setForm(f => ({ ...f, targetEntityId: e.target.value }))} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Scheduled Date</label>
                <input className="form-input" type="date" value={form.scheduledDate}
                  onChange={e => setForm(f => ({ ...f, scheduledDate: e.target.value }))} />
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving...' : editItem ? 'Update Audit' : 'Create Audit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
