import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { marketAPI } from '../services/api';

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [form, setForm] = useState({ listingId: '', traderId: '', quantity: '', orderStatus: 'PENDING' });
  const [submitting, setSubmitting] = useState(false);
  const [statusModal, setStatusModal] = useState(null);
  const [newStatus, setNewStatus] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const res = await marketAPI.getAllOrders();
      setOrders(Array.isArray(res.data) ? res.data : []);
    } catch { setOrders([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await marketAPI.placeOrder({ ...form, listingId: Number(form.listingId), traderId: Number(form.traderId), quantity: Number(form.quantity) });
      setSuccess('Order placed successfully!');
      setModal(false);
      setForm({ listingId: '', traderId: '', quantity: '', orderStatus: 'PENDING' });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to place order');
    }
    setSubmitting(false);
  };

  const handleUpdateStatus = async () => {
    if (!statusModal || !newStatus) return;
    try {
      await marketAPI.updateOrderStatus(statusModal, newStatus);
      setSuccess('Order status updated!');
      setStatusModal(null);
      load();
    } catch (err) {
      setError('Failed to update status');
    }
  };

  const statusColor = (s) => {
    const map = { CONFIRMED: 'badge-green', PENDING: 'badge-yellow', CANCELLED: 'badge-red', DELIVERED: 'badge-blue', COMPLETED: 'badge-green' };
    return map[s] || 'badge-gray';
  };

  return (
    <Layout title="Orders" subtitle="Crop market order management">
      <div className="fade-in">
        {error && <div className="alert alert-error">⚠ {error}</div>}
        {success && <div className="alert alert-success">✓ {success}</div>}

        <div className="page-header">
          <div>
            <div className="page-title">Order Management</div>
            <div className="page-subtitle">{orders.length} total orders</div>
          </div>
          <button className="btn btn-primary" onClick={() => setModal(true)}>+ Place Order</button>
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : orders.length === 0 ? (
          <div className="empty-state">
            <div className="icon">📦</div>
            <h3>No orders yet</h3>
            <p>Place the first order from an active crop listing</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Order ID</th><th>Listing ID</th><th>Trader ID</th><th>Qty</th><th>Total Amount</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.orderId || o.id}>
                    <td style={{ fontFamily: 'var(--mono)', color: 'var(--text3)' }}>#{o.orderId || o.id}</td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{o.listingId}</td>
                    <td style={{ fontFamily: 'var(--mono)' }}>#{o.traderId}</td>
                    <td>{o.quantity}</td>
                    <td style={{ color: 'var(--accent)', fontFamily: 'var(--mono)' }}>
                      {o.totalAmount ? `₹${o.totalAmount}` : '—'}
                    </td>
                    <td><span className={`badge ${statusColor(o.orderStatus || o.status)}`}>{o.orderStatus || o.status}</span></td>
                    <td>
                      <button className="btn btn-outline btn-sm" onClick={() => { setStatusModal(o.orderId || o.id); setNewStatus(o.orderStatus || 'CONFIRMED'); }}>
                        Update
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Place Order Modal */}
      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Place Order</span>
              <button className="modal-close" onClick={() => setModal(false)}>×</button>
            </div>
            {error && <div className="alert alert-error">⚠ {error}</div>}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Listing ID</label>
                <input className="form-input" type="number" placeholder="Crop listing ID" value={form.listingId}
                  onChange={e => setForm(f => ({ ...f, listingId: e.target.value }))} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Trader ID</label>
                  <input className="form-input" type="number" placeholder="Your trader ID" value={form.traderId}
                    onChange={e => setForm(f => ({ ...f, traderId: e.target.value }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Quantity</label>
                  <input className="form-input" type="number" placeholder="50" value={form.quantity}
                    onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} required />
                </div>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Placing...' : 'Place Order'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Update Status Modal */}
      {statusModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setStatusModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Update Order #{statusModal}</span>
              <button className="modal-close" onClick={() => setStatusModal(null)}>×</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">New Status</label>
                <select className="form-select" value={newStatus} onChange={e => setNewStatus(e.target.value)}>
                  {['PENDING', 'CONFIRMED', 'DELIVERED', 'CANCELLED', 'COMPLETED'].map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div className="form-actions">
                <button className="btn btn-outline" onClick={() => setStatusModal(null)}>Cancel</button>
                <button className="btn btn-primary" onClick={handleUpdateStatus}>Update Status</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
