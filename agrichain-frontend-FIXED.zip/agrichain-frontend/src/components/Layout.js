import React from 'react';
import Sidebar from './Sidebar';

export default function Layout({ children, title, subtitle }) {
  return (
    <div className="app-layout">
      <Sidebar />
      <main className="main-content">
        {(title || subtitle) && (
          <div className="top-bar">
            <div>
              <div className="top-bar-title">{title}</div>
              {subtitle && <div className="top-bar-subtitle">{subtitle}</div>}
            </div>
          </div>
        )}
        <div className="page-wrapper">
          {children}
        </div>
      </main>
    </div>
  );
}
