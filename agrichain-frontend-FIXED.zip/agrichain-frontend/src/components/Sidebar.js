import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { label: 'Dashboard', path: '/dashboard', icon: '🌾', section: 'Overview' },
  { label: 'System Health', path: '/health', icon: '💚', section: 'Overview' },
  { label: 'Users', path: '/users', icon: '👤', section: 'Registration' },
  { label: 'Farmers', path: '/farmers', icon: '🧑‍🌾', section: 'Registration' },
  { label: 'Documents', path: '/documents', icon: '📄', section: 'Registration' },
  { label: 'Crop Listings', path: '/market/listings', icon: '🌽', section: 'Market' },
  { label: 'Orders', path: '/market/orders', icon: '📦', section: 'Market' },
  { label: 'Transactions', path: '/transactions', icon: '💸', section: 'Payments' },
  { label: 'Subsidy Programs', path: '/subsidy/programs', icon: '🏦', section: 'Subsidies' },
  { label: 'Disbursements', path: '/subsidy/disbursements', icon: '💰', section: 'Subsidies' },
  { label: 'Audits', path: '/audits', icon: '🔍', section: 'Compliance' },
  { label: 'Audit Logs', path: '/audit-logs', icon: '📋', section: 'Compliance' },
  { label: 'Reports', path: '/reports', icon: '📊', section: 'Analytics' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const sections = [...new Set(navItems.map(i => i.section))];
  const initials = user?.name
    ? user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    : user?.email?.slice(0, 2).toUpperCase() || '??';

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <h1>🌿 AgriChain</h1>
        <p>Agricultural Platform v1.0</p>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        {sections.map(section => (
          <div key={section} className="sidebar-section">
            <div className="sidebar-section-title">{section}</div>
            {navItems
              .filter(item => item.section === section)
              .map(item => (
                <button
                  key={item.path}
                  className={`sidebar-nav-item ${location.pathname === item.path || location.pathname.startsWith(item.path + '/') ? 'active' : ''}`}
                  onClick={() => navigate(item.path)}
                >
                  <span className="icon">{item.icon}</span>
                  {item.label}
                </button>
              ))}
          </div>
        ))}
      </div>

      <div className="sidebar-footer">
        <div className="sidebar-user">
          <div className="sidebar-avatar">{initials}</div>
          <div className="sidebar-user-info">
            <div className="sidebar-user-name">{user?.name || user?.email || 'User'}</div>
            <div className="sidebar-user-role">{user?.userRole || user?.role || 'USER'}</div>
          </div>
        </div>
        <button className="btn btn-outline w-full btn-sm" onClick={logout}>
          ↩ Sign Out
        </button>
      </div>
    </aside>
  );
}
