# AgriChain Frontend

React frontend for the AgriChain microservices platform.

## Start

```bash
npm install
npm start
```

Opens at http://localhost:3000  
Proxies all API calls to API Gateway at http://localhost:8090

## Features
- Login / Register with JWT
- Dashboard with live stats
- Users, Farmers, Documents
- Crop Listings + Orders
- Transactions & Payments
- Subsidy Programs + Disbursements
- Audits + Audit Logs
- Reports & Analytics
- System Health Monitor
